<!-- CSRF Token -->
<meta name="csrf-token" content="{{ csrf_token() }}">

@extends('layouts.admin')

@section('title', 'Gold Trading Management System')

@section('content')

<!-- Module Navigation -->
<div class="container-fluid py-3">
    <!-- Main Navigation -->
<div class="row mb-3">
    <div class="col-md-6">
        <div class="card border-success">
            <div class="card-header bg-success text-white py-2">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">
                        <i class="fas fa-chart-line me-2"></i>Live Metal Prices
                        <span class="badge bg-light text-success ms-2" style="font-size: 0.6rem;">
                            <i class="fas fa-circle text-success me-1" style="font-size: 0.5rem; animation: blink 1s infinite;"></i>LIVE
                        </span>
                    </h6>
                    <button class="btn btn-light btn-sm" id="refreshLivePrices" onclick="refreshLivePrices()" style="font-size: 0.7rem;">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
            <div class="card-body p-2">
                <div class="row g-2">
                    <!-- Gold Price -->
                    <div class="col-6">
                        <div class="d-flex align-items-center p-2 border rounded bg-light">
                            <div class="me-2">
                                <i class="fas fa-coins text-warning" style="font-size: 1.2rem;"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="fw-bold text-dark" style="font-size: 0.8rem;">Gold (24K)</div>
                                <div class="text-success fw-bold" id="live-gold-price" style="font-size: 0.9rem;">
                                    Loading...
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Silver Price -->
                    <div class="col-6">
                        <div class="d-flex align-items-center p-2 border rounded bg-light">
                            <div class="me-2">
                                <i class="fas fa-medal text-secondary" style="font-size: 1.2rem;"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="fw-bold text-dark" style="font-size: 0.8rem;">Silver (999)</div>
                                <div class="text-success fw-bold" id="live-silver-price" style="font-size: 0.9rem;">
                                    Loading...
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Platinum Price -->
                    <div class="col-6">
                        <div class="d-flex align-items-center p-2 border rounded bg-light">
                            <div class="me-2">
                                <i class="fas fa-gem text-info" style="font-size: 1.2rem;"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="fw-bold text-dark" style="font-size: 0.8rem;">Platinum (999)</div>
                                <div class="text-success fw-bold" id="live-platinum-price" style="font-size: 0.9rem;">
                                    Loading...
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Palladium Price -->
                    <div class="col-6">
                        <div class="d-flex align-items-center p-2 border rounded bg-light">
                            <div class="me-2">
                                <i class="fas fa-ring text-primary" style="font-size: 1.2rem;"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="fw-bold text-dark" style="font-size: 0.8rem;">Palladium (999)</div>
                                <div class="text-success fw-bold" id="live-palladium-price" style="font-size: 0.9rem;">
                                    Loading...
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Last Updated -->
                <div class="text-center mt-2">
                    <small class="text-muted" id="livePricesLastUpdated">
                        <i class="fas fa-clock me-1"></i>Last updated: --:--
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 
    <div class="row mb-3">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body py-2">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <nav class="nav nav-pills">
                                <button class="nav-link nav-module active me-2" data-module="jewelry" onclick="switchModule('jewelry')">
                                    <i class="fas fa-gem me-1"></i>Jewelry Sales
                                </button>
                                <button class="nav-link nav-module me-2" data-module="scrap" onclick="switchModule('scrap')">
                                    <i class="fas fa-recycle me-1"></i>Scrap Metal
                                </button>
                                <button class="nav-link nav-module me-2" data-module="bullion_sell" onclick="switchModule('bullion_sell')">
                                    <i class="fas fa-coins me-1"></i>Sell Bullion
                                </button>
                                <button class="nav-link nav-module" data-module="bullion_buy" onclick="switchModule('bullion_buy')">
                                    <i class="fas fa-handshake me-1"></i>Buy Bullion
                                </button>
                            </nav>
                        </div>
                        <div class="col-md-4 text-end">
                            <button class="btn btn-outline-warning btn-sm" id="updatePricesBtn" onclick="updateMetalPrices()">
                                <i class="fas fa-sync-alt me-1"></i>Update Prices
                            </button>
                            <small class="text-muted ms-2" id="lastUpdated">Last updated: --:--</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

    <!-- Metal Type Navigation -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-warning">
                <div class="card-body py-2">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <nav class="nav nav-pills nav-pills-sm">
                                @if(isset($metalCategories) && $metalCategories->count() > 0)
                                    @foreach($metalCategories as $index => $metal)
                                        <button class="nav-link nav-metal {{ $index === 0 ? 'active' : '' }} me-2"
                                                data-metal="{{ $metal->slug }}"
                                                data-symbol="{{ $metal->symbol }}"
                                                onclick="switchMetal('{{ $metal->slug }}')">
                                            <i class="fas fa-circle {{ $metal->getIconColorClass() }} me-1"></i>
                                            {{ $metal->name }} ({{ $metal->symbol }})
                                        </button>
                                    @endforeach
                                @else
                                    <!-- Fallback if no metals in database -->
                                    <button class="nav-link nav-metal active me-2" data-metal="gold" onclick="switchMetal('gold')">
                                        <i class="fas fa-circle text-warning me-1"></i>Gold (XAU)
                                    </button>
                                @endif
                            </nav>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-end flex-wrap gap-2" id="metalPricesDisplay">
                                <!-- Prices populated by JavaScript -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Main Content Area -->
        <div class="col-lg-8">

            <!-- JEWELRY SALES MODULE -->
            <div class="module-section" id="jewelrySection">
                <!-- Sub-category Navigation for Current Metal -->
                <div class="card mb-4">
                    <div class="card-body py-2">
                        <ul class="nav nav-pills nav-pills-sm" id="subcategoryTabs">
                            <li class="nav-item">
                                <button class="nav-link active" data-subcategory="all" onclick="filterBySubcategory('all')">
                                    All Items
                                </button>
                            </li>
                            @if(isset($subcategories) && $subcategories->count() > 0)
                                @foreach($subcategories as $subcategory)
                                    <li class="nav-item">
                                        <button class="nav-link" data-subcategory="{{ $subcategory->slug }}" onclick="filterBySubcategory('{{ $subcategory->slug }}')">
                                            {{ $subcategory->name }}
                                        </button>
                                    </li>
                                @endforeach
                            @else
                                <!-- Fallback subcategories if none in database -->
                                <li class="nav-item">
                                    <button class="nav-link" data-subcategory="rings" onclick="filterBySubcategory('rings')">Rings</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-subcategory="necklaces" onclick="filterBySubcategory('necklaces')">Necklaces</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-subcategory="bracelets" onclick="filterBySubcategory('bracelets')">Bracelets</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-subcategory="earrings" onclick="filterBySubcategory('earrings')">Earrings</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-subcategory="chains" onclick="filterBySubcategory('chains')">Chains</button>
                                </li>
                            @endif
                        </ul>
                    </div>
                </div>

                <!-- Search and View Controls -->
                <div class="card mb-4">
                    <div class="card-body py-2">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="searchInput" placeholder="Search products..." onkeyup="searchProducts()">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <select class="form-select form-select-sm" id="karatFilter" onchange="filterProducts()">
                                    <option value="">All Karats</option>
                                    <option value="9">9K</option>
                                    <option value="10">10K</option>
                                    <option value="14">14K</option>
                                    <option value="18">18K</option>
                                    <option value="20">20K</option>
                                    <option value="21">21K</option>
                                    <option value="22">22K</option>
                                    <option value="23">23K</option>
                                    <option value="24">24K</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <select class="form-select form-select-sm" id="sortFilter" onchange="filterProducts()">
                                    <option value="name">Sort by Name</option>
                                    <option value="price_low">Price: Low to High</option>
                                    <option value="price_high">Price: High to Low</option>
                                    <!-- <option value="featured">Featured First</option> -->
                                </select>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex justify-content-end align-items-center gap-2">
                                    <small class="text-muted">View:</small>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <button type="button" class="btn btn-outline-primary active" id="gridViewBtn" onclick="switchToGridView()">
                                            <i class="fas fa-th"></i> Grid
                                        </button>
                                        <button type="button" class="btn btn-outline-primary" id="listViewBtn" onclick="switchToListView()">
                                            <i class="fas fa-list"></i> List
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Grid View (Cards) -->
                <div class="grid-view" id="gridView">
                    <div class="row g-3">
                        @if(isset($products) && $products->count() > 0)
                            @foreach($products as $product)
                                <div class="col-lg-3 col-md-4 col-sm-6 product-item"
                                            data-category="{{ $product->subcategory->slug ?? 'general' }}"
                                            data-subcategory="{{ $product->subcategory->slug ?? 'general' }}"
                                            data-name="{{ strtolower($product->name ?? 'product') }}"
                                            data-product-id="{{ $product->id }}"
                                            data-metal="{{ $product->metalCategory->slug ?? 'gold' }}"
                                            data-karat="{{ $product->karat ?? '18' }}"
                                            data-image-name="{{ $product->image ?? '' }}">

                                    <div class="card product-card border-0 shadow-sm h-100">
                                        <!-- Product Image -->
                                        <div class="position-relative">
                                            @php
                                                $imagePath = $product->image
                                                    ? asset('storage/' . $product->image)
                                                    : asset('images/products/default-product.jpg');
                                            @endphp

                                            <img src="{{ $imagePath }}"
                                                 class="card-img-top"
                                                 style="height: 80px; object-fit: cover;"
                                                 alt="{{ $product->name ?? 'Jewelry Product' }}"
                                                 loading="lazy"
                                                 onerror="this.src='{{ asset('images/products/default-product.jpg') }}'">

                                            @if(isset($product->is_featured) && $product->is_featured)
                                                <div class="position-absolute top-0 start-0 m-1">
                                                    <span class="badge bg-warning text-dark" style="font-size: 0.6rem;"></span>
                                                </div>
                                            @endif
                                        </div>

                                        <!-- Product Info -->
                                        <div class="card-body p-2">
                                            <!-- Product Name -->
                                            <h6 class="card-title mb-2 text-center" style="font-size: 0.8rem; line-height: 1.2;">
                                                {{ $product->name ?? 'Jewelry Product' }}
                                            </h6>

                                            <!-- Karat Selection Dropdown -->
                                            <div class="mb-2">
                                                <select class="form-select form-select-sm karat-selector"
                                                        id="karat_{{ $product->id }}"
                                                        data-product-id="{{ $product->id }}"
                                                        data-metal="{{ $product->metalCategory->slug ?? 'gold' }}"
                                                        data-subcategory="{{ $product->subcategory->slug ?? 'general' }}"
                                                        onchange="updateProductPriceOnKaratChange({{ $product->id }})"
                                                        style="font-size: 0.75rem;">
                                                    @if($product->metalCategory && $product->metalCategory->getAvailableKarats())
                                                        @foreach($product->metalCategory->getAvailableKarats() as $karat)
                                                            <option value="{{ $karat }}" {{ ($product->karat ?? '18') == $karat ? 'selected' : '' }}>
                                                                {{ $product->metalCategory->getKaratDisplayText($karat) }}
                                                            </option>
                                                        @endforeach
                                                    @else
                                                        <!-- Fallback for gold if no metal category -->
                                                        <option value="9" {{ ($product->karat ?? '18') == '9' ? 'selected' : '' }}>9K Gold</option>
                                                        <option value="10" {{ ($product->karat ?? '18') == '10' ? 'selected' : '' }}>10K Gold</option>
                                                        <option value="14" {{ ($product->karat ?? '18') == '14' ? 'selected' : '' }}>14K Gold</option>
                                                        <option value="18" {{ ($product->karat ?? '18') == '18' ? 'selected' : '' }}>18K Gold</option>
                                                        <option value="20" {{ ($product->karat ?? '18') == '20' ? 'selected' : '' }}>20K Gold</option>
                                                        <option value="21" {{ ($product->karat ?? '18') == '21' ? 'selected' : '' }}>21K Gold</option>
                                                        <option value="22" {{ ($product->karat ?? '18') == '22' ? 'selected' : '' }}>22K Gold</option>
                                                        <option value="23" {{ ($product->karat ?? '18') == '23' ? 'selected' : '' }}>23K Gold</option>
                                                        <option value="24" {{ ($product->karat ?? '18') == '24' ? 'selected' : '' }}>24K Gold</option>
                                                    @endif
                                                </select>
                                            </div>

                                            <!-- Weight Input -->
                                            <div class="mb-2">
                                                <div class="input-group input-group-sm">
                                                    <button class="btn btn-outline-secondary weight-btn-minus" type="button" data-product-id="{{ $product->id }}" style="font-size: 0.7rem;">-</button>
                                                    <input type="number"
                                                           class="form-control text-center weight-input"
                                                           id="weight_{{ $product->id }}"
                                                           data-product-id="{{ $product->id }}"
                                                           min="0.1"
                                                           step="0.1"
                                                           value="{{ $product->weight ?? 1 }}"
                                                           style="font-size: 0.75rem;">
                                                    <span class="input-group-text" style="font-size: 0.7rem;">g</span>
                                                    <button class="btn btn-outline-secondary weight-btn-plus" type="button" data-product-id="{{ $product->id }}" style="font-size: 0.7rem;">+</button>
                                                </div>
                                            </div>

                                            <!-- Price Display -->
                                            <div class="text-center mb-2">
                                                <div class="fw-bold text-primary" id="total_price_{{ $product->id }}" style="font-size: 0.85rem;">
                                                    AUD$64.13
                                                </div>
                                                <small class="text-muted" style="font-size: 0.65rem;">
                                                    <span id="weight_display_{{ $product->id }}">{{ $product->weight ?? 1 }}</span>g
                                                </small>
                                            </div>

                                            <!-- Add to Cart Button -->
                                            <button class="btn btn-primary btn-sm w-100 add-to-cart-btn"
                                                    data-product-id="{{ $product->id }}"
                                                    data-product-name="{{ $product->name ?? 'Jewelry Product' }}"
                                                    data-product-category="{{ $product->subcategory->name ?? 'Jewelry' }}"
                                                    data-product-image="{{ $imagePath }}"
                                                    style="font-size: 0.75rem; padding: 0.25rem 0.5rem;">
                                                <i class="fas fa-cart-plus me-1"></i>Add
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <div class="col-12">
                                <div class="text-center py-5">
                                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                                    <h5 class="text-muted">No products found</h5>
                                    <p class="text-muted">Try adjusting your filters or search terms</p>
                                </div>
                            </div>
                        @endif
                    </div>

                    {{-- Pagination --}}
                    @if(isset($products) && $products->hasPages())
                    <div class="d-flex justify-content-center mt-4">
                        {{ $products->appends(request()->query())->links() }}
                    </div>
                    @endif
                </div>

                <!-- List View (Table) -->
                <div class="list-view d-none" id="listView">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="80px">Image</th>
                                    <th>Product</th>
                                    <th width="100px">Category</th>
                                    <th width="120px">Karat</th>
                                    <th width="120px">Price/g</th>
                                    <th width="120px">Weight</th>
                                    <th width="120px">Total</th>
                                    <th width="140px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(isset($products) && $products->count() > 0)
                                    @foreach($products as $product)
                                        <tr class="product-row"
                                            data-category="{{ $product->subcategory->slug ?? 'general' }}"
                                            data-name="{{ strtolower($product->name ?? 'product') }}"
                                            data-product-id="{{ $product->id }}"
                                            data-metal="{{ $product->metalCategory->slug ?? 'gold' }}"
                                            data-subcategory="{{ $product->subcategory->slug ?? 'general' }}">

                                            <td>
                                                @php
                                                    $imagePath = $product->image
                                                        ? asset('storage/' . $product->image)
                                                        : asset('images/products/default-product.jpg');
                                                @endphp
                                                <img src="{{ $imagePath }}"
                                                     class="rounded"
                                                     style="width: 60px; height: 60px; object-fit: cover;"
                                                     alt="{{ $product->name ?? 'Product' }}"
                                                     onerror="this.src='{{ asset('images/products/default-product.jpg') }}'">
                                            </td>

                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div>
                                                        <h6 class="mb-0">{{ $product->name ?? 'Jewelry Product' }}</h6>
                                                        @if(isset($product->is_featured) && $product->is_featured)
                                                            <span class="badge bg-warning text-dark mt-1" style="font-size: 0.7rem;">Featured</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </td>

                                            <td>
                                                <span class="text-muted">{{ $product->subcategory->name ?? 'Jewelry' }}</span>
                                            </td>

                                            <td>
                                                <select class="form-select form-select-sm karat-selector"
                                                        id="karat_list_{{ $product->id }}"
                                                        data-product-id="{{ $product->id }}"
                                                        data-metal="{{ $product->metalCategory->slug ?? 'gold' }}"
                                                        data-subcategory="{{ $product->subcategory->slug ?? 'general' }}"
                                                        onchange="updateProductPriceOnKaratChange({{ $product->id }})"
                                                        style="width: 110px;">
                                                    @if($product->metalCategory && $product->metalCategory->getAvailableKarats())
                                                        @foreach($product->metalCategory->getAvailableKarats() as $karat)
                                                            <option value="{{ $karat }}" {{ ($product->karat ?? '18') == $karat ? 'selected' : '' }}>
                                                                {{ $karat }}{{ $product->metalCategory->symbol === 'XAU' ? 'K' : '' }}
                                                            </option>
                                                        @endforeach
                                                    @else
                                                        <!-- Fallback for gold if no metal category -->
                                                        <option value="9" {{ ($product->karat ?? '18') == '9' ? 'selected' : '' }}>9K</option>
                                                        <option value="10" {{ ($product->karat ?? '18') == '10' ? 'selected' : '' }}>10K</option>
                                                        <option value="14" {{ ($product->karat ?? '18') == '14' ? 'selected' : '' }}>14K</option>
                                                        <option value="18" {{ ($product->karat ?? '18') == '18' ? 'selected' : '' }}>18K</option>
                                                        <option value="20" {{ ($product->karat ?? '18') == '20' ? 'selected' : '' }}>20K</option>
                                                        <option value="21" {{ ($product->karat ?? '18') == '21' ? 'selected' : '' }}>21K</option>
                                                        <option value="22" {{ ($product->karat ?? '18') == '22' ? 'selected' : '' }}>22K</option>
                                                        <option value="23" {{ ($product->karat ?? '18') == '23' ? 'selected' : '' }}>23K</option>
                                                        <option value="24" {{ ($product->karat ?? '18') == '24' ? 'selected' : '' }}>24K</option>
                                                    @endif
                                                </select>
                                            </td>

                                            <td>
                                                <span class="fw-bold text-primary">
                                                    AUD$<span class="price-per-gram" id="price_per_gram_list_{{ $product->id }}">64.13</span>
                                                </span>
                                            </td>

                                            <td>
                                                <div class="input-group input-group-sm" style="width: 110px;">
                                                    <button class="btn btn-outline-secondary weight-btn-minus" type="button" data-product-id="{{ $product->id }}">-</button>
                                                    <input type="number"
                                                           class="form-control text-center weight-input"
                                                           id="weight_list_{{ $product->id }}"
                                                           data-product-id="{{ $product->id }}"
                                                           min="0.1"
                                                           step="0.1"
                                                           value="{{ $product->weight ?? 1 }}"
                                                           style="width: 50px;">
                                                    <button class="btn btn-outline-secondary weight-btn-plus" type="button" data-product-id="{{ $product->id }}">+</button>
                                                </div>
                                                <div class="weight-error-msg" id="error_list_{{ $product->id }}" style="display: none; color: #dc3545; font-size: 0.7rem;">
                                                    Weight must be > 0
                                                </div>
                                            </td>

                                            <td>
                                                <div class="fw-bold text-success" id="total_price_list_{{ $product->id }}">AUD$64.13</div>
                                                <small class="text-muted">for <span id="weight_display_list_{{ $product->id }}">{{ $product->weight ?? 1 }}</span>g</small>
                                            </td>

                                            <td>
                                                <button class="btn btn-primary btn-sm add-to-cart-btn"
                                                        data-product-id="{{ $product->id }}"
                                                        data-product-name="{{ $product->name ?? 'Jewelry Product' }}"
                                                        data-product-category="{{ $product->subcategory->name ?? 'Jewelry' }}"
                                                        data-product-image="{{ $imagePath }}">
                                                    <i class="fas fa-cart-plus me-1"></i>Add
                                                </button>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>

                    {{-- Pagination for List View --}}
                    @if(isset($products) && $products->hasPages())
                    <div class="d-flex justify-content-center mt-4">
                        {{ $products->appends(request()->query())->links() }}
                    </div>
                    @endif
                </div>

                <!-- No Products Message -->
                <div class="text-center py-5 d-none" id="noProductsMessage">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No products found</h5>
                    <p class="text-muted">Try adjusting your filters or search terms</p>
                </div>
            </div>

            <!-- SCRAP METAL MODULE -->
            <div class="module-section d-none" id="scrapSection">
                <div class="hero-section bg-gradient-warning text-dark rounded p-4 mb-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2 class="fw-bold mb-2">Scrap Metal Purchase</h2>
                            <p class="mb-0">We buy your unwanted precious metals • Instant cash offers</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="text-center">
                                <h4 class="mb-0">Competitive</h4>
                                <small>Market Rates</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Current Scrap Prices -->
                <div class="row mb-4" id="scrapPricesContainer">
                    <!-- Prices populated by JavaScript -->
                </div>

                <!-- Scrap Calculator -->
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0"><i class="fas fa-calculator me-2"></i>Scrap Metal Calculator</h5>
                        <small>We buy precious metals at competitive rates based on current market prices</small>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Metal Purity *</label>
                                    <select class="form-select" id="scrapKarat" required onchange="calculateScrapValue()">
                                        <option value="">Select Purity</option>
                                        <!-- Options populated by JavaScript based on current metal -->
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Weight (grams) *</label>
                                    <input type="number" class="form-control" id="scrapWeight" min="0.1" step="0.1" placeholder="Enter weight in grams" required oninput="calculateScrapValue()">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Description (optional)</label>
                                    <input type="text" class="form-control" id="scrapDescription" placeholder="e.g., Broken chain, old ring">
                                </div>

                                <button class="btn btn-warning w-100" onclick="addScrapToCart()">
                                    <i class="fas fa-handshake me-2"></i>Add to Transaction
                                </button>
                            </div>

                            <div class="col-md-6">
                                <div class="card bg-light border-0 h-100">
                                    <div class="card-body d-flex align-items-center justify-content-center">
                                        <div class="text-center w-100" id="scrapValue">
                                            <div class="text-muted">Enter weight to see offer</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Information Box -->
                <div class="alert alert-info mt-4">
                    <h6><i class="fas fa-info-circle me-2"></i>How Our Pricing Works</h6>
                    <ul class="mb-2 small">
                        <li><strong>Base Calculation:</strong> Metal weight × current price × purity</li>
                        <li><strong>Current Price × Purity:</strong> Already included in displayed prices</li>
                        <li><strong>Processing Fee:</strong> 15% deducted from gross value</li>
                        <li><strong>Purity Margins:</strong> Additional 5-12% deduction based on purity</li>
                        <li><strong>Final Offer:</strong> Gross value - processing fee - margin</li>
                        <li>No hidden fees or charges</li>
                    </ul>
                </div>
            </div>

            <!-- BULLION SELL MODULE -->
            <div class="module-section d-none" id="bullion_sellSection">
                <div class="hero-section bg-gradient-success text-white rounded p-4 mb-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2 class="fw-bold mb-2">Precious Metal Bullion Sales</h2>
                            <p class="mb-0">Certified pure metal bars and coins • Investment grade quality</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="text-center">
                                <h4 class="mb-0">99.9%+</h4>
                                <small>Pure Metal</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bullion Products for Sale -->
                <div class="row" id="bullionSellContainer">
                    <!-- Products populated by JavaScript -->
                </div>

                <!-- Information Box -->
                <div class="alert alert-success mt-4">
                    <h6><i class="fas fa-certificate me-2"></i>Quality Guarantee</h6>
                    <ul class="mb-0 small">
                        <li>All bullion is 99.9%+ pure precious metal</li>
                        <li>Each piece comes with authenticity certificate</li>
                        <li>8% premium added to spot metal price</li>
                        <li>Secure packaging and insured delivery</li>
                        <li>Buy-back guarantee at competitive rates</li>
                    </ul>
                </div>
            </div>

            <!-- BULLION BUY MODULE -->
            <div class="module-section d-none" id="bullion_buySection">
                <div class="hero-section bg-gradient-info text-white rounded p-4 mb-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2 class="fw-bold mb-2">Precious Metal Bullion Purchase</h2>
                            <p class="mb-0">We buy your metal bars and coins • Instant valuation</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="text-center">
                                <h4 class="mb-0">Top</h4>
                                <small>Market Rates</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bullion Buy Prices -->
                <div class="row" id="bullionBuyContainer">
                    <!-- Products populated by JavaScript -->
                </div>

                <!-- Information Box -->
                <div class="alert alert-info mt-4">
                    <h6><i class="fas fa-shield-alt me-2"></i>Purchase Process</h6>
                    <ul class="mb-0 small">
                        <li>We purchase certified pure precious metal bullion only</li>
                        <li>All items are verified for authenticity</li>
                        <li>5% margin deducted from current spot price</li>
                        <li>Immediate cash payment upon verification</li>
                        <li>Free authentication and testing service</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Cart Sidebar -->
        <div class="col-lg-4">
            <div class="cart-sidebar position-sticky" style="top: 2rem;">
                <!-- Cart Header -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Transaction Cart
                        </h5>
                    </div>

                    <!-- Cart Items -->
                    <div class="card-body p-0" style="max-height: 350px; overflow-y: auto;">
                        <div id="cartItems">
                            <div class="text-center py-4" id="emptyCart">
                                <i class="fas fa-shopping-cart fa-2x text-muted mb-2"></i>
                                <p class="text-muted mb-0">Your cart is empty</p>
                                <small class="text-muted">Add items to get started</small>
                            </div>
                        </div>
                    </div>

                    <!-- Cart Summary -->
                    <div class="card-footer">
                        <div class="cart-summary d-none" id="cartSummary">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Net Subtotal:</span>
                                <span id="cartSubtotal">AUD$0.00</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Tax (10%):</span>
                                <span id="cartTax">AUD$0.00</span>
                            </div>
                            <div class="d-flex justify-content-between mb-3">
                                <span>Shipping:</span>
                                <span id="cartShipping">AUD$25.00</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between h5">
                                <strong>Total:</strong>
                                <strong id="cartTotal">AUD$0.00</strong>
                            </div>

                            <div class="d-grid gap-2 mt-3">
                                <button class="btn btn-success" onclick="proceedToCheckout()">
                                    <i class="fas fa-credit-card me-2"></i>Proceed to Checkout
                                </button>
                                <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                                    <i class="fas fa-trash me-1"></i>Clear Cart
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Checkout Section (Hidden initially) -->
<div class="container py-4 d-none" id="checkoutSection">
    <div class="row mb-4">
        <div class="col-12">
            <div class="progress-steps text-center">
                <div class="step completed">
                    <div class="step-icon">1</div>
                    <div class="step-label">Shop</div>
                </div>
                <div class="step-line"></div>
                <div class="step active">
                    <div class="step-icon">2</div>
                    <div class="step-label">Checkout</div>
                </div>
                <div class="step-line"></div>
                <div class="step">
                    <div class="step-icon">3</div>
                    <div class="step-label">Complete</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <!-- Customer Search/Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-user me-2"></i>Customer Information</h5>
                </div>
                <div class="card-body">
                    <!-- Customer Search -->
                    <div class="mb-3">
                        <label class="form-label">Search Customer</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="customerSearch" placeholder="Search by email, phone, name, or passport ID...">
                            <button class="btn btn-outline-secondary" type="button" onclick="searchCustomer()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div id="customerSearchResults" class="mt-2"></div>
                    </div>

                    <form id="checkoutForm">
                        @csrf
                        <input type="hidden" id="customerId" name="customer_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">First Name *</label>
                                    <input type="text" class="form-control" id="customerFirstName" name="customer_first_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Last Name *</label>
                                    <input type="text" class="form-control" id="customerLastName" name="customer_last_name" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="customerEmail" name="customer_email" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="customerPhone" name="customer_phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Passport ID Number</label>
                                    <input type="text" class="form-control" id="customerPassportId" name="customer_passport_id">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Notes</label>
                                    <textarea class="form-control" name="notes" rows="2" placeholder="Special instructions..."></textarea>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Checkout Actions -->
            <div class="d-flex gap-2">
                <button class="btn btn-outline-secondary" onclick="backToShopping()">
                    <i class="fas fa-arrow-left me-2"></i>Back to Shopping
                </button>
                <button class="btn btn-success flex-fill" onclick="placeOrder()">
                    <i class="fas fa-lock me-2"></i>Complete Transaction
                </button>
            </div>
        </div>

        <!-- Checkout Summary -->
        <div class="col-lg-4">
            <div class="card position-sticky" style="top: 2rem;">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Transaction Summary</h5>
                </div>
                <div class="card-body p-0" style="max-height: 350px; overflow-y: auto;">
                    <div id="checkoutItems">
                        <!-- Items populated by JavaScript -->
                    </div>
                </div>
                <div class="card-footer">
                    <div class="order-totals">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Net Subtotal:</span>
                            <span id="checkoutSubtotal">AUD$0.00</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Tax (10% GST):</span>
                            <span id="checkoutTax">AUD$0.00</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span>Shipping:</span>
                            <span id="checkoutShipping">AUD$25.00</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between h5 mb-0">
                            <strong>Final Total:</strong>
                            <strong id="checkoutTotal">AUD$0.00</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Receipt Section (Hidden initially) -->
<div class="container py-4 d-none" id="receiptSection">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Success Animation -->
            <div class="text-center mb-5">
                <div class="success-animation mb-4">
                    <i class="fas fa-check-circle fa-5x text-success"></i>
                </div>
                <h1 class="h2 mb-3 text-success">Transaction Completed Successfully!</h1>
                <p class="lead text-muted">
                    Thank you for your business. Your transaction is being processed.
                </p>
            </div>

            <!-- Transaction Receipt -->
            <div class="card shadow-lg border-0 mb-4" id="orderReceipt">
                <div class="card-header bg-success text-white">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">
                                <i class="fas fa-receipt me-2"></i>Transaction Receipt
                            </h4>
                        </div>
                        <div class="col-auto">
                            <button class="btn btn-light btn-sm" onclick="printReceipt()">
                                <i class="fas fa-print me-1"></i>Print
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card-body" id="receiptContent">
                    <!-- Receipt content will be populated by JavaScript -->
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="text-center mb-4">
                <div class="d-grid gap-2 d-md-block">
                    <button class="btn btn-primary" onclick="downloadReceipt()">
                        <i class="fas fa-download me-2"></i>Download Receipt
                    </button>
                    <button class="btn btn-success" onclick="startNewOrder()">
                        <i class="fas fa-plus me-2"></i>New Transaction
                    </button>
                    <button class="btn btn-outline-info" onclick="emailReceipt()">
                        <i class="fas fa-envelope me-2"></i>Email Receipt
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Custom Styles for Gold Trading System */
.hero-section {
    background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
}

.bg-gradient-primary {
    background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
}

.bg-gradient-warning {
    background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
}

.bg-gradient-success {
    background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
}

.bg-gradient-info {
    background: linear-gradient(135deg, #17a2b8 0%, #117a8b 100%);
}

.nav-module {
    transition: all 0.3s ease;
}

.nav-module:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.product-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.cart-sidebar {
    max-height: calc(100vh - 4rem);
    overflow-y: auto;
}

.progress-steps {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 2rem 0;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
}

.step-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #e9ecef;
    color: #6c757d;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-bottom: 8px;
}

.step.completed .step-icon {
    background: #28a745;
    color: white;
}

.step.active .step-icon {
    background: #007bff;
    color: white;
}

.step-line {
    width: 100px;
    height: 2px;
    background: #e9ecef;
    margin: 0 20px;
    margin-top: -20px;
}

.step.completed + .step-line {
    background: #28a745;
}

.view-transition {
    animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.success-animation {
    animation: bounceIn 0.6s ease-out;
}

@keyframes bounceIn {
    0% { transform: scale(0.3); opacity: 0; }
    50% { transform: scale(1.05); }
    70% { transform: scale(0.9); }
    100% { transform: scale(1); opacity: 1; }
}

.btn-added {
    background-color: #28a745 !important;
    border-color: #28a745 !important;
    color: white !important;
}

.cart-item {
    transition: background-color 0.2s ease;
}

.cart-item:hover {
    background-color: #f8f9fa;
}

.weight-error-msg {
    font-size: 0.75rem;
    margin-top: 0.25rem;
}

.module-section {
    min-height: 600px;
}

/* Price display animations */
@keyframes priceUpdate {
    0% { background-color: #fff3cd; }
    100% { background-color: transparent; }
}

.price-updated {
    animation: priceUpdate 1s ease-out;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    .hero-section {
        text-align: center;
    }

    .progress-steps {
        flex-direction: column;
    }

    .step-line {
        width: 2px;
        height: 50px;
        margin: 10px 0;
    }

    .cart-sidebar {
        position: static !important;
        margin-top: 2rem;
    }
}
@keyframes blink {
    0%, 50% { opacity: 1; }
    51%, 100% { opacity: 0.3; }
}

/* Price update flash animation */
.price-flash {
    animation: priceFlash 0.8s ease-out;
}

@keyframes priceFlash {
    0% { background-color: #d4edda; }
    100% { background-color: #f8f9fa; }
}

/* Button loading state */
#refreshLivePrices.loading i {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
/* Print styles */
@media print {
    .btn, .nav, .card-header .btn, .alert {
        display: none !important;
    }

    .card {
        border: 1px solid #000 !important;
        box-shadow: none !important;
    }

    .card-header {
        background: #f8f9fa !important;
        color: #000 !important;
    }
}
</style>

<!-- JavaScript for Gold Trading System -->
<script>
    async function fetchAndDisplayLivePrices() {
    console.log('Fetching live metal prices...');
    
    try {
        // Fetch live prices from MetalPriceAPI
        const response = await fetch('https://api.metalpriceapi.com/v1/latest?api_key=d68f51781cca05150ab380fbea59224c&base=USD&currencies=XAU,XAG,XPD,XPT');
        
        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }

        const data = await response.json();
        console.log('API Response:', data);

        if (data.success && data.rates) {
            // Get AUD exchange rate
            const audResponse = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
            const audData = await audResponse.json();
            const audRate = audData.rates.AUD || 1.45;
            
            console.log('AUD Rate:', audRate);

            // Convert troy ounces to grams and calculate AUD prices
            const gramsPerTroyOz = 31.1035;
            
            const livePrices = {
                gold: ((data.rates.USDXAU * audRate) / gramsPerTroyOz),
                silver: ((data.rates.USDXAG * audRate) / gramsPerTroyOz),
                platinum: ((data.rates.USDXPT * audRate) / gramsPerTroyOz),
                palladium: ((data.rates.USDXPD * audRate) / gramsPerTroyOz)
            };

            console.log('Calculated Live Prices (AUD per gram):', livePrices);

            // Update display with REAL prices
            document.getElementById('live-gold-price').textContent = `AUD ${livePrices.gold.toFixed(2)}`;
            document.getElementById('live-silver-price').textContent = `AUD ${livePrices.silver.toFixed(2)}`;
            document.getElementById('live-platinum-price').textContent = `AUD ${livePrices.platinum.toFixed(2)}`;
            document.getElementById('live-palladium-price').textContent = `AUD ${livePrices.palladium.toFixed(2)}`;

            // Update last updated time
            document.getElementById('livePricesLastUpdated').innerHTML = 
                `<i class="fas fa-clock me-1"></i>Last updated: ${new Date().toLocaleTimeString()}`;

            // Add flash animation
            document.querySelectorAll('[id^="live-"][id$="-price"]').forEach(element => {
                element.parentElement.parentElement.classList.add('price-flash');
                setTimeout(() => {
                    element.parentElement.parentElement.classList.remove('price-flash');
                }, 800);
            });

            return livePrices;

        } else {
            throw new Error('Invalid API response format');
        }

    } catch (error) {
        console.error('Error fetching live prices:', error);
        
        // Show fallback prices if API fails
        const fallbackPrices = {
            gold: 154.50,
            silver: 1.68,
            platinum: 103.60,
            palladium: 152.00
        };

        document.getElementById('live-gold-price').textContent = `AUD ${fallbackPrices.gold.toFixed(2)}`;
        document.getElementById('live-silver-price').textContent = `AUD ${fallbackPrices.silver.toFixed(2)}`;
        document.getElementById('live-platinum-price').textContent = `AUD ${fallbackPrices.platinum.toFixed(2)}`;
        document.getElementById('live-palladium-price').textContent = `AUD ${fallbackPrices.palladium.toFixed(2)}`;

        document.getElementById('livePricesLastUpdated').innerHTML = 
            `<i class="fas fa-clock me-1"></i>Last updated: ${new Date().toLocaleTimeString()} (Fallback)`;

        return fallbackPrices;
    }
}

// Function to update the live price display
function updateLivePriceDisplay() {
    fetchAndDisplayLivePrices();
}

// Override the refresh button to fetch real prices
async function refreshLivePrices() {
    const refreshBtn = document.getElementById('refreshLivePrices');
    if (refreshBtn) {
        refreshBtn.classList.add('loading');
    }
    
    try {
        await fetchAndDisplayLivePrices();
    } finally {
        if (refreshBtn) {
            refreshBtn.classList.remove('loading');
        }
    }
}

// Update display immediately when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded, fetching live prices...');
    fetchAndDisplayLivePrices();
});

// Auto-refresh every 5 minutes
setInterval(() => {
    console.log('Auto-refreshing live prices...');
    fetchAndDisplayLivePrices();
}, 300000);

// Make function globally available
window.refreshLivePrices = refreshLivePrices;
    // Inject data from PHP/Database into JavaScript
    @if(isset($jsData))
        window.metalPricesFromDB = @json($jsData['metalPricesFromDB']);
        window.subcategoryLaborCosts = @json($jsData['subcategoryLaborCosts']);
        window.subcategoryProfitMargins = @json($jsData['subcategoryProfitMargins']);
        window.currentMetalSlug = @json($jsData['currentMetalSlug']);
    @endif
</script>
<!-- <script src="{{ asset('js/gold-trading-system.js') }}"></script> -->

@endsection
