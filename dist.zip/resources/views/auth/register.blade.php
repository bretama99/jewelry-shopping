{{-- File: resources/views/auth/register.blade.php --}}
@extends('layouts.admin')

@section('title', 'Create Account')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="auth-card">
                <!-- Header -->
                <div class="text-center mb-4">
                    <div class="auth-logo mb-3">
                        <i class="fas fa-gem fa-3x text-primary"></i>
                    </div>
                    <h2 class="fw-bold text-dark">Create Your Account</h2>
                    <p class="text-muted">Join our exclusive jewelry collection</p>
                </div>

                <!-- Registration Form -->
                <div class="card shadow-lg border-0">
                    <div class="card-body p-4">
                        <form method="POST" action="{{ route('register') }}">
                            @csrf

                            <!-- Full Name -->
                            <div class="mb-3">
                                <label for="name" class="form-label">
                                    <i class="fas fa-user me-2 text-muted"></i>Full Name
                                </label>
                                <input id="name" type="text"
                                       class="form-control form-control-lg @error('name') is-invalid @enderror"
                                       name="name" value="{{ old('name') }}" required autocomplete="name" autofocus
                                       placeholder="Enter your full name">
                                @error('name')
                                    <div class="invalid-feedback">
                                        <strong>{{ $message }}</strong>
                                    </div>
                                @enderror
                            </div>

                            <!-- Email Address -->
                            <div class="mb-3">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope me-2 text-muted"></i>Email Address
                                </label>
                                <input id="email" type="email"
                                       class="form-control form-control-lg @error('email') is-invalid @enderror"
                                       name="email" value="{{ old('email') }}" required autocomplete="email"
                                       placeholder="Enter your email address">
                                @error('email')
                                    <div class="invalid-feedback">
                                        <strong>{{ $message }}</strong>
                                    </div>
                                @enderror
                            </div>

                            <!-- Phone Number -->
                            <div class="mb-3">
                                <label for="phone" class="form-label">
                                    <i class="fas fa-phone me-2 text-muted"></i>Phone Number
                                </label>
                                <input id="phone" type="tel"
                                       class="form-control form-control-lg @error('phone') is-invalid @enderror"
                                       name="phone" value="{{ old('phone') }}" autocomplete="tel"
                                       placeholder="Enter your phone number (optional)">
                                @error('phone')
                                    <div class="invalid-feedback">
                                        <strong>{{ $message }}</strong>
                                    </div>
                                @enderror
                            </div>

                            <!-- Address -->
                            <div class="mb-3">
                                <label for="address" class="form-label">
                                    <i class="fas fa-map-marker-alt me-2 text-muted"></i>Address
                                </label>
                                <textarea id="address"
                                          class="form-control @error('address') is-invalid @enderror"
                                          name="address" rows="2" autocomplete="street-address"
                                          placeholder="Enter your address (optional)">{{ old('address') }}</textarea>
                                @error('address')
                                    <div class="invalid-feedback">
                                        <strong>{{ $message }}</strong>
                                    </div>
                                @enderror
                            </div>

                            <!-- Password -->
                            <div class="mb-3">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock me-2 text-muted"></i>Password
                                </label>
                                <div class="input-group">
                                    <input id="password" type="password"
                                           class="form-control form-control-lg @error('password') is-invalid @enderror"
                                           name="password" required autocomplete="new-password"
                                           placeholder="Create a strong password">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('password')">
                                        <i class="fas fa-eye" id="passwordToggleIcon"></i>
                                    </button>
                                </div>
                                <div class="form-text">
                                    <small>Password must be at least 8 characters long</small>
                                </div>
                                @error('password')
                                    <div class="invalid-feedback">
                                        <strong>{{ $message }}</strong>
                                    </div>
                                @enderror
                            </div>

                            <!-- Confirm Password -->
                            <div class="mb-3">
                                <label for="password-confirm" class="form-label">
                                    <i class="fas fa-lock me-2 text-muted"></i>Confirm Password
                                </label>
                                <div class="input-group">
                                    <input id="password-confirm" type="password"
                                           class="form-control form-control-lg"
                                           name="password_confirmation" required autocomplete="new-password"
                                           placeholder="Confirm your password">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('password-confirm')">
                                        <i class="fas fa-eye" id="confirmPasswordToggleIcon"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Terms and Conditions -->
                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                                    <label class="form-check-label" for="terms">
                                        I agree to the
                                        <a href="#" class="text-decoration-none">Terms of Service</a>
                                        and
                                        <a href="#" class="text-decoration-none">Privacy Policy</a>
                                    </label>
                                </div>
                            </div>

                            <!-- Marketing Emails -->
                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="marketing" name="marketing"
                                           {{ old('marketing') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="marketing">
                                        I'd like to receive email updates about new collections and special offers
                                    </label>
                                </div>
                            </div>

                            <!-- Register Button -->
                            <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                                <i class="fas fa-user-plus me-2"></i>Create Account
                            </button>

                            <!-- Divider -->
                            <div class="divider my-4">
                                <span class="divider-text">or</span>
                            </div>

                            <!-- Social Registration Buttons (Placeholder) -->
                            <div class="social-login mb-3">
                                <button type="button" class="btn btn-outline-danger w-100 mb-2" disabled>
                                    <i class="fab fa-google me-2"></i>Sign up with Google
                                    <small class="text-muted ms-2">(Coming Soon)</small>
                                </button>
                                <button type="button" class="btn btn-outline-primary w-100" disabled>
                                    <i class="fab fa-facebook-f me-2"></i>Sign up with Facebook
                                    <small class="text-muted ms-2">(Coming Soon)</small>
                                </button>
                            </div>

                            <!-- Login Link -->
                            <div class="text-center">
                                <p class="mb-0 text-muted">
                                    Already have an account?
                                    <a href="{{ route('login') }}" class="text-decoration-none fw-bold">
                                        Sign In
                                    </a>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Benefits Section -->
                <div class="benefits-section mt-4">
                    <div class="card bg-light border-0">
                        <div class="card-body p-3">
                            <h6 class="fw-bold mb-3">
                                <i class="fas fa-crown me-2 text-warning"></i>Member Benefits
                            </h6>
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <div class="benefit-item">
                                        <i class="fas fa-shipping-fast text-success me-2"></i>
                                        <small>Free shipping on orders over $500</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="benefit-item">
                                        <i class="fas fa-percentage text-primary me-2"></i>
                                        <small>Exclusive member discounts</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="benefit-item">
                                        <i class="fas fa-star text-warning me-2"></i>
                                        <small>Early access to new collections</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="benefit-item">
                                        <i class="fas fa-headset text-info me-2"></i>
                                        <small>Priority customer support</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Security Notice -->
                <div class="security-notice mt-3 text-center">
                    <small class="text-muted">
                        <i class="fas fa-shield-alt me-1"></i>
                        Your personal information is protected with industry-standard encryption
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
.auth-card {
    margin-top: 2rem;
    margin-bottom: 2rem;
}

.auth-logo {
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
}

.card {
    border-radius: 15px;
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
}

.form-control:focus {
    border-color: var(--bs-primary);
    box-shadow: 0 0 0 0.2rem rgba(var(--bs-primary-rgb), 0.25);
}

.divider {
    position: relative;
    text-align: center;
}

.divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: #dee2e6;
}

.divider-text {
    background: white;
    padding: 0 1rem;
    color: #6c757d;
    font-size: 0.875rem;
}

.social-login .btn {
    transition: all 0.3s ease;
}

.social-login .btn:hover:not(:disabled) {
    transform: translateY(-1px);
}

.benefit-item {
    display: flex;
    align-items: center;
    padding: 0.5rem;
    background: white;
    border-radius: 6px;
    margin-bottom: 0.5rem;
    transition: transform 0.3s ease;
}

.benefit-item:hover {
    transform: translateX(5px);
}

.benefits-section {
    animation: fadeInUp 0.8s ease-out 0.3s both;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.form-check-input:checked {
    background-color: var(--bs-primary);
    border-color: var(--bs-primary);
}

@media (max-width: 576px) {
    .auth-card {
        margin-top: 1rem;
    }

    .card-body {
        padding: 1.5rem !important;
    }
}
</style>
@endpush

@push('scripts')
<script>
function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    const toggleIcon = document.getElementById(inputId === 'password' ? 'passwordToggleIcon' : 'confirmPasswordToggleIcon');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Password strength indicator
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('password-confirm');

    // Real-time password matching
    confirmPasswordInput.addEventListener('input', function() {
        if (this.value !== passwordInput.value) {
            this.setCustomValidity('Passwords do not match');
            this.classList.add('is-invalid');
        } else {
            this.setCustomValidity('');
            this.classList.remove('is-invalid');
            if (this.value.length > 0) {
                this.classList.add('is-valid');
            }
        }
    });

    passwordInput.addEventListener('input', function() {
        // Reset confirm password validation when password changes
        if (confirmPasswordInput.value) {
            confirmPasswordInput.dispatchEvent(new Event('input'));
        }

        // Password strength feedback
        const strength = getPasswordStrength(this.value);
        updatePasswordStrength(strength);
    });

    function getPasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength++;
        if (password.match(/[a-z]/)) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;
        return strength;
    }

    function updatePasswordStrength(strength) {
        // Could add a visual password strength indicator here
        const strengthTexts = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
        const strengthColors = ['danger', 'warning', 'info', 'primary', 'success'];

        // Update visual feedback if needed
    }

    // Form validation feedback
    const form = document.querySelector('form');
    const inputs = form.querySelectorAll('input[required]');

    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });

        input.addEventListener('input', function() {
            if (this.classList.contains('is-invalid') && this.value.trim() !== '') {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });
    });

    // Email validation
    const emailInput = document.getElementById('email');
    emailInput.addEventListener('blur', function() {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (this.value && !emailRegex.test(this.value)) {
            this.classList.add('is-invalid');
            this.setCustomValidity('Please enter a valid email address');
        } else {
            this.setCustomValidity('');
            if (this.value) {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        }
    });

    // Terms checkbox validation
    const termsCheckbox = document.getElementById('terms');
    termsCheckbox.addEventListener('change', function() {
        if (!this.checked) {
            this.setCustomValidity('You must agree to the terms and conditions');
        } else {
            this.setCustomValidity('');
        }
    });

    // Animate form elements on load
    const formElements = document.querySelectorAll('.form-control, .btn, .form-check');
    formElements.forEach((element, index) => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';

        setTimeout(() => {
            element.style.transition = 'all 0.5s ease';
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, index * 50);
    });
});
</script>
@endpush
