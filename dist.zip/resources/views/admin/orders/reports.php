@extends('layouts.admin')

@section('title', 'Reports & Analytics')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">
                <i class="fas fa-chart-line me-2"></i>Reports & Analytics
            </h1>
            <p class="mb-0 text-muted">Business insights and performance metrics</p>
        </div>
        <div class="d-flex gap-2">
            <select class="form-select" id="dateRange">
                <option value="7">Last 7 days</option>
                <option value="30" selected>Last 30 days</option>
                <option value="90">Last 90 days</option>
                <option value="365">Last year</option>
            </select>
            <button class="btn btn-outline-success" onclick="exportReports()">
                <i class="fas fa-download me-1"></i> Export
            </button>
            <button class="btn btn-primary" onclick="refreshReports()">
                <i class="fas fa-sync-alt me-1"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Overview Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Revenue</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">$45,280</div>
                            <div class="text-success small">
                                <i class="fas fa-arrow-up"></i> 12.5% vs last period
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Orders</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">1,247</div>
                            <div class="text-success small">
                                <i class="fas fa-arrow-up"></i> 8.2% vs last period
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">New Customers</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">156</div>
                            <div class="text-info small">
                                <i class="fas fa-arrow-up"></i> 15.3% vs last period
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Avg Order Value</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">$363</div>
                            <div class="text-warning small">
                                <i class="fas fa-arrow-down"></i> 2.1% vs last period
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row mb-4">
        <!-- Revenue Chart -->
        <div class="col-xl-8">
            <div class="card shadow">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Revenue Over Time</h6>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary active" data-chart="revenue">Revenue</button>
                        <button class="btn btn-outline-primary" data-chart="orders">Orders</button>
                        <button class="btn btn-outline-primary" data-chart="customers">Customers</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="revenueChart" width="100%" height="40"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Products -->
        <div class="col-xl-4">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Top Selling Products</h6>
                </div>
                <div class="card-body">
                    <div class="top-products-list">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-gem text-white"></i>
                                </div>
                                <div>
                                    <div class="font-weight-bold">Diamond Ring</div>
                                    <div class="text-muted small">89 sold</div>
                                </div>
                            </div>
                            <div class="text-success font-weight-bold">$12,450</div>
                        </div>

                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-success d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-ring text-white"></i>
                                </div>
                                <div>
                                    <div class="font-weight-bold">Gold Necklace</div>
                                    <div class="text-muted small">67 sold</div>
                                </div>
                            </div>
                            <div class="text-success font-weight-bold">$8,950</div>
                        </div>

                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-star text-white"></i>
                                </div>
                                <div>
                                    <div class="font-weight-bold">Silver Bracelet</div>
                                    <div class="text-muted small">45 sold</div>
                                </div>
                            </div>
                            <div class="text-success font-weight-bold">$6,780</div>
                        </div>

                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-warning d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-crown text-white"></i>
                                </div>
                                <div>
                                    <div class="font-weight-bold">Pearl Earrings</div>
                                    <div class="text-muted small">32 sold</div>
                                </div>
                            </div>
                            <div class="text-success font-weight-bold">$4,320</div>
                        </div>

                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle bg-danger d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-heart text-white"></i>
                                </div>
                                <div>
                                    <div class="font-weight-bold">Ruby Pendant</div>
                                    <div class="text-muted small">28 sold</div>
                                </div>
                            </div>
                            <div class="text-success font-weight-bold">$3,850</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Detailed Reports -->
    <div class="row mb-4">
        <!-- Sales Performance -->
        <div class="col-xl-6">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Sales by Category</h6>
                </div>
                <div class="card-body">
                    <canvas id="categoryChart" width="100%" height="50"></canvas>
                </div>
            </div>
        </div>

        <!-- Customer Analytics -->
        <div class="col-xl-6">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Customer Metrics</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-4">
                                <div class="small font-weight-bold text-primary text-uppercase mb-1">Customer Retention</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">78.5%</div>
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 78.5%"></div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="small font-weight-bold text-success text-uppercase mb-1">Repeat Customers</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">45.2%</div>
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 45.2%"></div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="small font-weight-bold text-info text-uppercase mb-1">Customer Satisfaction</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">92.3%</div>
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: 92.3%"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <canvas id="customerChart" width="100%" height="50"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Orders Table -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Recent High-Value Orders</h6>
                    @if(Route::has('admin.orders.index'))
                        <a href="{{ route('admin.orders.index') }}" class="btn btn-primary btn-sm">View All Orders</a>
                    @else
                        <button class="btn btn-primary btn-sm">View All Orders</button>
                    @endif
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Products</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>#ORD-1234</strong></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                                <span class="text-white small">JS</span>
                                            </div>
                                            John Smith
                                        </div>
                                    </td>
                                    <td>Diamond Ring, Gold Chain</td>
                                    <td class="font-weight-bold text-success">$2,450</td>
                                    <td><span class="badge bg-success">Completed</span></td>
                                    <td>2 hours ago</td>
                                </tr>
                                <tr>
                                    <td><strong>#ORD-1233</strong></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-info d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                                <span class="text-white small">MJ</span>
                                            </div>
                                            Mary Johnson
                                        </div>
                                    </td>
                                    <td>Pearl Necklace Set</td>
                                    <td class="font-weight-bold text-success">$1,890</td>
                                    <td><span class="badge bg-warning text-dark">Processing</span></td>
                                    <td>5 hours ago</td>
                                </tr>
                                <tr>
                                    <td><strong>#ORD-1232</strong></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-success d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                                <span class="text-white small">RB</span>
                                            </div>
                                            Robert Brown
                                        </div>
                                    </td>
                                    <td>Wedding Ring Set</td>
                                    <td class="font-weight-bold text-success">$3,200</td>
                                    <td><span class="badge bg-primary">Shipped</span></td>
                                    <td>1 day ago</td>
                                </tr>
                                <tr>
                                    <td><strong>#ORD-1231</strong></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-warning d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                                <span class="text-white small">LD</span>
                                            </div>
                                            Lisa Davis
                                        </div>
                                    </td>
                                    <td>Sapphire Earrings</td>
                                    <td class="font-weight-bold text-success">$1,650</td>
                                    <td><span class="badge bg-success">Completed</span></td>
                                    <td>2 days ago</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
.chart-area {
    position: relative;
    height: 300px;
}

.top-products-list {
    max-height: 350px;
    overflow-y: auto;
}

.progress {
    background-color: #f8f9fc;
}

.card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}

.text-gray-800 {
    color: #5a5c69 !important;
}

.border-left-primary {
    border-left: 0.25rem solid #4e73df !important;
}

.border-left-success {
    border-left: 0.25rem solid #1cc88a !important;
}

.border-left-info {
    border-left: 0.25rem solid #36b9cc !important;
}

.border-left-warning {
    border-left: 0.25rem solid #f6c23e !important;
}

.table td {
    vertical-align: middle;
}

.btn-group .btn.active {
    background-color: #4e73df;
    border-color: #4e73df;
    color: white;
}
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue',
                data: [12000, 15000, 18000, 22000, 25000, 28000, 32000, 35000, 38000, 42000, 45000, 48000],
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Category Chart
    const categoryCtx = document.getElementById('categoryChart').getContext('2d');
    new Chart(categoryCtx, {
        type: 'doughnut',
        data: {
            labels: ['Rings', 'Necklaces', 'Earrings', 'Bracelets', 'Watches'],
            datasets: [{
                data: [35, 25, 20, 12, 8],
                backgroundColor: [
                    '#4e73df',
                    '#1cc88a',
                    '#36b9cc',
                    '#f6c23e',
                    '#e74a3b'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Customer Chart
    const customerCtx = document.getElementById('customerChart').getContext('2d');
    new Chart(customerCtx, {
        type: 'pie',
        data: {
            labels: ['New', 'Returning', 'VIP'],
            datasets: [{
                data: [45, 35, 20],
                backgroundColor: [
                    '#36b9cc',
                    '#1cc88a',
                    '#f6c23e'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Chart toggle buttons
    document.querySelectorAll('[data-chart]').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('[data-chart]').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            const chartType = this.getAttribute('data-chart');
            updateMainChart(chartType);
        });
    });

    function updateMainChart(type) {
        let newData, newLabel, newColor;

        switch(type) {
            case 'revenue':
                newData = [12000, 15000, 18000, 22000, 25000, 28000, 32000, 35000, 38000, 42000, 45000, 48000];
                newLabel = 'Revenue';
                newColor = '#4e73df';
                break;
            case 'orders':
                newData = [120, 150, 180, 220, 250, 280, 320, 350, 380, 420, 450, 480];
                newLabel = 'Orders';
                newColor = '#1cc88a';
                break;
            case 'customers':
                newData = [45, 52, 61, 78, 89, 95, 105, 118, 132, 145, 156, 168];
                newLabel = 'New Customers';
                newColor = '#36b9cc';
                break;
        }

        revenueChart.data.datasets[0].data = newData;
        revenueChart.data.datasets[0].label = newLabel;
        revenueChart.data.datasets[0].borderColor = newColor;
        revenueChart.data.datasets[0].backgroundColor = newColor + '0D';
        revenueChart.update();
    }
});

function refreshReports() {
    const refreshBtn = document.querySelector('[onclick="refreshReports()"]');
    const originalHTML = refreshBtn.innerHTML;
    refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Refreshing...';
    refreshBtn.disabled = true;

    setTimeout(() => {
        refreshBtn.innerHTML = originalHTML;
        refreshBtn.disabled = false;
        showAlert('Reports refreshed successfully!', 'success');
    }, 2000);
}

function exportReports() {
    const exportBtn = document.querySelector('[onclick="exportReports()"]');
    const originalHTML = exportBtn.innerHTML;
    exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Exporting...';
    exportBtn.disabled = true;

    setTimeout(() => {
        exportBtn.innerHTML = originalHTML;
        exportBtn.disabled = false;
        showAlert('Report exported successfully!', 'success');
    }, 3000);
}

function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        <i class="fas fa-check-circle me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}
</script>
@endpush