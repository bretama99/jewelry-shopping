{{-- File: resources/views/admin/orders/receipt.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Receipt - Order #{{ $order->order_number }}</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .company-logo {
            font-size: 24px;
            font-weight: bold;
            color: #DAA520;
            margin-bottom: 10px;
        }

        .company-info {
            font-size: 11px;
            line-height: 1.4;
            color: #666;
        }

        .receipt-title {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .order-info {
            display: table;
            width: 100%;
            margin-bottom: 30px;
        }

        .order-info-left,
        .order-info-right {
            display: table-cell;
            width: 50%;
            vertical-align: top;
            padding: 0 10px;
        }

        .info-section {
            margin-bottom: 20px;
        }

        .info-title {
            font-weight: bold;
            font-size: 13px;
            margin-bottom: 8px;
            text-transform: uppercase;
            border-bottom: 1px solid #ddd;
            padding-bottom: 2px;
        }

        .info-content {
            line-height: 1.4;
            font-size: 11px;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        .items-table th {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-weight: bold;
            font-size: 11px;
        }

        .items-table td {
            border: 1px solid #ddd;
            padding: 8px;
            font-size: 11px;
            vertical-align: top;
        }

        .items-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .totals-section {
            margin-top: 20px;
            float: right;
            width: 300px;
        }

        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }

        .totals-table td {
            padding: 5px 10px;
            border-bottom: 1px solid #eee;
        }

        .totals-table .total-line {
            border-top: 2px solid #000;
            border-bottom: 2px solid #000;
            font-weight: bold;
            font-size: 13px;
        }

        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 10px;
            color: #666;
            clear: both;
        }

        .payment-info {
            background-color: #f8f9fa;
            padding: 15px;
            border: 1px solid #ddd;
            margin: 20px 0;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .gold-prices {
            font-size: 10px;
            color: #666;
            margin-top: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
        }

        .product-details {
            font-size: 10px;
            color: #666;
            line-height: 1.3;
        }

        .weight-calculation {
            font-size: 10px;
            color: #666;
            font-style: italic;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="company-logo">
            🏺 GOLD JEWELRY STORE
        </div>
        <div class="company-info">
            123 Jewelry Street, Sydney NSW 2000, Australia<br>
            Phone: +61 2 9999 8888 | Email: sales@goldjewelrystore.com<br>
            ABN: 12 345 678 901 | GST Registered
        </div>
    </div>

    <!-- Receipt Title -->
    <div class="receipt-title">
        Tax Invoice / Receipt
    </div>

    <!-- Order Information -->
    <div class="order-info">
        <div class="order-info-left">
            <div class="info-section">
                <div class="info-title">Order Details</div>
                <div class="info-content">
{{-- File: resources/views/admin/orders/receipt.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Receipt - Order #{{ $order->order_number }}</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .company-logo {
            font-size: 24px;
            font-weight: bold;
            color: #DAA520;
            margin-bottom: 10px;
        }

        .company-info {
            font-size: 11px;
            line-height: 1.4;
            color: #666;
        }

        .receipt-title {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .order-info {
            display: table;
            width: 100%;
            margin-bottom: 30px;
        }

        .order-info-left,
        .order-info-right {
            display: table-cell;
            width: 50%;
            vertical-align: top;
            padding: 0 10px;
        }

        .info-section {
            margin-bottom: 20px;
        }

        .info-title {
            font-weight: bold;
            font-size: 13px;
            margin-bottom: 8px;
            text-transform: uppercase;
            border-bottom: 1px solid #ddd;
            padding-bottom: 2px;
        }

        .info-content {
            line-height: 1.4;
            font-size: 11px;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        .items-table th {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-weight: bold;
            font-size: 11px;
        }

        .items-table td {
            border: 1px solid #ddd;
            padding: 8px;
            font-size: 11px;
            vertical-align: top;
        }

        .items-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .totals-section {
            margin-top: 20px;
            float: right;
            width: 300px;
        }

        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }

        .totals-table td {
            padding: 5px 10px;
            border-bottom: 1px solid #eee;
        }

        .totals-table .total-line {
            border-top: 2px solid #000;
            border-bottom: 2px solid #000;
            font-weight: bold;
            font-size: 13px;
        }

        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 10px;
            color: #666;
            clear: both;
        }

        .payment-info {
            background-color: #f8f9fa;
            padding: 15px;
            border: 1px solid #ddd;
            margin: 20px 0;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .gold-prices {
            font-size: 10px;
            color: #666;
            margin-top: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
        }

        .product-details {
            font-size: 10px;
            color: #666;
            line-height: 1.3;
        }

        .weight-calculation {
            font-size: 10px;
            color: #666;
            font-style: italic;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="company-logo">
            🏺 GOLD JEWELRY STORE
        </div>
        <div class="company-info">
            123 Jewelry Street, Sydney NSW 2000, Australia<br>
            Phone: +61 2 9999 8888 | Email: sales@goldjewelrystore.com<br>
            ABN: 12 345 678 901 | GST Registered
        </div>
    </div>

    <!-- Receipt Title -->
    <div class="receipt-title">
        Tax Invoice / Receipt
    </div>

    <!-- Order Information -->
    <div class="order-info">
        <div class="order-info-left">
            <div class="info-section">
                <div class="info-title">Order Details</div>
                <div class="info-content">
                    <strong>Order Number:</strong> #{{ $order->order_number }}<br>
                    <strong>Order Date:</strong> {{ $order->created_at->format('d/m/Y H:i') }}<br>
                    <strong>Status:</strong>
                    <span class="status-badge {{ $order->payment_status == 'paid' ? 'status-paid' : 'status-pending' }}">
                        {{ ucfirst($order->payment_status) }}
                    </span><br>
                    @if($order->payment_method)
                        <strong>Payment Method:</strong> {{ ucfirst($order->payment_method) }}<br>
                    @endif
                    @if($order->tracking_number)
                        <strong>Tracking Number:</strong> {{ $order->tracking_number }}<br>
                    @endif
                </div>
            </div>

            <div class="info-section">
                <div class="info-title">Bill To</div>
                <div class="info-content">
                    {{ $order->customer_name ?? 'Guest Customer' }}<br>
                    @if($order->customer_email)
                        {{ $order->customer_email }}<br>
                    @endif
                    @if($order->customer_phone)
                        {{ $order->customer_phone }}<br>
                    @endif
                    @if($order->billing_address)
                        {{ $order->billing_address }}<br>
                        @if($order->billing_address2)
                            {{ $order->billing_address2 }}<br>
                        @endif
                        {{ $order->billing_city }}, {{ $order->billing_state }} {{ $order->billing_zip }}<br>
                        {{ $order->billing_country ?? 'Australia' }}
                    @endif
                </div>
            </div>
        </div>

        <div class="order-info-right">
            @if($order->shipping_address)
                <div class="info-section">
                    <div class="info-title">Ship To</div>
                    <div class="info-content">
                        {{ $order->shipping_name ?? $order->customer_name }}<br>
                        {{ $order->shipping_address }}<br>
                        @if($order->shipping_address2)
                            {{ $order->shipping_address2 }}<br>
                        @endif
                        {{ $order->shipping_city }}, {{ $order->shipping_state }} {{ $order->shipping_zip }}<br>
                        {{ $order->shipping_country ?? 'Australia' }}
                    </div>
                </div>
            @endif

            <div class="info-section">
                <div class="info-title">Payment Information</div>
                <div class="info-content">
                    <strong>Payment Status:</strong>
                    <span class="status-badge {{ $order->payment_status == 'paid' ? 'status-paid' : 'status-pending' }}">
                        {{ ucfirst($order->payment_status) }}
                    </span><br>
                    @if($order->payment_method)
                        <strong>Payment Method:</strong> {{ ucfirst($order->payment_method) }}<br>
                    @endif
                    @if($order->payment_reference)
                        <strong>Reference:</strong> {{ $order->payment_reference }}<br>
                    @endif
                    <strong>Total Paid:</strong> ${{ number_format($order->total_amount, 2) }}
                </div>
            </div>
        </div>
    </div>

    <!-- Order Items -->
    <table class="items-table">
        <thead>
            <tr>
                <th style="width: 35%;">Product</th>
                <th style="width: 15%;">Weight (g)</th>
                <th style="width: 12%;">Karat</th>
                <th style="width: 15%;">Price/Gram</th>
                <th style="width: 8%;">Qty</th>
                <th style="width: 15%;" class="text-right">Total</th>
            </tr>
        </thead>
        <tbody>
            @php $subtotal = 0; @endphp
            @foreach($order->orderItems as $item)
                @php
                    $itemTotal = $item->price * $item->weight * ($item->quantity ?? 1);
                    $subtotal += $itemTotal;
                @endphp
                <tr>
                    <td>
                        <strong>{{ $item->product_name }}</strong>
                        @if($item->product && $item->product->sku)
                            <br><small>SKU: {{ $item->product->sku }}</small>
                        @endif
                        <div class="product-details">
                            @if($item->product && $item->product->description)
                                {{ Str::limit($item->product->description, 100) }}
                            @endif
                        </div>
                    </td>
                    <td class="text-center">
                        {{ number_format($item->weight, 2) }}g
                        <div class="weight-calculation">
                            Custom weight selected
                        </div>
                    </td>
                    <td class="text-center">
                        <strong>{{ $item->karat }}K</strong>
                        <div class="product-details">
                            {{ number_format(($item->karat / 24) * 100, 1) }}% purity
                        </div>
                    </td>
                    <td class="text-right">
                        ${{ number_format($item->price, 2) }}
                        <div class="product-details">
                            Based on live gold rates
                        </div>
                    </td>
                    <td class="text-center">{{ $item->quantity ?? 1 }}</td>
                    <td class="text-right">
                        <strong>${{ number_format($itemTotal, 2) }}</strong>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Totals Section -->
    <div class="totals-section">
        <table class="totals-table">
            <tr>
                <td>Subtotal:</td>
                <td class="text-right">${{ number_format($subtotal, 2) }}</td>
            </tr>
            @if($order->discount_amount > 0)
                <tr>
                    <td>Discount:</td>
                    <td class="text-right">-${{ number_format($order->discount_amount, 2) }}</td>
                </tr>
            @endif
            @if($order->shipping_amount > 0)
                <tr>
                    <td>Shipping:</td>
                    <td class="text-right">${{ number_format($order->shipping_amount, 2) }}</td>
                </tr>
            @endif
            @if($order->tax_amount > 0)
                <tr>
                    <td>GST ({{ number_format(($order->tax_amount / ($subtotal + ($order->shipping_amount ?? 0))) * 100, 1) }}%):</td>
                    <td class="text-right">${{ number_format($order->tax_amount, 2) }}</td>
                </tr>
            @endif
            <tr class="total-line">
                <td><strong>TOTAL:</strong></td>
                <td class="text-right"><strong>${{ number_format($order->total_amount, 2) }}</strong></td>
            </tr>
        </table>
    </div>

    <!-- Gold Prices Information -->
    <div class="gold-prices">
        <strong>Gold Prices at Time of Purchase:</strong><br>
        @if(isset($goldPrices) && is_array($goldPrices))
            @foreach($goldPrices as $karat => $price)
                {{ $karat }}K Gold: ${{ number_format($price, 2) }}/gram &nbsp;&nbsp;
            @endforeach
        @else
            10K Gold: $35.20/gram &nbsp;&nbsp; 14K Gold: $49.30/gram &nbsp;&nbsp; 18K Gold: $63.40/gram &nbsp;&nbsp; 22K Gold: $77.50/gram &nbsp;&nbsp; 24K Gold: $85.50/gram
        @endif
        <br><small>Prices are based on live market rates and may fluctuate.</small>
    </div>

    <!-- Payment Information Box -->
    @if($order->payment_status == 'paid')
        <div class="payment-info">
            <strong>✓ PAYMENT CONFIRMED</strong><br>
            This order has been fully paid and confirmed.
            @if($order->payment_method)
                Payment was processed via {{ ucfirst($order->payment_method) }}.
            @endif
            @if($order->payment_date)
                Payment confirmed on {{ $order->payment_date->format('d/m/Y H:i') }}.
            @endif
        </div>
    @else
        <div class="payment-info">
            <strong>⚠ PAYMENT PENDING</strong><br>
            This order is awaiting payment confirmation. Please ensure payment is completed to avoid delays in processing.
        </div>
    @endif

    <!-- Terms and Conditions -->
    <div style="margin-top: 30px; font-size: 10px; line-height: 1.4;">
        <strong>Terms & Conditions:</strong><br>
        • All jewelry comes with a lifetime warranty against manufacturing defects.<br>
        • Custom weight orders are final and non-refundable unless defective.<br>
        • Gold prices are subject to market fluctuations and locked at time of purchase.<br>
        • Delivery times may vary based on location and availability.<br>
        • For warranty claims or support, contact us at support@goldjewelrystore.com<br>
        • This receipt serves as proof of purchase and warranty coverage.
    </div>

    <!-- Footer -->
    <div class="footer">
        <strong>Thank you for choosing Gold Jewelry Store!</strong><br>
        For questions about your order, please contact us at +61 2 9999 8888 or orders@goldjewelrystore.com<br>
        Visit us online at www.goldjewelrystore.com | Follow us on social media @goldjewelrystore<br><br>
        <small>This is a computer-generated receipt. Printed on {{ now()->format('d/m/Y H:i') }}</small>
    </div>
</body>
</html>
