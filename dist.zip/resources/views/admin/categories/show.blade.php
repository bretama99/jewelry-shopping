{{-- File: resources/views/admin/categories/show.blade.php --}}
@extends('layouts.admin')

@section('title', 'Category Details')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">{{ $category->name }}</h1>
            <p class="mb-0 text-muted">Category details and management</p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('categories.show', $category) }}"
               class="btn btn-outline-info" target="_blank">
                <i class="fas fa-external-link-alt me-2"></i>View on Website
            </a>
            <a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-primary">
                <i class="fas fa-edit me-2"></i>Edit Category
            </a>
            <a href="{{ route('admin.categories.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Categories
            </a>
        </div>
    </div>

    <div class="row">
        <!-- Category Overview -->
        <div class="col-lg-4">
            <!-- Category Image & Basic Info -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Category Overview</h6>
                </div>
                <div class="card-body text-center">
                    @if($category->image)
                        <img src="{{ $category->image_url }}" alt="{{ $category->name }}"
                             class="img-fluid rounded mb-3" style="max-height: 200px;">
                    @else
                        <div class="bg-light rounded p-4 mb-3">
                            <i class="fas fa-image fa-3x text-muted"></i>
                            <p class="text-muted mt-2 mb-0">No image uploaded</p>
                        </div>
                    @endif

                    <h4 class="fw-bold text-dark">{{ $category->name }}</h4>

                    <div class="d-flex justify-content-center gap-3 mt-3">
                        <span class="badge bg-{{ $category->is_active ? 'success' : 'secondary' }} px-3 py-2">
                            <i class="fas fa-{{ $category->is_active ? 'check' : 'times' }} me-1"></i>
                            {{ $category->is_active ? 'Active' : 'Inactive' }}
                        </span>
                        <span class="badge bg-info px-3 py-2">
                            Sort Order: {{ $category->sort_order }}
                        </span>
                    </div>

                    @if($category->description)
                        <div class="mt-3 p-3 bg-light rounded">
                            <h6 class="fw-bold mb-2">Description</h6>
                            <p class="text-muted mb-0">{{ $category->description }}</p>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Category Statistics -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">Statistics</h6>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-6 text-center">
                            <div class="stat-card border rounded p-3">
                                <h3 class="text-primary mb-1">{{ $category->products()->count() }}</h3>
                                <small class="text-muted">Total Products</small>
                            </div>
                        </div>
                        <div class="col-6 text-center">
                            <div class="stat-card border rounded p-3">
                                <h3 class="text-success mb-1">{{ $category->products()->where('is_active', true)->count() }}</h3>
                                <small class="text-muted">Active Products</small>
                            </div>
                        </div>
                        <div class="col-6 text-center">
                            <div class="stat-card border rounded p-3">
                                <h3 class="text-warning mb-1">{{ $category->products()->where('is_featured', true)->count() }}</h3>
                                <small class="text-muted">Featured</small>
                            </div>
                        </div>
                        <div class="col-6 text-center">
                            <div class="stat-card border rounded p-3">
                                <h3 class="text-info mb-1">{{ $category->products()->distinct('karat')->count('karat') }}</h3>
                                <small class="text-muted">Karat Types</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category Details -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-info">Technical Details</h6>
                </div>
                <div class="card-body">
                    <div class="detail-item d-flex justify-content-between border-bottom pb-2 mb-2">
                        <span class="text-muted">ID:</span>
                        <span class="fw-bold">{{ $category->id }}</span>
                    </div>
                    <div class="detail-item d-flex justify-content-between border-bottom pb-2 mb-2">
                        <span class="text-muted">Slug:</span>
                        <span class="fw-bold">{{ $category->slug }}</span>
                    </div>
                    <div class="detail-item d-flex justify-content-between border-bottom pb-2 mb-2">
                        <span class="text-muted">Created:</span>
                        <span class="fw-bold">{{ $category->created_at->format('M d, Y') }}</span>
                    </div>
                    <div class="detail-item d-flex justify-content-between border-bottom pb-2 mb-2">
                        <span class="text-muted">Updated:</span>
                        <span class="fw-bold">{{ $category->updated_at->format('M d, Y') }}</span>
                    </div>
                    <div class="detail-item d-flex justify-content-between">
                        <span class="text-muted">Sort Order:</span>
                        <span class="fw-bold">{{ $category->sort_order }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Products in Category -->
        <div class="col-lg-8">
            <div class="card shadow">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Products in {{ $category->name }}</h6>
                    <div class="d-flex gap-2">
                        <a href="{{ route('admin.products.create') }}?category={{ $category->id }}"
                           class="btn btn-sm btn-primary">
                            <i class="fas fa-plus me-1"></i>Add Product
                        </a>
                        <a href="{{ route('admin.products.index', ['category' => $category->id]) }}"
                           class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-list me-1"></i>View All
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    @if($category->products()->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th width="80">Image</th>
                                        <th>Product Name</th>
                                        <th width="80">Karat</th>
                                        <th width="100">Base Weight</th>
                                        <th width="80">Status</th>
                                        <th width="120">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($category->products()->orderBy('name')->get() as $product)
                                        <tr>
                                            <td>
                                                <img src="{{ $product->image_url }}" alt="{{ $product->name }}"
                                                     class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                            </td>
                                            <td>
                                                <div>
                                                    <strong>{{ $product->name }}</strong>
                                                    @if($product->is_featured)
                                                        <span class="badge bg-warning text-dark ms-2">Featured</span>
                                                    @endif
                                                    <br>
                                                    <small class="text-muted">SKU: {{ $product->sku }}</small>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">{{ $product->karat }}K</span>
                                            </td>
                                            <td>{{ $product->base_weight }}g</td>
                                            <td>
                                                <span class="badge bg-{{ $product->is_active ? 'success' : 'secondary' }}">
                                                    {{ $product->is_active ? 'Active' : 'Inactive' }}
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="{{ route('admin.products.show', $product) }}"
                                                       class="btn btn-sm btn-outline-info" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="{{ route('admin.products.edit', $product) }}"
                                                       class="btn btn-sm btn-outline-primary" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="{{ route('products.show', $product) }}"
                                                       class="btn btn-sm btn-outline-secondary" title="View on Website" target="_blank">
                                                        <i class="fas fa-external-link-alt"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!-- Product Distribution by Karat -->
                        @if($category->products()->count() > 0)
                            <div class="mt-4 p-3 bg-light rounded">
                                <h6 class="fw-bold mb-3">Product Distribution by Karat</h6>
                                <div class="row g-2">
                                    @foreach($category->products()->groupBy('karat') as $karat => $products)
                                        <div class="col-auto">
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="badge bg-primary">{{ $karat }}K</span>
                                                <span class="small">{{ $products->count() }} products</span>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        @endif
                    @else
                        <div class="text-center py-5">
                            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">No Products Yet</h5>
                            <p class="text-muted mb-4">This category doesn't have any products. Start by adding your first product.</p>
                            <a href="{{ route('admin.products.create') }}?category={{ $category->id }}"
                               class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Add First Product
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions Card -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">Quick Actions</h6>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <div class="d-grid">
                                <a href="{{ route('admin.categories.edit', $category) }}"
                                   class="btn btn-outline-primary">
                                    <i class="fas fa-edit me-2"></i>Edit Category
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-grid">
                                <a href="{{ route('admin.products.create') }}?category={{ $category->id }}"
                                   class="btn btn-outline-success">
                                    <i class="fas fa-plus me-2"></i>Add Product
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-grid">
                                <form method="POST" action="{{ route('admin.categories.toggle-status', $category) }}" style="display: inline;">
                                    @csrf
                                    @method('PATCH')
                                    <button type="submit" class="btn btn-outline-{{ $category->is_active ? 'warning' : 'info' }} w-100">
                                        <i class="fas fa-{{ $category->is_active ? 'eye-slash' : 'eye' }} me-2"></i>
                                        {{ $category->is_active ? 'Deactivate' : 'Activate' }}
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-grid">
                                <a href="{{ route('categories.show', $category) }}"
                                   class="btn btn-outline-info" target="_blank">
                                    <i class="fas fa-external-link-alt me-2"></i>View on Website
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Animate statistics on load
    const statCards = document.querySelectorAll('.stat-card h3');
    statCards.forEach(stat => {
        const target = parseInt(stat.textContent);
        animateNumber(stat, 0, target, 1000);
    });

    function animateNumber(element, start, end, duration) {
        const range = end - start;
        const startTime = performance.now();

        const step = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const value = Math.floor(start + (range * progress));

            element.textContent = value;

            if (progress < 1) {
                requestAnimationFrame(step);
            }
        };

        requestAnimationFrame(step);
    }
});
</script>
@endpush
