@extends('layouts.admin')

@section('title', 'Edit Category')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Edit Category</h1>
            <p class="mb-0 text-muted">Modify category: <strong>{{ $category->name }}</strong></p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.categories.show', $category) }}" class="btn btn-info">
                <i class="fas fa-eye me-1"></i> View
            </a>
            <a href="{{ route('admin.categories.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Back to Categories
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Category Information</h6>
                </div>

                <form action="{{ route('admin.categories.update', $category) }}" method="POST" enctype="multipart/form-data" id="categoryForm">
                    @csrf
                    @method('PUT')
                    <div class="card-body">
                        <div class="row">
                            <!-- Category Name -->
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">Category Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror"
                                       id="name" name="name" value="{{ old('name', $category->name) }}" required>
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Slug -->
                            <div class="col-md-6 mb-3">
                                <label for="slug" class="form-label">Slug</label>
                                <input type="text" class="form-control @error('slug') is-invalid @enderror"
                                       id="slug" name="slug" value="{{ old('slug', $category->slug) }}">
                                <div class="form-text">Leave empty to auto-generate from category name</div>
                                @error('slug')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror"
                                      id="description" name="description" rows="4"
                                      placeholder="Enter category description...">{{ old('description', $category->description) }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Current Image Display -->
                        @if($category->image && file_exists(public_path('images/categories/' . $category->image)))
                        <div class="mb-3" id="currentImageSection">
                            <label class="form-label">Current Image</label>
                            <div class="d-flex align-items-center gap-3">
                                <img src="{{ asset('images/categories/' . $category->image) }}" alt="{{ $category->name }}"
                                     class="img-thumbnail category-current-image" style="max-width: 150px; max-height: 150px;">
                                <div>
                                    <p class="mb-1"><strong>{{ basename($category->image) }}</strong></p>
                                    <p class="mb-2 text-muted small">
                                        <i class="fas fa-folder"></i> /public/images/categories/{{ $category->image }}
                                    </p>
                                    <button type="button" class="btn btn-sm btn-outline-danger" id="removeCurrentImage">
                                        <i class="fas fa-trash me-1"></i> Remove Current Image
                                    </button>
                                </div>
                            </div>
                        </div>
                        @endif

                        <!-- Category Image -->
                        <div class="mb-3">
                            <label for="image" class="form-label">
                                {{ $category->image ? 'Replace Image' : 'Category Image' }}
                            </label>
                            <input type="file" class="form-control @error('image') is-invalid @enderror"
                                   id="image" name="image" accept="image/*">
                            <div class="form-text">Upload an image for this category (JPEG, PNG, JPG, GIF, WEBP - Max: 2MB)</div>
                            <div class="form-text text-info">
                                <i class="fas fa-info-circle"></i> Images will be saved to: <code>public/images/categories/</code>
                            </div>
                            @error('image')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror

                            <!-- New Image Preview -->
                            <div id="imagePreview" class="mt-3 d-none">
                                <div class="d-flex align-items-center gap-3">
                                    <img id="previewImg" src="" alt="Preview" class="img-thumbnail" style="max-width: 200px;">
                                    <div>
                                        <button type="button" class="btn btn-sm btn-outline-danger" id="removeImage">
                                            <i class="fas fa-times"></i> Remove
                                        </button>
                                        <div class="mt-2">
                                            <small class="text-muted">Preview of new image</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <!-- Sort Order -->
                            <div class="col-md-4 mb-3">
                                <label for="sort_order" class="form-label">Sort Order</label>
                                <input type="number" class="form-control @error('sort_order') is-invalid @enderror"
                                       id="sort_order" name="sort_order" value="{{ old('sort_order', $category->sort_order) }}"
                                       min="0" max="999">
                                <div class="form-text">Lower numbers appear first</div>
                                @error('sort_order')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <!-- Status -->
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="is_active"
                                           name="is_active" value="1" {{ old('is_active', $category->is_active) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_active">
                                        Active
                                    </label>
                                </div>
                                <div class="form-text">Only active categories are visible to customers</div>
                            </div>

                            <!-- Featured -->
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Featured</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="is_featured"
                                           name="is_featured" value="1" {{ old('is_featured', $category->is_featured) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_featured">
                                        Featured Category
                                    </label>
                                </div>
                                <div class="form-text">Featured categories appear prominently</div>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="d-flex justify-content-between">
                            <div>
                                <a href="{{ route('admin.categories.index') }}" class="btn btn-secondary">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </a>
                                <button type="button" class="btn btn-info ms-2" onclick="duplicateCategory()">
                                    <i class="fas fa-copy me-1"></i> Duplicate
                                </button>
                            </div>
                            <div>
                                @if($category->canBeDeleted())
                                <button type="button" class="btn btn-danger me-2" onclick="deleteCategory()">
                                    <i class="fas fa-trash me-1"></i> Delete
                                </button>
                                @endif
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Update Category
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- SEO Settings -->
        <div class="col-lg-4">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">SEO Settings</h6>
                </div>
                <div class="card-body">
                    <!-- Meta Title -->
                    <div class="mb-3">
                        <label for="meta_title" class="form-label">Meta Title</label>
                        <input type="text" class="form-control @error('meta_title') is-invalid @enderror"
                               id="meta_title" name="meta_title" value="{{ old('meta_title', $category->meta_title) }}"
                               maxlength="200" form="categoryForm">
                        <div class="form-text">
                            <span id="titleCount">0</span>/200 characters
                        </div>
                        @error('meta_title')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- Meta Description -->
                    <div class="mb-3">
                        <label for="meta_description" class="form-label">Meta Description</label>
                        <textarea class="form-control @error('meta_description') is-invalid @enderror"
                                  id="meta_description" name="meta_description" rows="4"
                                  maxlength="300" form="categoryForm">{{ old('meta_description', $category->meta_description) }}</textarea>
                        <div class="form-text">
                            <span id="descCount">0</span>/300 characters
                        </div>
                        @error('meta_description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- URL Preview -->
                    <div class="mb-3">
                        <label class="form-label">URL Preview</label>
                        <div class="p-2 bg-light rounded">
                            <small class="text-muted">
                                {{ url('/categories') }}/<span id="slugPreview">{{ $category->slug }}</span>
                            </small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category Stats -->
            <div class="card shadow mt-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-chart-bar me-1"></i> Category Statistics
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="h4 mb-0 text-success">{{ $category->active_products_count ?? 0 }}</div>
                            <div class="small text-muted">Active Products</div>
                        </div>
                        <div class="col-6">
                            <div class="h4 mb-0 text-info">{{ $category->products_count ?? 0 }}</div>
                            <div class="small text-muted">Total Products</div>
                        </div>
                    </div>
                    <hr>
                    <div class="small">
                        <p><strong>Created:</strong> {{ $category->created_at->format('M d, Y H:i') }}</p>
                        <p><strong>Updated:</strong> {{ $category->updated_at->format('M d, Y H:i') }}</p>
                        <p><strong>Status:</strong>
                            <span class="badge {{ $category->is_active ? 'bg-success' : 'bg-secondary' }}">
                                {{ $category->is_active ? 'Active' : 'Inactive' }}
                            </span>
                        </p>
                        @if($category->is_featured)
                        <p><strong>Featured:</strong>
                            <span class="badge bg-warning"><i class="fas fa-star"></i> Featured</span>
                        </p>
                        @endif
                        @if($category->image)
                        <p><strong>Image:</strong>
                            <span class="badge bg-info">{{ $category->image }}</span>
                        </p>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Actions -->
            <div class="card shadow mt-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-cog me-1"></i> Quick Actions
                    </h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="{{ route('categories.show', $category->slug) }}"
                           class="btn btn-outline-primary btn-sm" target="_blank">
                            <i class="fas fa-external-link-alt me-1"></i> View on Frontend
                        </a>

                        <button type="button" class="btn btn-outline-info btn-sm" onclick="toggleStatus()">
                            <i class="fas {{ $category->is_active ? 'fa-eye-slash' : 'fa-eye' }} me-1"></i>
                            {{ $category->is_active ? 'Deactivate' : 'Activate' }}
                        </button>

                        <button type="button" class="btn btn-outline-warning btn-sm" onclick="toggleFeature()">
                            <i class="fas fa-star me-1"></i>
                            {{ $category->is_featured ? 'Unfeature' : 'Feature' }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the category <strong>{{ $category->name }}</strong>?</p>
                @if($category->products_count > 0)
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-1"></i>
                        This category has {{ $category->products_count }} products. You cannot delete it until all products are moved to other categories or deleted.
                    </div>
                @else
                    <p class="text-muted small">This action cannot be undone.</p>
                @endif
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                @if($category->canBeDeleted())
                <form action="{{ route('admin.categories.destroy', $category) }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete Category</button>
                </form>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Hidden form for duplicate action -->
<form id="duplicateForm" action="{{ route('admin.categories.duplicate', $category) }}" method="POST" style="display: none;">
    @csrf
</form>
@endsection

@push('styles')
<style>
.form-check-input:checked {
    background-color: #4e73df;
    border-color: #4e73df;
}

.card {
    border: 1px solid #e3e6f0;
}

.card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}

.text-gray-800 {
    color: #5a5c69!important;
}

.img-thumbnail {
    border: 1px solid #e3e6f0;
}

.category-current-image {
    transition: transform 0.2s ease;
}

.category-current-image:hover {
    transform: scale(1.05);
}

.border-end {
    border-right: 1px solid #e3e6f0!important;
}
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const slugInput = document.getElementById('slug');
    const slugPreview = document.getElementById('slugPreview');
    const imageInput = document.getElementById('image');
    const imagePreview = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');
    const removeImageBtn = document.getElementById('removeImage');
    const removeCurrentImageBtn = document.getElementById('removeCurrentImage');
    const metaTitleInput = document.getElementById('meta_title');
    const metaDescInput = document.getElementById('meta_description');
    const titleCount = document.getElementById('titleCount');
    const descCount = document.getElementById('descCount');

    // Auto-generate slug from name (only if slug is empty or auto-generated)
    nameInput.addEventListener('input', function() {
        if (!slugInput.value || slugInput.dataset.autoGenerated) {
            const slug = generateSlug(this.value);
            slugInput.value = slug;
            slugInput.dataset.autoGenerated = 'true';
            updateSlugPreview(slug);
        }
    });

    // Manual slug editing
    slugInput.addEventListener('input', function() {
        if (this.value) {
            this.dataset.autoGenerated = 'false';
        }
        updateSlugPreview(this.value);
    });

    // Character counting
    metaTitleInput.addEventListener('input', function() {
        updateCharCount(this, titleCount);
    });

    metaDescInput.addEventListener('input', function() {
        updateCharCount(this, descCount);
    });

    // Image preview
    imageInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            // Validate file type
            const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            if (!validTypes.includes(file.type)) {
                alert('Please select a valid image file (JPEG, PNG, JPG, GIF, WEBP)');
                this.value = '';
                return;
            }

            // Validate file size (2MB max)
            if (file.size > 2 * 1024 * 1024) {
                alert('File size must be less than 2MB');
                this.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                imagePreview.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        }
    });

    // Remove new image
    removeImageBtn?.addEventListener('click', function() {
        imageInput.value = '';
        imagePreview.classList.add('d-none');
        previewImg.src = '';
    });

    // Remove current image
    removeCurrentImageBtn?.addEventListener('click', function() {
        if (confirm('Are you sure you want to remove the current image?')) {
            // Add a hidden input to indicate image removal
            const removeInput = document.createElement('input');
            removeInput.type = 'hidden';
            removeInput.name = 'remove_image';
            removeInput.value = '1';
            document.getElementById('categoryForm').appendChild(removeInput);

            // Hide the current image display
            document.getElementById('currentImageSection').style.display = 'none';

            // Update the image label
            document.querySelector('label[for="image"]').textContent = 'Category Image';
        }
    });

    // Helper functions
    function generateSlug(text) {
        return text
            .toLowerCase()
            .replace(/[^a-z0-9 -]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .trim('-');
    }

    function updateSlugPreview(slug) {
        slugPreview.textContent = slug || 'category-name';
    }

    function updateCharCount(input, counter) {
        counter.textContent = input.value.length;
        if (input.value.length > input.maxLength * 0.9) {
            counter.classList.add('text-warning');
        } else {
            counter.classList.remove('text-warning');
        }
    }

    // Initialize character counts
    updateCharCount(metaTitleInput, titleCount);
    updateCharCount(metaDescInput, descCount);

    // Initialize slug preview
    updateSlugPreview(slugInput.value);
});

// Global functions for buttons
function deleteCategory() {
    new bootstrap.Modal(document.getElementById('deleteModal')).show();
}

function duplicateCategory() {
    if (confirm('Are you sure you want to duplicate this category?')) {
        document.getElementById('duplicateForm').submit();
    }
}

function toggleStatus() {
    fetch(`/admin/categories/{{ $category->id }}/toggle-status`, {
        method: 'PATCH',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Failed to update status');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred');
    });
}

function toggleFeature() {
    fetch(`/admin/categories/{{ $category->id }}/toggle-feature`, {
        method: 'PATCH',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Failed to update feature status');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred');
    });
}
</script>
@endpush
