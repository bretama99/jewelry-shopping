@extends('layouts.admin')

@section('title', 'Category Details')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Category Details</h1>
            <p class="mb-0 text-muted">{{ $category->name }}</p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('categories.show', $category->slug) }}"
               class="btn btn-outline-primary" target="_blank">
                <i class="fas fa-external-link-alt me-1"></i> View on Site
            </a>
            <a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i> Edit Category
            </a>
            <a href="{{ route('categories.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Back to Categories
            </a>
        </div>
    </div>

    <div class="row">
        <!-- Category Information -->
        <div class="col-lg-8">
            <!-- Basic Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Basic Information</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <td width="120"><strong>Name:</strong></td>
                                        <td>{{ $category->name }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Slug:</strong></td>
                                        <td>
                                            <code>{{ $category->slug }}</code>
                                            <small class="text-muted ms-2">
                                                {{ url('/categories/' . $category->slug) }}
                                            </small>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Description:</strong></td>
                                        <td>
                                            @if($category->description)
                                                {{ $category->description }}
                                            @else
                                                <em class="text-muted">No description provided</em>
                                            @endif
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Sort Order:</strong></td>
                                        <td>{{ $category->sort_order }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td>
                                            <span class="badge {{ $category->is_active ? 'bg-success' : 'bg-secondary' }}">
                                                {{ $category->is_active ? 'Active' : 'Inactive' }}
                                            </span>
                                            @if($category->is_featured)
                                                <span class="badge bg-warning ms-1">
                                                    <i class="fas fa-star"></i> Featured
                                                </span>
                                            @endif
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Created:</strong></td>
                                        <td>{{ $category->created_at->format('M d, Y H:i:s') }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Updated:</strong></td>
                                        <td>{{ $category->updated_at->format('M d, Y H:i:s') }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-4 text-center">
                            @if($category->image)
                                <img src="{{ $category->image_url }}"
                                     alt="{{ $category->name }}"
                                     class="img-thumbnail mb-3"
                                     style="max-width: 200px; max-height: 200px;">
                                <br>
                                <small class="text-muted">{{ basename($category->image) }}</small>
                            @else
                                <div class="bg-light rounded d-flex align-items-center justify-content-center mb-3"
                                     style="width: 200px; height: 200px; margin: 0 auto;">
                                    <div class="text-center">
                                        <i class="fas fa-image fa-3x text-muted mb-2"></i>
                                        <br>
                                        <small class="text-muted">No image</small>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <!-- SEO Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">SEO Information</h6>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tbody>
                            <tr>
                                <td width="120"><strong>Meta Title:</strong></td>
                                <td>
                                    @if($category->meta_title)
                                        {{ $category->meta_title }}
                                        <small class="text-muted">({{ strlen($category->meta_title) }} characters)</small>
                                    @else
                                        <em class="text-muted">Using category name: {{ $category->name }}</em>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Meta Description:</strong></td>
                                <td>
                                    @if($category->meta_description)
                                        {{ $category->meta_description }}
                                        <small class="text-muted">({{ strlen($category->meta_description) }} characters)</small>
                                    @else
                                        <em class="text-muted">
                                            @if($category->description)
                                                Using category description (truncated)
                                            @else
                                                No meta description set
                                            @endif
                                        </em>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <td><strong>URL:</strong></td>
                                <td>
                                    <a href="{{ route('categories.show', $category->slug) }}" target="_blank">
                                        {{ route('categories.show', $category->slug) }}
                                        <i class="fas fa-external-link-alt ms-1"></i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Products in Category -->
            <div class="card shadow">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Products in Category</h6>
                    <a href="{{ route('admin.products.index', ['category' => $category->id]) }}"
                       class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-plus me-1"></i> Add Product
                    </a>
                </div>
                <div class="card-body">
                    @if($category->products->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Product</th>
                                        <th>SKU</th>
                                        <th>Karat</th>
                                        <th>Status</th>
                                        <th>Orders</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($category->products->take(10) as $product)
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    @if($product->image)
                                                        <img src="{{ $product->image_url }}"
                                                             alt="{{ $product->name }}"
                                                             class="me-2 rounded"
                                                             style="width: 40px; height: 40px; object-fit: cover;">
                                                    @else
                                                        <div class="bg-light rounded me-2 d-flex align-items-center justify-content-center"
                                                             style="width: 40px; height: 40px;">
                                                            <i class="fas fa-gem text-muted"></i>
                                                        </div>
                                                    @endif
                                                    <div>
                                                        <strong>{{ $product->name }}</strong>
                                                        @if($product->is_featured)
                                                            <i class="fas fa-star text-warning ms-1" title="Featured"></i>
                                                        @endif
                                                    </div>
                                                </div>
                                            </td>
                                            <td><code>{{ $product->sku ?? 'N/A' }}</code></td>
                                            <td>{{ $product->karat ?? 'N/A' }}K</td>
                                            <td>
                                                <span class="badge {{ $product->is_active ? 'bg-success' : 'bg-secondary' }}">
                                                    {{ $product->is_active ? 'Active' : 'Inactive' }}
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info">
                                                    {{ $product->order_items_count ?? 0 }}
                                                </span>
                                            </td>
                                            <td>
                                                <small class="text-muted">
                                                    {{ $product->created_at->format('M d, Y') }}
                                                </small>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="{{ route('admin.products.show', $product) }}"
                                                       class="btn btn-outline-primary" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="{{ route('admin.products.edit', $product) }}"
                                                       class="btn btn-outline-secondary" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        @if($category->products->count() > 10)
                            <div class="text-center mt-3">
                                <a href="{{ route('admin.products.index', ['category' => $category->id]) }}"
                                   class="btn btn-outline-primary">
                                    View All {{ $category->products->count() }} Products
                                </a>
                            </div>
                        @endif
                    @else
                        <div class="text-center py-4">
                            <i class="fas fa-gem fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">No products in this category</h5>
                            <p class="text-muted">Start by adding some products to this category.</p>
                            <a href="{{ route('admin.products.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus me-1"></i> Add First Product
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Quick Stats -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-chart-bar me-1"></i> Statistics
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-6 mb-3">
                            <div class="border-end">
                                <div class="h3 mb-0 text-primary">{{ $category->products->count() }}</div>
                                <div class="small text-muted">Total Products</div>
                            </div>
                        </div>
                        <div class="col-6 mb-3">
                            <div class="h3 mb-0 text-success">{{ $category->products->where('is_active', true)->count() }}</div>
                            <div class="small text-muted">Active Products</div>
                        </div>
                        <div class="col-6">
                            <div class="border-end">
                                <div class="h3 mb-0 text-warning">{{ $category->products->where('is_featured', true)->count() }}</div>
                                <div class="small text-muted">Featured</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="h3 mb-0 text-info">{{ $category->products->sum('order_items_count') ?? 0 }}</div>
                            <div class="small text-muted">Total Orders</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-bolt me-1"></i> Quick Actions
                    </h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-primary">
                            <i class="fas fa-edit me-1"></i> Edit Category
                        </a>

                        <button type="button" class="btn btn-outline-info" onclick="toggleStatus()">
                            <i class="fas {{ $category->is_active ? 'fa-eye-slash' : 'fa-eye' }} me-1"></i>
                            {{ $category->is_active ? 'Deactivate' : 'Activate' }}
                        </button>

                        <button type="button" class="btn btn-outline-warning" onclick="toggleFeature()">
                            <i class="fas fa-star me-1"></i>
                            {{ $category->is_featured ? 'Unfeature' : 'Feature' }}
                        </button>

                        <a href="{{ route('admin.categories.duplicate', $category) }}"
                           class="btn btn-outline-secondary"
                           onclick="return confirm('Duplicate this category?')">
                            <i class="fas fa-copy me-1"></i> Duplicate
                        </a>

                        <hr>

                        @if($category->canBeDeleted())
                        <button type="button" class="btn btn-outline-danger" onclick="deleteCategory()">
                            <i class="fas fa-trash me-1"></i> Delete Category
                        </button>
                        @else
                        <button type="button" class="btn btn-outline-danger" disabled
                                title="Cannot delete category with products">
                            <i class="fas fa-trash me-1"></i> Delete Category
                        </button>
                        <small class="text-muted">Remove all products first to delete this category.</small>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Category Navigation -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-sitemap me-1"></i> Category Navigation
                    </h6>
                </div>
                <div class="card-body">
                    @php
                        $prevCategory = \App\Models\Category::where('sort_order', '<', $category->sort_order)
                                                           ->orderBy('sort_order', 'desc')
                                                           ->first();
                        $nextCategory = \App\Models\Category::where('sort_order', '>', $category->sort_order)
                                                           ->orderBy('sort_order', 'asc')
                                                           ->first();
                    @endphp

                    <div class="d-flex justify-content-between">
                        @if($prevCategory)
                            <a href="{{ route('admin.categories.show', $prevCategory) }}"
                               class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-chevron-left me-1"></i> {{ Str::limit($prevCategory->name, 15) }}
                            </a>
                        @else
                            <span></span>
                        @endif

                        @if($nextCategory)
                            <a href="{{ route('admin.categories.show', $nextCategory) }}"
                               class="btn btn-sm btn-outline-primary">
                                {{ Str::limit($nextCategory->name, 15) }} <i class="fas fa-chevron-right ms-1"></i>
                            </a>
                        @endif
                    </div>

                    <div class="text-center mt-3">
                        <a href="{{ route('categories.index') }}" class="btn btn-sm btn-secondary">
                            <i class="fas fa-list me-1"></i> All Categories
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the category <strong>{{ $category->name }}</strong>?</p>
                <p class="text-muted small">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form action="{{ route('admin.categories.destroy', $category) }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete Category</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
.border-end {
    border-right: 1px solid #e3e6f0!important;
}

.text-gray-800 {
    color: #5a5c69!important;
}

.card {
    border: 1px solid #e3e6f0;
}

.card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}
</style>
@endpush

@push('scripts')
<script>
function deleteCategory() {
    new bootstrap.Modal(document.getElementById('deleteModal')).show();
}

function toggleStatus() {
    fetch(`/admin/categories/{{ $category->id }}/toggle-status`, {
        method: 'PATCH',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Failed to update status');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred');
    });
}

function toggleFeature() {
    fetch(`/admin/categories/{{ $category->id }}/toggle-feature`, {
        method: 'PATCH',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Failed to update feature status');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred');
    });
}
</script>
@endpush
