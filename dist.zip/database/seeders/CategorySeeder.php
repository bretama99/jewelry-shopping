<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Rings',
                'slug' => 'rings',
                'description' => 'Elegant rings crafted from finest gold in various karats. Perfect for engagements, weddings, or everyday wear. From simple bands to intricate designs with precious stones.',
                'meta_title' => 'Gold Rings Collection - Engagement & Wedding Rings',
                'meta_description' => 'Shop our exquisite collection of gold rings including engagement rings, wedding bands, and fashion rings. Available in 10K, 14K, 18K, and 22K gold.',
                'sort_order' => 1,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Necklaces',
                'slug' => 'necklaces',
                'description' => 'Beautiful necklaces featuring intricate designs and premium gold craftsmanship. From delicate chains to statement pieces that enhance your natural beauty.',
                'meta_title' => 'Gold Necklaces - Elegant Jewelry Collection',
                'meta_description' => 'Discover our stunning gold necklace collection featuring chains, pendants, and statement pieces in various gold purities.',
                'sort_order' => 2,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Bracelets',
                'slug' => 'bracelets',
                'description' => 'Stunning bracelets that add elegance and sophistication to any outfit. Choose from tennis bracelets, bangles, and charm bracelets.',
                'meta_title' => 'Gold Bracelets - Luxury Jewelry Collection',
                'meta_description' => 'Browse our premium gold bracelet collection including tennis bracelets, bangles, and charm bracelets in various gold karats.',
                'sort_order' => 3,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Earrings',
                'slug' => 'earrings',
                'description' => 'Exquisite earrings in various styles from subtle studs to statement pieces. Perfect for any occasion, designed to complement your unique style.',
                'meta_title' => 'Gold Earrings - Studs, Hoops & Drop Earrings',
                'meta_description' => 'Shop our beautiful gold earring collection featuring studs, hoops, drop earrings, and chandelier styles in premium gold.',
                'sort_order' => 4,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'name' => 'Chains',
                'slug' => 'chains',
                'description' => 'Gold chains in different weights and styles for men and women. From delicate feminine chains to bold masculine designs.',
                'meta_title' => 'Gold Chains - Jewelry for Men & Women',
                'meta_description' => 'Explore our gold chain collection featuring various styles and weights. Perfect for layering or wearing alone.',
                'sort_order' => 5,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'name' => 'Anklets',
                'slug' => 'anklets',
                'description' => 'Delicate anklets that add a touch of glamour to your style. Perfect for summer and special occasions, crafted with attention to detail.',
                'meta_title' => 'Gold Anklets - Delicate Ankle Jewelry',
                'meta_description' => 'Add elegance to your look with our gold anklet collection. Delicate designs perfect for any occasion.',
                'sort_order' => 6,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'name' => 'Wedding Sets',
                'slug' => 'wedding-sets',
                'description' => 'Complete wedding jewelry sets for your special day. Coordinated pieces including necklaces, earrings, and bracelets for the bride.',
                'meta_title' => 'Wedding Jewelry Sets - Bridal Gold Collection',
                'meta_description' => 'Complete your bridal look with our wedding jewelry sets. Matching gold pieces for your perfect wedding day.',
                'sort_order' => 7,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Pendants',
                'slug' => 'pendants',
                'description' => 'Beautiful pendants and charms for personalized jewelry. Express your personality with our diverse collection of meaningful designs.',
                'meta_title' => 'Gold Pendants & Charms - Personalized Jewelry',
                'meta_description' => 'Discover our gold pendant collection featuring religious symbols, initials, and decorative designs in various gold purities.',
                'sort_order' => 8,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'name' => 'Men\'s Jewelry',
                'slug' => 'mens-jewelry',
                'description' => 'Sophisticated jewelry designed specifically for men. Including rings, chains, bracelets, and cufflinks in masculine designs.',
                'meta_title' => 'Men\'s Gold Jewelry - Rings, Chains & Bracelets',
                'meta_description' => 'Shop our men\'s gold jewelry collection featuring rings, chains, bracelets, and accessories designed for the modern man.',
                'sort_order' => 9,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Custom Jewelry',
                'slug' => 'custom-jewelry',
                'description' => 'Bespoke jewelry crafted to your specifications. Work with our artisans to create unique pieces that reflect your personal style and story.',
                'meta_title' => 'Custom Gold Jewelry - Bespoke Design Services',
                'meta_description' => 'Create your dream jewelry piece with our custom design services. Personalized gold jewelry crafted to perfection.',
                'sort_order' => 10,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];

        foreach ($categories as $categoryData) {
            // Check if category already exists to prevent duplicates
            if (!Category::where('slug', $categoryData['slug'])->exists()) {
                Category::create($categoryData);
                $this->command->info("Created category: {$categoryData['name']}");
            } else {
                $this->command->warn("Category already exists: {$categoryData['name']}");
            }
        }

        // Update featured categories randomly if none are featured
        $featuredCount = Category::where('is_featured', true)->count();
        if ($featuredCount === 0) {
            Category::inRandomOrder()->limit(4)->update(['is_featured' => true]);
            $this->command->info('Updated random categories to featured status.');
        }

        $this->command->info('Categories seeded successfully!');
        $this->command->info('Total categories: ' . Category::count());
        $this->command->info('Featured categories: ' . Category::where('is_featured', true)->count());
    }
}
