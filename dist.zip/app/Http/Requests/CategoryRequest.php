<?php
// app/Http/Requests/CategoryRequest.php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CategoryRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $categoryId = $this->route('category') ? $this->route('category')->id : null;

        return [
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique('categories')->ignore($categoryId)
            ],
            'slug' => [
                'nullable',
                'string',
                'max:120',
                'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/',
                Rule::unique('categories')->ignore($categoryId)
            ],
            'description' => 'nullable|string|max:2000',
            'image' => [
                'nullable',
                'image',
                'mimes:jpeg,png,jpg,gif,webp',
                'max:2048', // 2MB max
                'dimensions:min_width=100,min_height=100,max_width=2000,max_height=2000'
            ],
            'is_active' => 'sometimes|boolean',
            'is_featured' => 'sometimes|boolean',
            'sort_order' => 'nullable|integer|min:0|max:9999',
            'meta_title' => 'nullable|string|max:200',
            'meta_description' => 'nullable|string|max:300',
            'remove_image' => 'sometimes|boolean'
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'Category name is required.',
            'name.max' => 'Category name cannot exceed 100 characters.',
            'name.unique' => 'A category with this name already exists.',

            'slug.max' => 'Slug cannot exceed 120 characters.',
            'slug.regex' => 'Slug can only contain lowercase letters, numbers, and hyphens.',
            'slug.unique' => 'This slug is already taken.',

            'description.max' => 'Description cannot exceed 2000 characters.',

            'image.image' => 'The file must be an image.',
            'image.mimes' => 'Image must be a JPEG, PNG, JPG, GIF, or WEBP file.',
            'image.max' => 'Image size cannot exceed 2MB.',
            'image.dimensions' => 'Image must be between 100x100 and 2000x2000 pixels.',

            'sort_order.integer' => 'Sort order must be a number.',
            'sort_order.min' => 'Sort order cannot be negative.',
            'sort_order.max' => 'Sort order cannot exceed 9999.',

            'meta_title.max' => 'Meta title cannot exceed 200 characters.',
            'meta_description.max' => 'Meta description cannot exceed 300 characters.',
        ];
    }

    public function attributes()
    {
        return [
            'name' => 'category name',
            'slug' => 'URL slug',
            'description' => 'category description',
            'image' => 'category image',
            'is_active' => 'active status',
            'is_featured' => 'featured status',
            'sort_order' => 'sort order',
            'meta_title' => 'meta title',
            'meta_description' => 'meta description',
        ];
    }

    protected function prepareForValidation()
    {
        // Convert checkbox values to boolean
        $this->merge([
            'is_active' => $this->has('is_active') ? $this->boolean('is_active') : false,
            'is_featured' => $this->has('is_featured') ? $this->boolean('is_featured') : false,
            'sort_order' => $this->filled('sort_order') ? (int) $this->sort_order : 0,
            'remove_image' => $this->boolean('remove_image', false),
        ]);

        // Clean up slug if provided
        if ($this->filled('slug')) {
            $this->merge([
                'slug' => strtolower(trim($this->slug))
            ]);
        }

        // Trim text fields
        if ($this->filled('name')) {
            $this->merge(['name' => trim($this->name)]);
        }

        if ($this->filled('description')) {
            $this->merge(['description' => trim($this->description)]);
        }

        if ($this->filled('meta_title')) {
            $this->merge(['meta_title' => trim($this->meta_title)]);
        }

        if ($this->filled('meta_description')) {
            $this->merge(['meta_description' => trim($this->meta_description)]);
        }
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            // Additional validation rules

            // If slug is provided, ensure it's properly formatted
            if ($this->filled('slug')) {
                $slug = $this->get('slug');
                if (str_starts_with($slug, '-') || str_ends_with($slug, '-')) {
                    $validator->errors()->add('slug', 'Slug cannot start or end with a hyphen.');
                }

                if (str_contains($slug, '--')) {
                    $validator->errors()->add('slug', 'Slug cannot contain consecutive hyphens.');
                }
            }

            // Validate meta title isn't just the name repeated
            if ($this->filled('meta_title') && $this->filled('name')) {
                if (strtolower($this->get('meta_title')) === strtolower($this->get('name'))) {
                    $validator->errors()->add('meta_title', 'Meta title should be different from the category name for better SEO.');
                }
            }

            // Validate description length for readability
            if ($this->filled('description')) {
                $wordCount = str_word_count($this->get('description'));
                if ($wordCount < 5) {
                    $validator->errors()->add('description', 'Description should contain at least 5 words for better content quality.');
                }
            }
        });
    }

    /**
     * Get the validated data with processed values
     */
    public function getProcessedData()
    {
        $data = $this->validated();

        // Remove remove_image from the final data as it's handled separately
        unset($data['remove_image']);

        // Generate slug if not provided and name is available
        if (empty($data['slug']) && !empty($data['name'])) {
            $data['slug'] = \Illuminate\Support\Str::slug($data['name']);
        }

        return $data;
    }
}
