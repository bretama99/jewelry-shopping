<?php
// app/Http/Controllers/Admin/CategoryController.php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Models\Category;
use App\Services\CategoryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    protected $categoryService;

    public function __construct(CategoryService $categoryService)
    {
        $this->categoryService = $categoryService;
    }

    public function index(Request $request)
    {
        $filters = $request->only(['search', 'status', 'featured', 'sort', 'view']);
        $categories = $this->categoryService->getAllCategories($filters);
        $stats = $this->categoryService->getStats();

        return view('admin.categories.index', compact('categories', 'stats', 'filters'));
    }

    public function create()
    {
        return view('admin.categories.create');
    }

    public function store(CategoryRequest $request)
    {
        try {
            $data = $request->validated();

            // Handle image upload
            if ($request->hasFile('image')) {
                $data['image'] = $this->handleImageUpload($request->file('image'));
            }

            $category = $this->categoryService->createCategory($data);

            return redirect()
                ->route('admin.categories.index')
                ->with('success', 'Category created successfully.');
        } catch (\Exception $e) {
            return back()
                ->withInput()
                ->with('error', 'Error creating category: ' . $e->getMessage());
        }
    }

    public function show(Category $category)
    {
        $category->load(['products' => function ($query) {
            $query->orderBy('name')->take(10);
        }]);

        return view('admin.categories.show', compact('category'));
    }

    public function edit(Category $category)
    {
        return view('admin.categories.edit', compact('category'));
    }

    public function update(CategoryRequest $request, Category $category)
    {
        try {
            $data = $request->validated();

            // Handle image removal
            if ($request->has('remove_image') && $request->remove_image) {
                if ($category->image) {
                    $this->deleteImage($category->image);
                    $data['image'] = null;
                }
            }

            // Handle new image upload
            if ($request->hasFile('image')) {
                // Delete old image if exists
                if ($category->image) {
                    $this->deleteImage($category->image);
                }

                $data['image'] = $this->handleImageUpload($request->file('image'));
            }

            $this->categoryService->updateCategory($category, $data);

            return redirect()
                ->route('admin.categories.index')
                ->with('success', 'Category updated successfully.');
        } catch (\Exception $e) {
            return back()
                ->withInput()
                ->with('error', 'Error updating category: ' . $e->getMessage());
        }
    }

    public function destroy(Category $category)
    {
        try {
            // Delete associated image before deleting category
            if ($category->image) {
                $this->deleteImage($category->image);
            }

            $this->categoryService->deleteCategory($category);

            if (request()->wantsJson()) {
                return response()->json(['success' => true]);
            }

            return redirect()
                ->route('admin.categories.index')
                ->with('success', 'Category deleted successfully.');
        } catch (\Exception $e) {
            if (request()->wantsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }

            return back()->with('error', $e->getMessage());
        }
    }

    public function toggleStatus(Category $category)
    {
        try {
            $this->categoryService->toggleStatus($category);

            if (request()->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'is_active' => $category->is_active,
                    'message' => 'Status updated successfully.'
                ]);
            }

            return back()->with('success', 'Category status updated successfully.');
        } catch (\Exception $e) {
            if (request()->wantsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }

            return back()->with('error', 'Error updating status.');
        }
    }

    public function toggleFeature(Category $category)
    {
        try {
            $this->categoryService->toggleFeature($category);

            if (request()->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'is_featured' => $category->is_featured,
                    'message' => 'Featured status updated successfully.'
                ]);
            }

            return back()->with('success', 'Featured status updated successfully.');
        } catch (\Exception $e) {
            if (request()->wantsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }

            return back()->with('error', 'Error updating featured status.');
        }
    }

    public function duplicate(Category $category)
    {
        try {
            // Handle image duplication
            $duplicatedImage = null;
            if ($category->image) {
                $duplicatedImage = $this->duplicateImage($category->image);
            }

            $newCategory = $this->categoryService->duplicateCategory($category);

            // Update with duplicated image
            if ($duplicatedImage) {
                $newCategory->update(['image' => $duplicatedImage]);
            }

            if (request()->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Category duplicated successfully.',
                    'redirect' => route('admin.categories.edit', $newCategory)
                ]);
            }

            return redirect()
                ->route('admin.categories.edit', $newCategory)
                ->with('success', 'Category duplicated successfully. Please review and update as needed.');
        } catch (\Exception $e) {
            if (request()->wantsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }

            return back()->with('error', 'Error duplicating category.');
        }
    }

    public function bulkAction(Request $request)
    {
        $request->validate([
            'action' => 'required|in:activate,deactivate,feature,unfeature,delete',
            'category_ids' => 'required|array|min:1',
            'category_ids.*' => 'exists:categories,id'
        ]);

        try {
            // Handle bulk delete with image deletion
            if ($request->action === 'delete') {
                $categories = Category::whereIn('id', $request->category_ids)->get();

                foreach ($categories as $category) {
                    // Only delete if no products
                    if ($category->products()->count() === 0) {
                        if ($category->image) {
                            $this->deleteImage($category->image);
                        }
                    }
                }
            }

            $this->categoryService->bulkAction($request->category_ids, $request->action);

            $actionName = str_replace('_', ' ', $request->action);
            return response()->json([
                'success' => true,
                'message' => "Successfully {$actionName}d " . count($request->category_ids) . " category(s)."
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error performing bulk action: ' . $e->getMessage()
            ]);
        }
    }

    public function export(Request $request)
    {
        $filters = $request->only(['search', 'status', 'featured']);
        // Implementation for CSV/Excel export
        // You can use Laravel Excel package for this

        return response()->json(['message' => 'Export functionality to be implemented']);
    }

    /**
     * Handle image upload to categories folder
     */
    private function handleImageUpload($file)
    {
        // Create categories directory if it doesn't exist
        $categoriesPath = public_path('images/categories');
        if (!File::exists($categoriesPath)) {
            File::makeDirectory($categoriesPath, 0755, true);
        }

        // Generate unique filename
        $filename = time() . '_' . Str::random(10) . '.' . $file->getClientOriginalExtension();

        // Move file to categories directory
        $file->move($categoriesPath, $filename);

        return $filename;
    }

    /**
     * Delete image from categories folder
     */
    private function deleteImage($filename)
    {
        if ($filename) {
            $imagePath = public_path('images/categories/' . $filename);
            if (File::exists($imagePath)) {
                File::delete($imagePath);
            }
        }
    }

    /**
     * Duplicate image file for category duplication
     */
    private function duplicateImage($originalFilename)
    {
        $originalPath = public_path('images/categories/' . $originalFilename);

        if (!File::exists($originalPath)) {
            return null;
        }

        // Generate new filename
        $extension = pathinfo($originalFilename, PATHINFO_EXTENSION);
        $newFilename = time() . '_' . Str::random(10) . '.' . $extension;
        $newPath = public_path('images/categories/' . $newFilename);

        // Copy the file
        if (File::copy($originalPath, $newPath)) {
            return $newFilename;
        }

        return null;
    }
}
