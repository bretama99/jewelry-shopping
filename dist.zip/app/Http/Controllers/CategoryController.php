<?php
// File: app/Http/Controllers/CategoryController.php - Updated for Dynamic Categories
namespace App\Http\Controllers;

use App\Models\MetalCategory;
use App\Models\Subcategory;
use App\Models\Product;
use App\Services\MetalPriceApiService;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    protected $metalPriceService;

    public function __construct(MetalPriceApiService $metalPriceService)
    {
        $this->metalPriceService = $metalPriceService;
    }

    /**
     * Display all metal categories
     */
    public function index()
    {
        $metalCategories = MetalCategory::where('is_active', true)
            ->withCount(['products' => function ($query) {
                $query->where('is_active', true);
            }])
            ->orderBy('sort_order')
            ->get();

        // Get live prices for each metal
        foreach ($metalCategories as $category) {
            $priceData = $this->metalPriceService->getCurrentPrice($category->symbol);
            $category->current_price = $priceData['success'] ? $priceData['price'] : null;
            $category->price_updated = $priceData['success'] ? $priceData['last_updated'] : null;
        }

        return view('categories.index', compact('metalCategories'));
    }

    /**
     * Display products for a specific metal category
     */
    public function showMetal(Request $request, $metalSlug)
    {
        $metalCategory = MetalCategory::where('slug', $metalSlug)
            ->where('is_active', true)
            ->firstOrFail();

        $query = Product::with(['subcategory'])
            ->where('metal_category_id', $metalCategory->id)
            ->where('is_active', true);

        // Apply subcategory filter
        if ($request->has('subcategory') && $request->subcategory) {
            $query->whereHas('subcategory', function ($q) use ($request) {
                $q->where('slug', $request->subcategory);
            });
        }

        // Apply karat filter
        if ($request->has('karat') && $request->karat) {
            $query->where('karat', $request->karat);
        }

        // Search within metal category
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Sorting
        $sort = $request->get('sort', 'featured');
        switch ($sort) {
            case 'price_low':
                $query->orderBy('weight', 'asc'); // Simplified
                break;
            case 'price_high':
                $query->orderBy('weight', 'desc'); // Simplified
                break;
            case 'newest':
                $query->orderBy('created_at', 'desc');
                break;
            case 'name':
                $query->orderBy('name', 'asc');
                break;
            default: // featured
                $query->orderBy('is_featured', 'desc')
                      ->orderBy('sort_order', 'asc')
                      ->orderBy('name', 'asc');
        }

        $products = $query->paginate(12)->withQueryString();

        // Get filter options for this metal
        $subcategories = Subcategory::whereHas('metalCategories', function ($q) use ($metalCategory) {
            $q->where('metal_categories.id', $metalCategory->id);
        })
        ->where('is_active', true)
        ->orderBy('sort_order')
        ->get();

        // Get available karats for this metal
        $availableKarats = $this->getAvailableKarats($metalCategory->symbol);

        // Get current metal price
        $priceData = $this->metalPriceService->getCurrentPrice($metalCategory->symbol);
        $metalCategory->current_price = $priceData['success'] ? $priceData['price'] : null;

        return view('categories.metal', compact(
            'metalCategory',
            'products',
            'subcategories',
            'availableKarats'
        ));
    }

    /**
     * Display all subcategories
     */
    public function subcategories()
    {
        $subcategories = Subcategory::where('is_active', true)
            ->withCount(['products' => function ($query) {
                $query->where('is_active', true);
            }])
            ->orderBy('sort_order')
            ->get();

        return view('categories.subcategories', compact('subcategories'));
    }

    /**
     * Display products for a specific subcategory
     */
    public function showSubcategory(Request $request, $subcategorySlug)
    {
        $subcategory = Subcategory::where('slug', $subcategorySlug)
            ->where('is_active', true)
            ->firstOrFail();

        $query = Product::with(['metalCategory'])
            ->where('subcategory_id', $subcategory->id)
            ->where('is_active', true);

        // Apply metal filter
        if ($request->has('metal') && $request->metal) {
            $query->whereHas('metalCategory', function ($q) use ($request) {
                $q->where('symbol', $request->metal)
                  ->orWhere('slug', $request->metal);
            });
        }

        // Apply karat filter
        if ($request->has('karat') && $request->karat) {
            $query->where('karat', $request->karat);
        }

        // Search within subcategory
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Sorting
        $sort = $request->get('sort', 'featured');
        switch ($sort) {
            case 'price_low':
                $query->orderBy('weight', 'asc'); // Simplified
                break;
            case 'price_high':
                $query->orderBy('weight', 'desc'); // Simplified
                break;
            case 'newest':
                $query->orderBy('created_at', 'desc');
                break;
            case 'name':
                $query->orderBy('name', 'asc');
                break;
            default: // featured
                $query->orderBy('is_featured', 'desc')
                      ->orderBy('sort_order', 'asc')
                      ->orderBy('name', 'asc');
        }

        $products = $query->paginate(12)->withQueryString();

        // Get filter options for this subcategory
        $metalCategories = MetalCategory::whereHas('subcategories', function ($q) use ($subcategory) {
            $q->where('subcategories.id', $subcategory->id);
        })
        ->where('is_active', true)
        ->orderBy('sort_order')
        ->get();

        return view('categories.subcategory', compact(
            'subcategory',
            'products',
            'metalCategories'
        ));
    }

    /**
     * Get available karats for a metal symbol
     */
    protected function getAvailableKarats($metalSymbol)
    {
        switch ($metalSymbol) {
            case 'XAU': // Gold
                return [
                    '24' => '24K (Pure Gold)',
                    '22' => '22K (91.7%)',
                    '21' => '21K (87.5%)',
                    '18' => '18K (75%)',
                    '14' => '14K (58.3%)',
                    '10' => '10K (41.7%)'
                ];
            case 'XAG': // Silver
                return [
                    '999' => '999 (99.9% Pure)',
                    '925' => '925 Sterling (92.5%)',
                    '900' => '900 Coin (90%)',
                    '800' => '800 (80%)'
                ];
            case 'XPT': // Platinum
                return [
                    '999' => '999 (99.9% Pure)',
                    '950' => '950 (95%)',
                    '900' => '900 (90%)',
                    '850' => '850 (85%)'
                ];
            case 'XPD': // Palladium
                return [
                    '999' => '999 (99.9% Pure)',
                    '950' => '950 (95%)',
                    '500' => '500 (50%)'
                ];
            default:
                return [];
        }
    }
}

