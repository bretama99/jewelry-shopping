<?php
// File: app/Http/Controllers/ProductController.php - Updated for Dynamic Categories
namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\MetalCategory;
use App\Models\Subcategory;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Customer;
use App\Services\MetalPriceApiService;
use App\Services\KitcoApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ProductController extends Controller
{
    protected $metalPriceService;
    protected $kitcoApiService;

    public function __construct(MetalPriceApiService $metalPriceService, KitcoApiService $kitcoApiService)
    {
        $this->metalPriceService = $metalPriceService;
        $this->kitcoApiService = $kitcoApiService;

    }

    /**
     * Display all products with dynamic filtering (Gold Trading Interface)
     */
    public function index(Request $request)
    {
        try {
            // Get active metal categories with their relationships
            $metalCategories = MetalCategory::with(['activeSubcategories'])
                ->where('is_active', true)
                ->ordered()
                ->get();

            // Get active subcategories with product counts
            $subcategories = Subcategory::with(['activeProducts', 'activeMetalCategories'])
                ->where('is_active', true)
                ->withCount('activeProducts')
                ->ordered()
                ->get();

            // Build the products query with filters
            $query = Product::with(['metalCategory', 'subcategory'])
                ->where('is_active', true);

            // Apply metal filter
            if ($request->has('metal') && $request->metal) {
                $query->whereHas('metalCategory', function ($q) use ($request) {
                    $q->where('slug', $request->metal)
                      ->orWhere('symbol', $request->metal);
                });
            }

            // Apply subcategory filter
            if ($request->has('subcategory') && $request->subcategory && $request->subcategory !== 'all') {
                $query->whereHas('subcategory', function ($q) use ($request) {
                    $q->where('slug', $request->subcategory);
                });
            }

            // Apply karat filter
            if ($request->has('karat') && $request->karat) {
                $query->where('karat', $request->karat);
            }

            // Apply price range filters (simplified)
            if ($request->has('price_min') && $request->price_min) {
                $query->whereRaw('weight * ? >= ?', [100, $request->price_min]); // Simplified
            }

            if ($request->has('price_max') && $request->price_max) {
                $query->whereRaw('weight * ? <= ?', [100, $request->price_max]); // Simplified
            }

            // Apply search
            if ($request->has('search') && $request->search) {
                $search = $request->search;
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%")
                      ->orWhere('sku', 'like', "%{$search}%");
                });
            }

            // Apply sorting
            $sort = $request->get('sort', 'name');
            $direction = $request->get('direction', 'asc');

            switch ($sort) {
                case 'price':
                case 'price_low':
                    $query->orderBy('weight', 'asc'); // Simplified sorting by weight
                    break;
                case 'price_high':
                    $query->orderBy('weight', 'desc');
                    break;
                case 'featured':
                    $query->orderBy('is_featured', 'desc')
                          ->orderBy('sort_order', 'asc');
                    break;
                case 'newest':
                    $query->orderBy('created_at', 'desc');
                    break;
                default:
                    $query->orderBy('sort_order', 'asc')
                          ->orderBy('name', $direction);
            }

            // Paginate results
            $products = $query->paginate(16)->withQueryString();

            // Get current metal prices (cache for 5 minutes)
            $metalPrices = Cache::remember('metal_prices', 300, function () {
                return $this->getCurrentMetalPrices();
            });

            // Get available karat options for current metal filter
            $availableKarats = [];
            if ($request->has('metal') && $request->metal) {
                $metalCategory = $metalCategories->firstWhere('slug', $request->metal);
                if ($metalCategory) {
                    $availableKarats = $metalCategory->getAvailableKarats();
                }
            }

            // Prepare data for JavaScript
            $jsData = [
                'metalPricesFromDB' => $metalPrices,
                'subcategoryLaborCosts' => $this->getSubcategoryLaborCosts($subcategories),
                'subcategoryProfitMargins' => $this->getSubcategoryProfitMargins($subcategories),
                'currentMetalSlug' => $request->get('metal', $metalCategories->first()?->slug ?? 'gold')
            ];

            return view('products.index', compact(
                'products',
                'metalCategories',
                'subcategories',
                'metalPrices',
                'availableKarats',
                'jsData'
            ));

        } catch (\Exception $e) {
            Log::error('Error loading products interface: ' . $e->getMessage());

            // Return with minimal data if there's an error
            return view('products.index', [
                'products' => collect(),
                'metalCategories' => collect(),
                'subcategories' => collect(),
                'metalPrices' => [],
                'availableKarats' => [],
                'jsData' => [
                    'metalPricesFromDB' => [],
                    'subcategoryLaborCosts' => [],
                    'subcategoryProfitMargins' => [],
                    'currentMetalSlug' => 'gold'
                ]
            ])->with('error', 'Unable to load products. Please try again.');
        }
    }

    /**
     * Display a specific product
     */
    public function show(Product $product)
    {
        if (!$product->is_active) {
            abort(404);
        }

        $product->load(['metalCategory', 'subcategory']);

        // Get live pricing using the database model method
        $livePricing = $product->getPriceBreakdown();

        // Get available weight options
        $weightOptions = $this->generateWeightOptions($product);

        // Get available karat options for this metal from database
        $karatOptions = [];
        if ($product->metalCategory) {
            $availableKarats = $product->metalCategory->getAvailableKarats();
            foreach ($availableKarats as $karat) {
                $karatOptions[] = [
                    'value' => $karat,
                    'label' => $product->metalCategory->getKaratDisplayText($karat),
                    'multiplier' => $product->metalCategory->purity_ratios[$karat] ?? 1.0
                ];
            }
        }

        // Get related products
        $relatedProducts = Product::where('is_active', true)
            ->where('id', '!=', $product->id)
            ->where(function ($query) use ($product) {
                $query->where('subcategory_id', $product->subcategory_id)
                      ->orWhere('metal_category_id', $product->metal_category_id);
            })
            ->limit(4)
            ->get();

        return view('products.show', compact(
            'product',
            'livePricing',
            'weightOptions',
            'karatOptions',
            'relatedProducts'
        ));
    }

    /**
     * Get live price calculation for product using database model
     */
    public function getLivePrice(Request $request, Product $product)
    {
        try {
            $weight = $request->get('weight', $product->weight);
            $karat = $request->get('karat', $product->karat);

            // Use the product model's pricing calculation
            $pricing = $product->getPriceBreakdown($weight);

            if (!$pricing) {
                throw new \Exception('Unable to calculate pricing');
            }

            return response()->json([
                'success' => true,
                'pricing' => $pricing,
                'formatted_price' => 'AUD$' . number_format($pricing['final_price'], 2)
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
                'fallback_price' => $product->calculateLivePrice($weight ?? null)
            ]);
        }
    }

    /**
     * Get current metal prices from database/API
     */
    protected function getCurrentMetalPrices()
    {
        try {
            $prices = [];
            $metalCategories = MetalCategory::where('is_active', true)->get();

            foreach ($metalCategories as $metal) {
                // Try to get fresh prices from API if stale
                if ($metal->isPriceStale()) {
                    try {
                        $priceData = $this->kitcoApiService->getCurrentPrice($metal->symbol);
                        if ($priceData['success']) {
                            $exchangeRate = $this->metalPriceService->getExchangeRate();
                            $metal->updatePriceFromApi($priceData['price'], $exchangeRate);
                        }
                    } catch (\Exception $e) {
                        Log::warning('Failed to update price for ' . $metal->symbol . ': ' . $e->getMessage());
                    }
                }

                // Get all prices for different karats/purities
                $prices[$metal->slug] = $metal->getAllPrices();
            }

            return $prices;

        } catch (\Exception $e) {
            Log::error('Error fetching metal prices: ' . $e->getMessage());

            // Return fallback prices from database
            $prices = [];
            $metalCategories = MetalCategory::where('is_active', true)->get();

            foreach ($metalCategories as $metal) {
                $prices[$metal->slug] = $metal->getAllPrices();
            }

            return $prices;
        }
    }

    /**
     * Update metal prices from API
     */
    public function updatePrices(Request $request)
    {
        try {
            $updated = [];
            $metalCategories = MetalCategory::where('is_active', true)->get();

            foreach ($metalCategories as $metal) {
                $priceData = $this->kitcoApiService->getCurrentPrice($metal->symbol);

                if ($priceData['success']) {
                    $oldPrice = $metal->current_price_usd;
                    $exchangeRate = $this->metalPriceService->getExchangeRate();
                    $metal->updatePriceFromApi($priceData['price'], $exchangeRate);

                    $updated[] = [
                        'metal' => $metal->name,
                        'symbol' => $metal->symbol,
                        'old_price' => $oldPrice,
                        'new_price' => $priceData['price'],
                        'change' => $priceData['price'] - $oldPrice,
                        'change_percent' => $oldPrice > 0 ? (($priceData['price'] - $oldPrice) / $oldPrice) * 100 : 0
                    ];
                }
            }

            // Clear the cache
            Cache::forget('metal_prices');

            return response()->json([
                'success' => true,
                'message' => 'Metal prices updated successfully',
                'updated' => $updated,
                'timestamp' => now()->toISOString()
            ]);

        } catch (\Exception $e) {
            Log::error('Error updating metal prices: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Failed to update metal prices',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get available karats for a metal category (API endpoint)
     */
    public function getAvailableKarats(Request $request, $metalSlug)
    {
        try {
            $metalCategory = MetalCategory::where('slug', $metalSlug)
                ->where('is_active', true)
                ->first();

            if (!$metalCategory) {
                return response()->json([
                    'success' => false,
                    'error' => 'Metal category not found'
                ], 404);
            }

            $karats = $metalCategory->getAvailableKarats();
            $karatsWithPrices = [];

            foreach ($karats as $karat) {
                $karatsWithPrices[] = [
                    'value' => $karat,
                    'label' => $metalCategory->getKaratDisplayText($karat),
                    'price_per_gram' => $metalCategory->calculatePricePerGram($karat)
                ];
            }

            return response()->json([
                'success' => true,
                'data' => $karatsWithPrices,
                'metal' => [
                    'name' => $metalCategory->name,
                    'symbol' => $metalCategory->symbol,
                    'slug' => $metalCategory->slug
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to get karats',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get subcategories for a metal category (API endpoint)
     */
    public function getSubcategoriesForMetal(Request $request, $metalSlug)
    {
        try {
            $metalCategory = MetalCategory::where('slug', $metalSlug)
                ->where('is_active', true)
                ->first();

            if (!$metalCategory) {
                return response()->json([
                    'success' => false,
                    'error' => 'Metal category not found'
                ], 404);
            }

            $subcategories = $metalCategory->activeSubcategories()
                ->withCount('activeProducts')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $subcategories->map(function ($subcategory) use ($metalCategory) {
                    return [
                        'id' => $subcategory->id,
                        'name' => $subcategory->name,
                        'slug' => $subcategory->slug,
                        'products_count' => $subcategory->active_products_count,
                        'labor_cost' => $subcategory->getLaborCostForMetal($metalCategory->id),
                        'profit_margin' => $subcategory->getProfitMarginForMetal($metalCategory->id)
                    ];
                })
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to get subcategories',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Calculate scrap price (API endpoint)
     */
    public function calculateScrapPrice(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'metal_slug' => 'required|string',
                'karat' => 'required|string',
                'weight' => 'required|numeric|min:0.01'
            ]);

            $metalCategory = MetalCategory::where('slug', $validatedData['metal_slug'])
                ->where('is_active', true)
                ->first();

            if (!$metalCategory) {
                return response()->json([
                    'success' => false,
                    'error' => 'Metal category not found'
                ], 404);
            }

            $weight = $validatedData['weight'];
            $karat = $validatedData['karat'];

            // Get current price for this karat
            $pricePerGram = $metalCategory->calculatePricePerGram($karat);
            $grossValue = $weight * $pricePerGram;

            // Apply scrap deductions (configurable)
            $processingFee = 0.15; // 15%
            $margins = [
                'gold' => ['9' => 0.12, '10' => 0.12, '14' => 0.10, '18' => 0.08, '21' => 0.06, '22' => 0.05],
                'silver' => ['925' => 0.10, '950' => 0.08, '999' => 0.05],
                'platinum' => ['900' => 0.10, '950' => 0.08, '999' => 0.05],
                'palladium' => ['950' => 0.08, '999' => 0.05]
            ];

            $metalSlug = $metalCategory->slug;
            $margin = $margins[$metalSlug][$karat] ?? 0.10;

            $processingDeduction = $grossValue * $processingFee;
            $marginDeduction = $grossValue * $margin;
            $totalDeductions = $processingDeduction + $marginDeduction;
            $offerValue = $grossValue - $totalDeductions;

            return response()->json([
                'success' => true,
                'data' => [
                    'weight' => $weight,
                    'karat' => $karat,
                    'price_per_gram' => $pricePerGram,
                    'gross_value' => round($grossValue, 2),
                    'processing_fee_percent' => $processingFee * 100,
                    'processing_deduction' => round($processingDeduction, 2),
                    'margin_percent' => $margin * 100,
                    'margin_deduction' => round($marginDeduction, 2),
                    'total_deductions' => round($totalDeductions, 2),
                    'offer_value' => round($offerValue, 2),
                    'offer_per_gram' => round($offerValue / $weight, 2)
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to calculate scrap price',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Search customers for checkout
     */
    public function searchCustomers(Request $request)
    {
        try {
            $query = $request->get('query', '');

            if (strlen($query) < 2) {
                return response()->json([
                    'success' => false,
                    'message' => 'Query too short'
                ]);
            }

            $customers = Customer::where(function ($q) use ($query) {
                $q->where('first_name', 'like', "%{$query}%")
                  ->orWhere('last_name', 'like', "%{$query}%")
                  ->orWhere('email', 'like', "%{$query}%")
                  ->orWhere('phone', 'like', "%{$query}%")
                  ->orWhere('passport_id_number', 'like', "%{$query}%")
                  ->orWhereRaw("CONCAT(first_name, ' ', last_name) LIKE ?", ["%{$query}%"]);
            })
            ->limit(10)
            ->get();

            return response()->json([
                'success' => true,
                'data' => $customers->map(function ($customer) {
                    return [
                        'id' => $customer->id,
                        'first_name' => $customer->first_name,
                        'last_name' => $customer->last_name,
                        'full_name' => $customer->first_name . ' ' . $customer->last_name,
                        'email' => $customer->email,
                        'phone' => $customer->phone,
                        'passport_id_number' => $customer->passport_id_number,
                    ];
                })
            ]);

        } catch (\Exception $e) {
            Log::error('Error searching customers: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Search failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create a new order
     */
    public function createOrder(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'customer_first_name' => 'required|string|max:255',
                'customer_last_name' => 'required|string|max:255',
                'customer_email' => 'required|email|max:255',
                'customer_phone' => 'nullable|string|max:20',
                'customer_passport_id' => 'nullable|string|max:50',
                'notes' => 'nullable|string|max:1000',
                'order_type' => 'required|string|in:jewelry,scrap,bullion,mixed',
                'items' => 'required|array|min:1',
                'items.*.type' => 'required|string|in:jewelry,scrap,bullion',
                'items.*.product_id' => 'nullable|string',
                'items.*.product_name' => 'required|string|max:255',
                'items.*.weight' => 'required|numeric|min:0.01',
                'items.*.karat' => 'required|string',
                'items.*.price_per_gram' => 'required|numeric|min:0',
                'items.*.total_price' => 'required|numeric',
            ]);

            DB::beginTransaction();

            // Find or create customer
            $customer = Customer::where('email', $validatedData['customer_email'])->first();

            if (!$customer) {
                $customer = Customer::create([
                    'first_name' => $validatedData['customer_first_name'],
                    'last_name' => $validatedData['customer_last_name'],
                    'email' => $validatedData['customer_email'],
                    'phone' => $validatedData['customer_phone'],
                    'passport_id_number' => $validatedData['customer_passport_id'],
                ]);
            }

            // Calculate totals
            $totalRevenue = 0;
            $totalExpenses = 0;

            foreach ($validatedData['items'] as $item) {
                if ($item['type'] === 'scrap' || ($item['type'] === 'bullion' && isset($item['subtype']) && $item['subtype'] === 'buy')) {
                    $totalExpenses += abs($item['total_price']);
                } else {
                    $totalRevenue += abs($item['total_price']);
                }
            }

            $netSubtotal = $totalRevenue - $totalExpenses;
            $tax = max(0, $totalRevenue * 0.10); // 10% GST on sales only
            $shipping = $totalRevenue > 500 ? 0 : ($totalRevenue > 0 ? 25 : 0);
            $finalTotal = $netSubtotal + $tax + $shipping;

            // Create order
            $order = Order::create([
                'order_number' => $this->generateOrderNumber(),
                'customer_id' => $customer->id,
                'order_type' => $validatedData['order_type'],
                'status' => 'processing',
                'subtotal' => $netSubtotal,
                'tax_amount' => $tax,
                'shipping_amount' => $shipping,
                'total_amount' => $finalTotal,
                'notes' => $validatedData['notes'],
                'metal_prices_snapshot' => $this->getCurrentMetalPrices(),
            ]);

            // Create order items
            foreach ($validatedData['items'] as $item) {
                $orderItem = OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['product_id'] ?? null,
                    'type' => $item['type'],
                    'subtype' => $item['subtype'] ?? null,
                    'name' => $item['product_name'],
                    'weight' => $item['weight'],
                    'karat' => $item['karat'],
                    'price_per_gram' => $item['price_per_gram'],
                    'total_price' => $item['total_price'],
                    'metal_category' => $item['category_name'] ?? null,
                    'description' => $item['description'] ?? null,
                ]);

                // Update product stock if it's a jewelry item
                if ($item['type'] === 'jewelry' && !empty($item['product_id'])) {
                    $product = Product::find($item['product_id']);
                    if ($product) {
                        $product->decrementStock(1);
                    }
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Order created successfully',
                'data' => [
                    'order' => $order->load('customer', 'items'),
                    'order_number' => $order->order_number
                ]
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'error' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error creating order: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Failed to create order',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Generate weight options for product customization
     */
    protected function generateWeightOptions(Product $product)
    {
        $options = [];
        $current = $product->min_weight;

        while ($current <= $product->max_weight) {
            $options[] = [
                'value' => $current,
                'label' => number_format($current, 3) . 'g'
            ];
            $current += $product->weight_step;
        }

        return $options;
    }

    /**
     * Get labor costs for subcategories
     */
    protected function getSubcategoryLaborCosts($subcategories)
    {
        $laborCosts = [];
        foreach ($subcategories as $subcategory) {
            $laborCosts[$subcategory->slug] = $subcategory->default_labor_cost;
        }
        return $laborCosts;
    }

    /**
     * Get profit margins for subcategories
     */
    protected function getSubcategoryProfitMargins($subcategories)
    {
        $profitMargins = [];
        foreach ($subcategories as $subcategory) {
            $profitMargins[$subcategory->slug] = $subcategory->default_profit_margin;
        }
        return $profitMargins;
    }

    /**
     * Generate unique order number
     */
    protected function generateOrderNumber()
    {
        do {
            $orderNumber = 'ORD-' . date('Ymd') . '-' . strtoupper(\Str::random(6));
        } while (Order::where('order_number', $orderNumber)->exists());

        return $orderNumber;
    }
}
