<?php
// app/Services/CategoryService.php

namespace App\Services;

use App\Models\Category;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class CategoryService
{
    public function getAllCategories($filters = [])
    {
        $query = Category::withCount(['products', 'activeProducts']);

        // Apply filters
        if (!empty($filters['search'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('name', 'like', '%' . $filters['search'] . '%')
                  ->orWhere('description', 'like', '%' . $filters['search'] . '%');
            });
        }

        if (isset($filters['status'])) {
            if ($filters['status'] === 'active') {
                $query->where('is_active', true);
            } elseif ($filters['status'] === 'inactive') {
                $query->where('is_active', false);
            }
        }

        if (isset($filters['featured'])) {
            $query->where('is_featured', $filters['featured']);
        }

        // Apply sorting
        switch ($filters['sort'] ?? 'name') {
            case 'created_desc':
                $query->latest();
                break;
            case 'created_asc':
                $query->oldest();
                break;
            case 'products_count':
                $query->orderByDesc('products_count');
                break;
            case 'sort_order':
                $query->orderBy('sort_order', 'asc')->orderBy('name', 'asc');
                break;
            default:
                $query->orderBy('name', 'asc');
        }

        return $query->paginate(15)->appends($filters);
    }

    public function createCategory(array $data)
    {
        // Handle slug generation
        if (empty($data['slug']) && !empty($data['name'])) {
            $data['slug'] = $this->generateUniqueSlug($data['name']);
        }

        // Handle image upload
        if (isset($data['image']) && $data['image'] instanceof UploadedFile) {
            $data['image'] = $this->handleImageUpload($data['image'], $data['name']);
        }

        // Set default values
        $data['is_active'] = $data['is_active'] ?? true;
        $data['is_featured'] = $data['is_featured'] ?? false;
        $data['sort_order'] = $data['sort_order'] ?? 0;

        return Category::create($data);
    }

    public function updateCategory(Category $category, array $data)
    {
        // Handle slug regeneration if name changed and no custom slug provided
        if (isset($data['name']) && $data['name'] !== $category->name) {
            if (empty($data['slug'])) {
                $data['slug'] = $this->generateUniqueSlug($data['name'], $category->id);
            }
        }

        // Handle image upload
        if (isset($data['image']) && $data['image'] instanceof UploadedFile) {
            // Delete old image
            if ($category->image) {
                $this->deleteImage($category->image);
            }
            $data['image'] = $this->handleImageUpload($data['image'], $data['name'] ?? $category->name);
        }

        // Handle image removal
        if (isset($data['remove_image']) && $data['remove_image']) {
            if ($category->image) {
                $this->deleteImage($category->image);
            }
            $data['image'] = null;
            unset($data['remove_image']);
        }

        // Set boolean values
        $data['is_active'] = isset($data['is_active']) ? (bool)$data['is_active'] : $category->is_active;
        $data['is_featured'] = isset($data['is_featured']) ? (bool)$data['is_featured'] : $category->is_featured;

        $category->update($data);
        return $category->fresh();
    }

    public function deleteCategory(Category $category)
    {
        if (!$category->canBeDeleted()) {
            throw new \Exception('Cannot delete category with existing products.');
        }

        // Delete image if exists
        if ($category->image) {
            $this->deleteImage($category->image);
        }

        return $category->delete();
    }

    public function toggleStatus(Category $category)
    {
        $category->update(['is_active' => !$category->is_active]);
        return $category->fresh();
    }

    public function toggleFeature(Category $category)
    {
        $category->update(['is_featured' => !$category->is_featured]);
        return $category->fresh();
    }

    public function duplicateCategory(Category $category)
    {
        $newCategory = $category->replicate();
        $newCategory->name = $category->name . ' (Copy)';
        $newCategory->slug = $this->generateUniqueSlug($newCategory->name);
        $newCategory->is_active = false;

        // Copy image if exists
        if ($category->image) {
            $newImageName = $this->duplicateImage($category->image, $newCategory->name);
            if ($newImageName) {
                $newCategory->image = $newImageName;
            }
        }

        $newCategory->save();
        return $newCategory;
    }

    public function bulkAction(array $categoryIds, string $action)
    {
        $categories = Category::whereIn('id', $categoryIds);

        switch ($action) {
            case 'activate':
                $categories->update(['is_active' => true]);
                break;
            case 'deactivate':
                $categories->update(['is_active' => false]);
                break;
            case 'feature':
                $categories->update(['is_featured' => true]);
                break;
            case 'unfeature':
                $categories->update(['is_featured' => false]);
                break;
            case 'delete':
                $categoriesToDelete = $categories->get();
                foreach ($categoriesToDelete as $category) {
                    if ($category->canBeDeleted()) {
                        $this->deleteCategory($category);
                    }
                }
                break;
            default:
                throw new \InvalidArgumentException("Invalid bulk action: {$action}");
        }

        return true;
    }

    public function getStats()
    {
        return [
            'total_categories' => Category::count(),
            'active_categories' => Category::where('is_active', true)->count(),
            'featured_categories' => Category::where('is_featured', true)->count(),
            'total_products' => Category::withCount('products')->get()->sum('products_count'),
        ];
    }

    /**
     * Handle image upload to public/images/categories directory
     */
    private function handleImageUpload(UploadedFile $image, string $categoryName)
    {
        // Create categories directory if it doesn't exist
        $categoriesPath = public_path('images/categories');
        if (!File::exists($categoriesPath)) {
            File::makeDirectory($categoriesPath, 0755, true);
        }

        // Generate unique filename
        $extension = $image->getClientOriginalExtension();
        $fileName = time() . '_' . Str::slug($categoryName) . '.' . $extension;

        // Move file to categories directory
        $image->move($categoriesPath, $fileName);

        return $fileName;
    }

    /**
     * Delete image from public/images/categories directory
     */
    private function deleteImage(string $filename)
    {
        if ($filename) {
            $imagePath = public_path('images/categories/' . $filename);
            if (File::exists($imagePath)) {
                File::delete($imagePath);
            }
        }
    }

    /**
     * Duplicate image file for category duplication
     */
    private function duplicateImage(string $originalFilename, string $newCategoryName)
    {
        $originalPath = public_path('images/categories/' . $originalFilename);

        if (!File::exists($originalPath)) {
            return null;
        }

        // Generate new filename
        $extension = pathinfo($originalFilename, PATHINFO_EXTENSION);
        $newFilename = time() . '_copy_' . Str::slug($newCategoryName) . '.' . $extension;
        $newPath = public_path('images/categories/' . $newFilename);

        // Copy the file
        if (File::copy($originalPath, $newPath)) {
            return $newFilename;
        }

        return null;
    }

    private function generateUniqueSlug(string $name, ?int $excludeId = null)
    {
        $slug = Str::slug($name);
        $originalSlug = $slug;
        $counter = 1;

        $query = Category::where('slug', $slug);
        if ($excludeId) {
            $query->where('id', '!=', $excludeId);
        }

        while ($query->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;

            $query = Category::where('slug', $slug);
            if ($excludeId) {
                $query->where('id', '!=', $excludeId);
            }
        }

        return $slug;
    }

    public function getFeaturedCategories($limit = 6)
    {
        return Category::active()
            ->featured()
            ->withCount('activeProducts')
            ->orderBy('sort_order')
            ->limit($limit)
            ->get();
    }

    public function getActiveCategories()
    {
        return Category::active()
            ->withCount('activeProducts')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();
    }
}
