<?php
// File: bootstrap/providers.php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\PermissionServiceProvider::class,
];
