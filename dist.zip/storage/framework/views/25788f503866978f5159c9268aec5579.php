<?php $__env->startSection('title', 'Categories Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Categories</h1>
            <p class="mb-0 text-muted">Browse and manage jewelry categories</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('categories.export')); ?>" class="btn btn-outline-success">
                <i class="fas fa-download me-1"></i> Export
            </a>
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i> Add Category
            </a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Categories</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['total_categories']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-tags fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Active Categories</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['active_categories']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Featured Categories</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['featured_categories']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-star fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Products</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['total_products']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-gem fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters and Search -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h6 class="m-0 font-weight-bold text-primary">Categories List</h6>
                </div>
                <div class="col-md-6">
                    <form method="GET" class="d-flex gap-2">
                        <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>"
                               placeholder="Search categories..." class="form-control form-control-sm">

                        <select name="status" class="form-select form-select-sm">
                            <option value="">All Status</option>
                            <option value="active" <?php echo e(($filters['status'] ?? '') == 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(($filters['status'] ?? '') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>

                        <select name="view" class="form-select form-select-sm">
                            <option value="grid" <?php echo e(($filters['view'] ?? 'grid') == 'grid' ? 'selected' : ''); ?>>Grid View</option>
                            <option value="list" <?php echo e(($filters['view'] ?? 'grid') == 'list' ? 'selected' : ''); ?>>List View</option>
                        </select>

                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fas fa-search"></i>
                        </button>

                        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary btn-sm">
                            <i class="fas fa-times"></i>
                        </a>
                    </form>
                </div>
            </div>
        </div>

        <div class="card-body">
            <!-- Bulk Actions -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="bulk-actions d-none">
                        <select id="bulkAction" class="form-select form-select-sm d-inline-block w-auto">
                            <option value="">Bulk Actions</option>
                            <option value="activate">Activate</option>
                            <option value="deactivate">Deactivate</option>
                            <option value="feature">Feature</option>
                            <option value="unfeature">Unfeature</option>
                            <option value="delete">Delete</option>
                        </select>
                        <button type="button" id="applyBulkAction" class="btn btn-sm btn-primary ms-2">Apply</button>
                        <span class="ms-2 text-muted"><span id="selectedCount">0</span> selected</span>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="btn-group btn-group-sm" role="group">
                        <a href="?<?php echo e(http_build_query(array_merge(request()->query(), ['view' => 'grid']))); ?>"
                           class="btn <?php echo e(($filters['view'] ?? 'grid') == 'grid' ? 'btn-primary' : 'btn-outline-primary'); ?>">
                            <i class="fas fa-th"></i> Grid
                        </a>
                        <a href="?<?php echo e(http_build_query(array_merge(request()->query(), ['view' => 'list']))); ?>"
                           class="btn <?php echo e(($filters['view'] ?? 'grid') == 'list' ? 'btn-primary' : 'btn-outline-primary'); ?>">
                            <i class="fas fa-list"></i> List
                        </a>
                    </div>
                </div>
            </div>

            <?php if($categories->count() > 0): ?>
                <?php if(($filters['view'] ?? 'grid') == 'grid'): ?>
                    <!-- Grid View -->
                    <div class="row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                                <div class="card category-card h-100 shadow-sm">
                                    <div class="position-relative">
                                        <!-- Category Image -->
                                        <div class="category-image-container">
                                            <?php if($category->image): ?>
                                                <img src="<?php echo e($category->image_url); ?>" alt="<?php echo e($category->name); ?>"
                                                     class="card-img-top category-image">
                                            <?php else: ?>
                                                <div class="card-img-top category-image bg-light d-flex align-items-center justify-content-center">
                                                    <i class="fas fa-image fa-3x text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <!-- Status Badges -->
                                        <div class="position-absolute top-0 start-0 m-2">
                                            <div class="d-flex flex-column gap-1">
                                                <?php if($category->is_featured): ?>
                                                    <span class="badge bg-warning">
                                                        <i class="fas fa-star"></i> Featured
                                                    </span>
                                                <?php endif; ?>
                                                <span class="badge <?php echo e($category->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                                    <?php echo e($category->is_active ? 'Active' : 'Inactive'); ?>

                                                </span>
                                            </div>
                                        </div>

                                        <!-- Selection Checkbox -->
                                        <div class="position-absolute top-0 end-0 m-2">
                                            <input type="checkbox" class="form-check-input category-checkbox"
                                                   value="<?php echo e($category->id); ?>">
                                        </div>

                                        <!-- Quick Actions -->
                                        <div class="position-absolute bottom-0 end-0 m-2">
                                            <div class="btn-group btn-group-sm">
                                                <button type="button" class="btn btn-sm btn-outline-light toggle-status"
                                                        data-id="<?php echo e($category->id); ?>"
                                                        title="<?php echo e($category->is_active ? 'Deactivate' : 'Activate'); ?>">
                                                    <i class="fas <?php echo e($category->is_active ? 'fa-eye-slash' : 'fa-eye'); ?>"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-light toggle-feature"
                                                        data-id="<?php echo e($category->id); ?>"
                                                        title="<?php echo e($category->is_featured ? 'Unfeature' : 'Feature'); ?>">
                                                    <i class="fas fa-star <?php echo e($category->is_featured ? 'text-warning' : ''); ?>"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <h6 class="card-title mb-2"><?php echo e($category->name); ?></h6>
                                        <?php if($category->description): ?>
                                            <p class="card-text text-muted small">
                                                <?php echo e(Str::limit($category->description, 80)); ?>

                                            </p>
                                        <?php endif; ?>

                                        <div class="d-flex justify-content-between align-items-center mt-3">
                                            <small class="text-muted">
                                                <i class="fas fa-cube"></i> <?php echo e($category->products_count ?? 0); ?> products
                                            </small>
                                            <div class="btn-group btn-group-sm">
                                                <a href="<?php echo e(route('categories.edit', $category)); ?>"
                                                   class="btn btn-outline-primary btn-sm" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-outline-danger btn-sm delete-category"
                                                        data-id="<?php echo e($category->id); ?>"
                                                        data-name="<?php echo e($category->name); ?>" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <!-- List View -->
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th width="40">
                                        <input type="checkbox" id="selectAll" class="form-check-input">
                                    </th>
                                    <th width="80">Image</th>
                                    <th>Name</th>
                                    <th>Products</th>
                                    <th>Status</th>
                                    <th>Featured</th>
                                    <th>Sort Order</th>
                                    <th>Created</th>
                                    <th width="120">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" class="form-check-input category-checkbox"
                                                   value="<?php echo e($category->id); ?>">
                                        </td>
                                        <td>
                                            <?php if($category->image): ?>
                                                <img src="<?php echo e($category->image_url); ?>" alt="<?php echo e($category->name); ?>"
                                                     class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light d-flex align-items-center justify-content-center img-thumbnail"
                                                     style="width: 50px; height: 50px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div>
                                                <strong><?php echo e($category->name); ?></strong>
                                                <?php if($category->description): ?>
                                                    <br><small class="text-muted"><?php echo e(Str::limit($category->description, 50)); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo e($category->products_count ?? 0); ?></span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm toggle-status <?php echo e($category->is_active ? 'btn-success' : 'btn-secondary'); ?>"
                                                    data-id="<?php echo e($category->id); ?>">
                                                <?php echo e($category->is_active ? 'Active' : 'Inactive'); ?>

                                            </button>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm toggle-feature <?php echo e($category->is_featured ? 'btn-warning' : 'btn-outline-warning'); ?>"
                                                    data-id="<?php echo e($category->id); ?>">
                                                <i class="fas fa-star"></i>
                                            </button>
                                        </td>
                                        <td><?php echo e($category->sort_order); ?></td>
                                        <td>
                                            <small class="text-muted"><?php echo e($category->created_at->format('M d, Y')); ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="<?php echo e(route('categories.edit', $category)); ?>"
                                                   class="btn btn-outline-primary" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-outline-danger delete-category"
                                                        data-id="<?php echo e($category->id); ?>"
                                                        data-name="<?php echo e($category->name); ?>" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <!-- Pagination -->
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <div>
                        <small class="text-muted">
                            Showing <?php echo e($categories->firstItem()); ?> to <?php echo e($categories->lastItem()); ?>

                            of <?php echo e($categories->total()); ?> results
                        </small>
                    </div>
                    <div>
                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-tags fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">No categories found</h4>
                    <p class="text-muted">Start by creating your first category</p>
                    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i> Create Category
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the category <strong id="categoryName"></strong>?</p>
                <p class="text-muted small">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteForm" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Ensure CSRF token is available for JavaScript -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.category-image {
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.category-card:hover .category-image {
    transform: scale(1.05);
}

.category-image-container {
    overflow: hidden;
    border-radius: 0.375rem 0.375rem 0 0;
}

.category-card {
    transition: all 0.3s ease;
    border: 1px solid #e3e6f0;
}

.category-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.border-left-primary {
    border-left: 0.25rem solid #4e73df!important;
}

.border-left-success {
    border-left: 0.25rem solid #1cc88a!important;
}

.border-left-info {
    border-left: 0.25rem solid #36b9cc!important;
}

.border-left-warning {
    border-left: 0.25rem solid #f6c23e!important;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle Status
    document.querySelectorAll('.toggle-status').forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.dataset.id;

            fetch(`/categories/${categoryId}/toggle-status`, {
                method: 'PATCH',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Content-Type': 'application/json',
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Failed to update status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred');
            });
        });
    });

    // Toggle Feature
    document.querySelectorAll('.toggle-feature').forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.dataset.id;

            fetch(`/categories/${categoryId}/toggle-feature`, {
                method: 'PATCH',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Content-Type': 'application/json',
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Failed to update feature status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred');
            });
        });
    });

    // Delete Category - Simple and direct approach
    document.querySelectorAll('.delete-category').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const categoryId = this.dataset.id;
            const categoryName = this.dataset.name;

            if (confirm(`Are you sure you want to delete "${categoryName}"? This action cannot be undone.`)) {
                // Create a form and submit it
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = `/categories/${categoryId}`;

                // Add CSRF token
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = '_token';
                csrfInput.value = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                form.appendChild(csrfInput);

                // Add method spoofing for DELETE
                const methodInput = document.createElement('input');
                methodInput.type = 'hidden';
                methodInput.name = '_method';
                methodInput.value = 'DELETE';
                form.appendChild(methodInput);

                // Submit the form
                document.body.appendChild(form);
                form.submit();
            }
        });
    });

    // Select All Checkboxes
    const selectAllCheckbox = document.getElementById('selectAll');
    const categoryCheckboxes = document.querySelectorAll('.category-checkbox');
    const bulkActions = document.querySelector('.bulk-actions');
    const selectedCount = document.getElementById('selectedCount');

    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            categoryCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateBulkActions();
        });
    }

    categoryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateBulkActions);
    });

    function updateBulkActions() {
        const checkedBoxes = document.querySelectorAll('.category-checkbox:checked');
        const count = checkedBoxes.length;

        selectedCount.textContent = count;

        if (count > 0) {
            bulkActions.classList.remove('d-none');
        } else {
            bulkActions.classList.add('d-none');
        }

        // Update select all checkbox state
        if (selectAllCheckbox) {
            selectAllCheckbox.indeterminate = count > 0 && count < categoryCheckboxes.length;
            selectAllCheckbox.checked = count === categoryCheckboxes.length;
        }
    }

    // Bulk Actions
    document.getElementById('applyBulkAction')?.addEventListener('click', function() {
        const action = document.getElementById('bulkAction').value;
        const checkedBoxes = document.querySelectorAll('.category-checkbox:checked');

        if (!action) {
            alert('Please select an action');
            return;
        }

        if (checkedBoxes.length === 0) {
            alert('Please select at least one category');
            return;
        }

        if (action === 'delete' && !confirm('Are you sure you want to delete the selected categories?')) {
            return;
        }

        const categoryIds = Array.from(checkedBoxes).map(cb => cb.value);

        fetch('/categories/bulk-action', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: action,
                category_ids: categoryIds
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'Failed to perform bulk action');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred');
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\projects\final jewelry project\jewelry-ecommerce\resources\views/categories/index.blade.php ENDPATH**/ ?>