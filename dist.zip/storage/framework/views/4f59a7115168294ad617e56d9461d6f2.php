<?php $__env->startSection('title', 'Create Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Create New Product</h1>
            <p class="mb-0 text-muted">Add a new jewelry product to your store</p>
        </div>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Products
        </a>
    </div>

    <form method="POST" action="<?php echo e(route('admin.products.store')); ?>"
          enctype="multipart/form-data" id="productForm">
        <?php echo csrf_field(); ?>

        <div class="row">
            <!-- Main Product Information -->
            <div class="col-lg-8">
                <!-- Basic Information -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Basic Information</h6>
                    </div>
                    <div class="card-body">
                        <!-- Product Name -->
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="name" name="name" value="<?php echo e(old('name')); ?>"
                                   placeholder="e.g., Classic Gold Wedding Ring" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Metal Category and Subcategory -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="metal_category_id" class="form-label">Metal Category <span class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['metal_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="metal_category_id" name="metal_category_id" required onchange="updateMetalCategory()">
                                    <option value="">Select Metal Category</option>
                                    <?php $__currentLoopData = $metalCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metalCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($metalCategory->id); ?>"
                                                data-symbol="<?php echo e($metalCategory->symbol); ?>"
                                                <?php echo e(old('metal_category_id') == $metalCategory->id ? 'selected' : ''); ?>>
                                            <?php echo e($metalCategory->name); ?> (<?php echo e($metalCategory->symbol); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['metal_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="subcategory_id" class="form-label">Subcategory <span class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="subcategory_id" name="subcategory_id" required onchange="updateSubcategory()">
                                    <option value="">Select Subcategory</option>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subcategory->id); ?>"
                                                <?php echo e(old('subcategory_id') == $subcategory->id ? 'selected' : ''); ?>>
                                            <?php echo e($subcategory->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label for="description" class="form-label">Product Description</label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="description" name="description" rows="4"
                                      placeholder="Detailed description of the product..."><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Pricing Information -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Pricing Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="labor_cost" class="form-label">Labor Cost Override (AUD per gram)</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['labor_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="labor_cost" name="labor_cost" value="<?php echo e(old('labor_cost')); ?>"
                                       step="0.01" min="0" max="99999.99"
                                       onchange="calculateSamplePrice()">
                                <div class="form-text">Leave empty to use subcategory default (<span id="defaultLaborCost">--</span> AUD/g)</div>
                                <?php $__errorArgs = ['labor_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Product Image -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Product Image</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="image" class="form-label">Upload Image <span class="text-danger">*</span></label>
                            <input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="image" name="image" accept="image/*" required>
                            <div class="form-text">Recommended: Square format (1:1 ratio), min 400x400px, max 3MB</div>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Image Preview -->
                        <div id="imagePreview" class="text-center" style="display: none;">
                            <img id="previewImg" src="" alt="Preview"
                                 class="img-fluid rounded border" style="max-height: 300px;">
                        </div>
                    </div>
                </div>

                <!-- Product Status -->
                <div class="card shadow mb-4">
                    <div class="card-body">

                        <div class="mb-3">
                            <label for="sort_order" class="form-label">Sort Order</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="sort_order" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>"
                                   min="0" max="999">
                            <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Actions -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i>Cancel
                    </a>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-primary" onclick="previewProduct()">
                            <i class="fas fa-eye me-2"></i>Preview
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Create Product
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Product Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="submitForm()">
                    <i class="fas fa-save me-2"></i>Create Product
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
let availableKarats = {};
let metalCategories = <?php echo json_encode($metalCategories, 15, 512) ?>;
let subcategories = <?php echo json_encode($subcategories, 15, 512) ?>;

document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const slugInput = document.getElementById('slug');
    const imageInput = document.getElementById('image');
    const imagePreview = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');

    // Auto-generate slug from name
    nameInput.addEventListener('input', function() {
        if (!slugInput.value || slugInput.dataset.manual !== 'true') {
            const slug = this.value
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .trim()
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-');
            slugInput.value = slug;
        }
    });

    // Mark slug as manually edited
    slugInput.addEventListener('input', function() {
        this.dataset.manual = 'true';
    });

    // Image preview
    imageInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            if (file.size > 3 * 1024 * 1024) { // 3MB limit
                alert('Image size must be less than 3MB');
                this.value = '';
                imagePreview.style.display = 'none';
                return;
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                imagePreview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            imagePreview.style.display = 'none';
        }
    });

    // Load current metal prices
    loadMetalPrices();

    // Auto-fill weight ranges based on base weight
    document.getElementById('weight').addEventListener('change', function() {
        const baseWeight = parseFloat(this.value);
        if (baseWeight && !document.getElementById('min_weight').value) {
            document.getElementById('min_weight').value = (baseWeight * 0.5).toFixed(3);
        }
        if (baseWeight && !document.getElementById('max_weight').value) {
            document.getElementById('max_weight').value = (baseWeight * 3).toFixed(3);
        }
    });

    // Form validation
    document.getElementById('productForm').addEventListener('submit', function(e) {
        const minWeight = parseFloat(document.getElementById('min_weight').value);
        const maxWeight = parseFloat(document.getElementById('max_weight').value);
        const baseWeight = parseFloat(document.getElementById('weight').value);

        if (minWeight >= maxWeight) {
            e.preventDefault();
            alert('Maximum weight must be greater than minimum weight.');
            return;
        }

        if (baseWeight < minWeight || baseWeight > maxWeight) {
            e.preventDefault();
            alert('Base weight must be between minimum and maximum weight.');
            return;
        }
    });
});

// Update metal category and load available karats
function updateMetalCategory() {
    const metalCategoryId = document.getElementById('metal_category_id').value;
    const karatSelect = document.getElementById('karat');
    const subcategorySelect = document.getElementById('subcategory_id');

    // Clear karat options
    karatSelect.innerHTML = '<option value="">Loading...</option>';

    if (metalCategoryId) {
        // Fetch available karats for this metal
        fetch(`/admin/products/metal/${metalCategoryId}/karats`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    availableKarats = data.karats;
                    karatSelect.innerHTML = '<option value="">Select karat/purity</option>';

                    data.karats.forEach(karat => {
                        const option = document.createElement('option');
                        option.value = karat;
                        option.textContent = formatKaratDisplay(karat, data.metal_name);
                        karatSelect.appendChild(option);
                    });

                    updateKaratInfo();
                }
            })
            .catch(error => {
                console.error('Error fetching karats:', error);
                karatSelect.innerHTML = '<option value="">Error loading karats</option>';
            });

        // Filter subcategories for this metal
        fetch(`/admin/subcategories/for-metal/${metalCategoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const currentValue = subcategorySelect.value;
                    subcategorySelect.innerHTML = '<option value="">Select subcategory</option>';

                    data.subcategories.forEach(subcategory => {
                        const option = document.createElement('option');
                        option.value = subcategory.id;
                        option.textContent = subcategory.name;
                        if (currentValue == subcategory.id) {
                            option.selected = true;
                        }
                        subcategorySelect.appendChild(option);
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching subcategories:', error);
            });
    } else {
        karatSelect.innerHTML = '<option value="">Select metal category first</option>';
        subcategorySelect.innerHTML = '<option value="">Select metal category first</option>';
    }

    calculateSamplePrice();
}

// Update subcategory and load default pricing
function updateSubcategory() {
    const subcategoryId = document.getElementById('subcategory_id').value;

    if (subcategoryId) {
        const subcategory = subcategories.find(s => s.id == subcategoryId);
        if (subcategory) {
            document.getElementById('defaultLaborCost').textContent = subcategory.default_labor_cost;
            document.getElementById('defaultProfitMargin').textContent = subcategory.default_profit_margin;
        }
    } else {
        document.getElementById('defaultLaborCost').textContent = '--';
        document.getElementById('defaultProfitMargin').textContent = '--';
    }

    calculateSamplePrice();
}

// Format karat display based on metal type
function formatKaratDisplay(karat, metalName) {
    if (metalName === 'Silver') {
        return karat === '925' ? 'Sterling Silver (925)' : `Silver ${karat}`;
    } else if (metalName === 'Gold') {
        return `${karat}K Gold`;
    } else {
        return `${karat} ${metalName}`;
    }
}

// Update karat information
function updateKaratInfo() {
    const karat = document.getElementById('karat').value;
    const metalCategoryId = document.getElementById('metal_category_id').value;
    const karatInfo = document.getElementById('karatInfo');

    if (karat && metalCategoryId) {
        const metalCategory = metalCategories.find(m => m.id == metalCategoryId);
        if (metalCategory) {
            karatInfo.textContent = `Selected: ${formatKaratDisplay(karat, metalCategory.name)}`;
            karatInfo.className = 'form-text text-success';
        }
        calculateSamplePrice();
    } else {
        karatInfo.textContent = 'Select metal category and karat to see information';
        karatInfo.className = 'form-text';
    }
}

// Preview product
function previewProduct() {
    const formData = new FormData(document.getElementById('productForm'));

    const name = formData.get('name') || 'Product Name';
    const metalCategoryId = formData.get('metal_category_id');
    const subcategoryId = formData.get('subcategory_id');
    const karat = formData.get('karat') || '18';
    const weight = formData.get('weight') || '0';
    const description = formData.get('description') || 'No description provided';

    const metalCategory = metalCategories.find(m => m.id == metalCategoryId);
    const subcategory = subcategories.find(s => s.id == subcategoryId);

    const previewHTML = `
        <div class="row">
            <div class="col-md-6">
                <div class="border rounded p-3 text-center">
                    ${document.getElementById('previewImg').src ?
                        `<img src="${document.getElementById('previewImg').src}" class="img-fluid rounded" style="max-height: 200px;">` :
                        '<div class="bg-light p-5 rounded"><i class="fas fa-image fa-3x text-muted"></i><br><small class="text-muted">No image selected</small></div>'
                    }
                </div>
            </div>
            <div class="col-md-6">
                <h5>${name}</h5>
                <p class="text-muted">${metalCategory ? metalCategory.name : 'No metal'} • ${subcategory ? subcategory.name : 'No subcategory'}</p>
                <p class="text-muted">${karat}${metalCategory && metalCategory.name === 'Gold' ? 'K' : ''} • ${weight}g base weight</p>
                <p>${description}</p>
                <div class="bg-light p-3 rounded">
                    <h6>Configuration:</h6>
                    <div class="small">
                        <div>Metal: ${metalCategory ? metalCategory.name : 'Not selected'}</div>
                        <div>Type: ${subcategory ? subcategory.name : 'Not selected'}</div>
                        <div>Purity: ${karat}</div>
                        <div>Weight: ${weight}g</div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('previewContent').innerHTML = previewHTML;
    const modal = new bootstrap.Modal(document.getElementById('previewModal'));
    modal.show();
}

// Submit form from modal
function submitForm() {
    document.getElementById('productForm').submit();
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\projects\final jewelry project\jewelry-ecommerce\resources\views/admin/products/create.blade.php ENDPATH**/ ?>