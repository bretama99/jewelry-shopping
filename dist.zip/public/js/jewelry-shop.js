/**
 * Gold Trading Management System - FIXED VERSION
 * Fixes: Filtering system, default weight values, live price updates, subcategory filtering
 */

// ============================
// GLOBAL VARIABLES & CONFIGURATION
// ============================

// Global variables for precious metals pricing
let currentMetalPrices = {
    XAU: 0, // Gold price per troy ounce in USD
    XAG: 0, // Silver price per troy ounce in USD
    XPD: 0, // Palladium price per troy ounce in USD
    XPT: 0, // Platinum price per troy ounce in USD
    last_updated: null
};

// Convert troy ounce to gram and store prices per gram in AUD
const metalPricesPerGram = {
    gold: {},    // Will store prices for different karats
    silver: {},  // Will store prices for different purities
    palladium: {},
    platinum: {}
};

// Application state variables
let cart = [];
let selectedCustomer = null;
let searchTimer;
let currentView = 'grid';
let currentModule = 'jewelry'; // jewelry, scrap, bullion_sell, bullion_buy
let currentMetal = 'gold'; // Current metal slug
let currentSubcategory = 'all'; // Current subcategory filter
let isInitialized = false;
let priceUpdateInterval;

// Dynamic configuration loaded from database
let metalCategories = [];
let subcategories = [];
let tradingConfig = {
    jewelry: {
        laborCosts: {}, // Dynamic from database
        profitMargin: 0.25 // Default, can be overridden per subcategory
    },
    scrap: {
        processingFee: 0.15, // 15% deduction
        margins: {} // Dynamic from database
    },
    bullion: {
        sellPremium: {}, // Dynamic from database
        buyMargin: {}, // Dynamic from database
        sizes: {
            '1': { weight: 1, type: 'gram' },
            '2.5': { weight: 2.5, type: 'gram' },
            '5': { weight: 5, type: 'gram' },
            '10': { weight: 10, type: 'gram' },
            '0.5oz': { weight: 15.5517, type: 'gram' },
            '20': { weight: 20, type: 'gram' },
            '1oz': { weight: 31.1035, type: 'gram' },
            '50': { weight: 50, type: 'gram' },
            '100': { weight: 100, type: 'gram' },
            '250': { weight: 250, type: 'gram' },
            '500': { weight: 500, type: 'gram' },
            '1000': { weight: 1000, type: 'gram' }
        }
    }
};

// ============================
// INITIALIZATION SYSTEM
// ============================

// Main initialization when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    if (isInitialized) return;

    setTimeout(() => {
        try {
            // Load dynamic data from database first
            loadDynamicConfiguration().then(() => {
                updateMetalPrices().then(() => {
                    initializeSystem();
                    setupEventListeners();
                    initializeCustomerSearch();
                    updateCartDisplay();
                    
                    // Set default weights to 1 for all products
                    setDefaultWeights();

                    // Start price update interval (every 5 minutes)
                    priceUpdateInterval = setInterval(updateMetalPrices, 300000);

                    // Load saved view preference
                    const savedView = localStorage.getItem('gold_trading_view') || 'grid';
                    if (savedView === 'list') {
                        switchToListView();
                    } else {
                        switchToGridView();
                    }

                    isInitialized = true;
                    console.log('Gold Trading System initialized successfully');
                });
            });
        } catch (error) {
            console.error('Initialization error:', error);
        }
    }, 500);
});

// Set default weight to 1 for all products
function setDefaultWeights() {
    document.querySelectorAll('.weight-input').forEach(input => {
        if (!input.value || input.value === '0') {
            input.value = '1';
            const productId = input.getAttribute('data-product-id');
            if (productId) {
                updateProductTotalPrice(productId);
            }
        }
    });
}

async function loadDynamicConfiguration() {
    try {
        // Use fallback if window data is not available or if we need to fetch from API
        if (window.metalPricesFromDB && window.subcategoryLaborCosts) {
            // Use data injected from PHP
            console.log('Using data from PHP injection');
            metalCategories = window.metalPricesFromDB.metalCategories || [];
            subcategories = window.subcategoryLaborCosts.subcategories || [];
            currentMetal = window.currentMetalSlug || 'gold';
        } else {
            // Fallback to API calls
            console.log('Fetching data from API');
            await loadFromAPI();
        }

        // Load pricing configuration
        await loadPricingConfiguration();

    } catch (error) {
        console.error('Error loading dynamic configuration:', error);
        // Use fallback configuration
        setFallbackConfiguration();
    }
}

async function loadFromAPI() {
    try {
        // Load metal categories from database
        const metalResponse = await fetch('/api/metal-categories');
        if (metalResponse.ok) {
            const metalData = await metalResponse.json();
            metalCategories = metalData.data || [];
            console.log('Loaded metal categories:', metalCategories);
        }

        // Load subcategories from database
        const subcategoryResponse = await fetch('/api/subcategories');
        if (subcategoryResponse.ok) {
            const subcategoryData = await subcategoryResponse.json();
            subcategories = subcategoryData.data || [];
            console.log('Loaded subcategories:', subcategories);
        }

    } catch (error) {
        console.error('Error loading from API:', error);
        setFallbackConfiguration();
    }
}

async function loadPricingConfiguration() {
    try {
        // Load labor costs and profit margins for each subcategory
        for (const subcategory of subcategories) {
            tradingConfig.jewelry.laborCosts[subcategory.slug] = subcategory.default_labor_cost || 15.00;
        }

        // Load scrap margins for each metal
        for (const metal of metalCategories) {
            if (!tradingConfig.scrap.margins[metal.slug]) {
                tradingConfig.scrap.margins[metal.slug] = {};
            }

            // Load dynamic margins from database or use defaults
            const margins = await loadScrapMargins(metal.slug);
            tradingConfig.scrap.margins[metal.slug] = margins;
        }

        // Load bullion premiums and margins
        for (const metal of metalCategories) {
            tradingConfig.bullion.sellPremium[metal.slug] = await loadBullionSellPremium(metal.slug);
            tradingConfig.bullion.buyMargin[metal.slug] = await loadBullionBuyMargin(metal.slug);
        }

        console.log('Loaded trading configuration:', tradingConfig);

    } catch (error) {
        console.error('Error loading pricing configuration:', error);
    }
}

async function loadScrapMargins(metalSlug) {
    try {
        const response = await fetch(`/api/metals/${metalSlug}/scrap-margins`);
        if (response.ok) {
            const data = await response.json();
            return data.margins;
        }
    } catch (error) {
        console.error(`Error loading scrap margins for ${metalSlug}:`, error);
    }

    // Fallback margins
    const defaultMargins = {
        gold: { '9': 0.12, '10': 0.12, '14': 0.10, '18': 0.08, '19': 0.08, '20': 0.07, '21': 0.06, '22': 0.05, '23': 0.05, '24': 0.05 },
        silver: { '800': 0.12, '900': 0.10, '925': 0.10, '950': 0.08, '999': 0.05 },
        platinum: { '850': 0.12, '900': 0.10, '950': 0.08, '999': 0.05 },
        palladium: { '500': 0.15, '950': 0.08, '999': 0.05 }
    };

    return defaultMargins[metalSlug] || {};
}

async function loadBullionSellPremium(metalSlug) {
    try {
        const response = await fetch(`/api/metals/${metalSlug}/bullion-premium`);
        if (response.ok) {
            const data = await response.json();
            return data.sell_premium;
        }
    } catch (error) {
        console.error(`Error loading bullion sell premium for ${metalSlug}:`, error);
    }

    // Fallback premiums
    const defaultPremiums = { gold: 0.08, silver: 0.12, palladium: 0.10, platinum: 0.10 };
    return defaultPremiums[metalSlug] || 0.08;
}

async function loadBullionBuyMargin(metalSlug) {
    try {
        const response = await fetch(`/api/metals/${metalSlug}/bullion-margin`);
        if (response.ok) {
            const data = await response.json();
            return data.buy_margin;
        }
    } catch (error) {
        console.error(`Error loading bullion buy margin for ${metalSlug}:`, error);
    }

    // Fallback margins
    const defaultMargins = { gold: 0.05, silver: 0.08, palladium: 0.07, platinum: 0.07 };
    return defaultMargins[metalSlug] || 0.05;
}

function setFallbackConfiguration() {
    // Fallback metal categories
    metalCategories = [
        { id: 1, name: 'Gold', slug: 'gold', symbol: 'XAU', is_active: true },
        { id: 2, name: 'Silver', slug: 'silver', symbol: 'XAG', is_active: true },
        { id: 3, name: 'Platinum', slug: 'platinum', symbol: 'XPT', is_active: true },
        { id: 4, name: 'Palladium', slug: 'palladium', symbol: 'XPD', is_active: true }
    ];

    // Fallback subcategories
    subcategories = [
        { id: 1, name: 'Rings', slug: 'rings', default_labor_cost: 12.00 },
        { id: 2, name: 'Necklaces', slug: 'necklaces', default_labor_cost: 18.00 },
        { id: 3, name: 'Bracelets', slug: 'bracelets', default_labor_cost: 15.00 },
        { id: 4, name: 'Earrings', slug: 'earrings', default_labor_cost: 14.00 },
        { id: 5, name: 'Chains', slug: 'chains', default_labor_cost: 10.00 }
    ];

    console.log('Using fallback configuration');
}

function initializeSystem() {
    if (Object.keys(metalPricesPerGram.gold || {}).length === 0) {
        setFallbackPrices();
    }

    initializeProductData();
    initializeProductPrices();
    updatePriceDisplays();
    populateScrapKaratOptions();
    
    // Initialize filter states
    currentSubcategory = 'all';
    
    // Apply initial filter
    filterProducts();
}

// ============================
// PRICE UPDATE SYSTEM WITH LIVE UPDATES
// ============================

async function updateMetalPrices() {
    try {
        const updateBtn = document.getElementById('updatePricesBtn');
        if (updateBtn) {
            updateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Updating...';
            updateBtn.disabled = true;
        }

        showNotification('Updating precious metal prices...', 'info');

        const response = await fetch('https://api.metalpriceapi.com/v1/latest?api_key=d68f51781cca05150ab380fbea59224c&base=USD&currencies=XAU,XAG,XPD,XPT');

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }

        const data = await response.json();

        if (data.success && data.rates) {
            const rates = data.rates;
            
            // Update global prices
            currentMetalPrices = {
                XAU: rates.USDXAU,
                XAG: rates.USDXAG,
                XPD: rates.USDXPD,
                XPT: rates.USDXPT,
                last_updated: new Date()
            };

            const usdPrices = {
                gold: rates.USDXAU,
                silver: rates.USDXAG,
                palladium: rates.USDXPD,
                platinum: rates.USDXPT
            };

            console.log('USD Prices per troy ounce:', usdPrices);

            const audRate = await getAudRate();
            const gramsPerTroyOz = 31.1035;

            calculateAllMetalPrices(usdPrices, audRate, gramsPerTroyOz);

            // Show live update animation
            showPriceUpdateAnimation();
            
            updatePriceDisplays();
            updateAllProductPrices();
            
            showNotification(`Prices updated successfully! Gold: AUD$${metalPricesPerGram.gold['24']?.toFixed(2) || 'N/A'}/g`, 'success');

        } else {
            throw new Error('Invalid API response format');
        }
    } catch (error) {
        console.error('Error updating metal prices:', error);
        // showNotification('Failed to update prices. Using cached prices.', 'warning');

        if (Object.keys(metalPricesPerGram.gold || {}).length === 0) {
            setFallbackPrices();
        }
    } finally {
        const updateBtn = document.getElementById('updatePricesBtn');
        if (updateBtn) {
            updateBtn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>Update Prices';
            updateBtn.disabled = false;
        }
    }
}

function showPriceUpdateAnimation() {
    // Add animation class to price displays
    document.querySelectorAll('#metalPricesDisplay .badge').forEach(badge => {
        badge.classList.add('price-updated');
        setTimeout(() => {
            badge.classList.remove('price-updated');
        }, 1000);
    });

    // Add animation to product price displays
    document.querySelectorAll('[id*="total_price_"], [id*="price_per_gram_"]').forEach(element => {
        element.classList.add('price-updated');
        setTimeout(() => {
            element.classList.remove('price-updated');
        }, 1000);
    });
}

function calculateAllMetalPrices(usdPrices, audRate, gramsPerTroyOz) {
    // Reset the global prices object
    metalPricesPerGram.gold = {};
    metalPricesPerGram.silver = {};
    metalPricesPerGram.palladium = {};
    metalPricesPerGram.platinum = {};

    // Calculate prices for each metal category dynamically
    metalCategories.forEach(metal => {
        const metalSlug = metal.slug;
        const metalSymbol = metal.symbol;

        if (!usdPrices[metalSlug]) return;

        const pureMetalPriceAudPerGram = (usdPrices[metalSlug] * audRate) / gramsPerTroyOz;

        // Get available karats/purities for this metal
        const availableKarats = getAvailableKarats(metalSlug);

        availableKarats.forEach(karat => {
            let purityRatio;

            if (metalSymbol === 'XAU') {
                // Gold: karat/24
                purityRatio = parseInt(karat) / 24;
            } else {
                // Other metals: Use purity ratios from database or calculate
                if (metal.purity_ratios && metal.purity_ratios[karat]) {
                    purityRatio = metal.purity_ratios[karat];
                } else {
                    // Fallback calculation for purity (e.g., 925 = 0.925)
                    purityRatio = parseInt(karat) / 1000;
                }
            }

            const adjustedPrice = Math.round((pureMetalPriceAudPerGram * purityRatio) * 100) / 100;

            if (!metalPricesPerGram[metalSlug]) {
                metalPricesPerGram[metalSlug] = {};
            }

            metalPricesPerGram[metalSlug][karat] = adjustedPrice;
        });
    });

    console.log('Calculated metal prices per gram (AUD):', metalPricesPerGram);
}

function setFallbackPrices() {
    const fallbackPurePrices = {
        gold: 154.50,
        silver: 1.68,
        palladium: 152.00,
        platinum: 103.60
    };

    metalCategories.forEach(metal => {
        const metalSlug = metal.slug;
        const purePrice = fallbackPurePrices[metalSlug];

        if (!purePrice) return;

        const availableKarats = getAvailableKarats(metalSlug);

        metalPricesPerGram[metalSlug] = {};

        availableKarats.forEach(karat => {
            let purityRatio;

            if (metal.symbol === 'XAU') {
                purityRatio = parseInt(karat) / 24;
            } else {
                purityRatio = parseInt(karat) / 1000;
            }

            metalPricesPerGram[metalSlug][karat] = Math.round((purePrice * purityRatio) * 100) / 100;
        });
    });

    console.log('Using fallback prices:', metalPricesPerGram);
}

async function getAudRate() {
    try {
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
        if (response.ok) {
            const data = await response.json();
            return data.rates.AUD || 1.45;
        }
        return 1.45;
    } catch (error) {
        console.log('Currency conversion failed, using fallback rate');
        return 1.45;
    }
}

// ============================
// FIXED FILTERING AND SEARCH SYSTEM
// ============================

function filterBySubcategory(subcategorySlug) {
    try {
        currentSubcategory = subcategorySlug;
        
        // Update navigation active state
        document.querySelectorAll('#subcategoryTabs .nav-link').forEach(link => {
            link.classList.remove('active');
        });

        const clickedButton = document.querySelector(`[data-subcategory="${subcategorySlug}"]`);
        if (clickedButton) {
            clickedButton.classList.add('active');
        }
        
        filterProducts();
    } catch (error) {
        console.error('Error filtering by subcategory:', error);
    }
}

function searchProducts() {
    filterProducts();
}

function filterProducts() {
    try {
        const searchInput = document.getElementById('searchInput');
        const karatFilter = document.getElementById('karatFilter');
        const sortFilter = document.getElementById('sortFilter');

        const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
        const karatValue = karatFilter ? karatFilter.value : '';
        const sortValue = sortFilter ? sortFilter.value : '';

        let visibleCount = 0;
        const allProducts = [];

        // Get all product items
        const productItems = document.querySelectorAll('.product-item, .product-row');
        
        productItems.forEach(product => {
            const show = shouldShowProduct(product, searchTerm, karatValue, currentSubcategory);
            
            if (show) {
                allProducts.push(product);
                visibleCount++;
            }
            
            // Hide/show based on filter results
            if (product.classList.contains('product-item')) {
                product.style.display = show ? 'block' : 'none';
                product.closest('.col-lg-3, .col-md-4, .col-sm-6').style.display = show ? 'block' : 'none';
            } else {
                product.style.display = show ? 'table-row' : 'none';
            }
        });

        // Apply sorting if needed
        if (sortValue && allProducts.length > 0) {
            applySorting(allProducts, sortValue);
        }

        // Update UI feedback
        updateFilterFeedback(visibleCount, searchTerm, karatValue, currentSubcategory);

    } catch (error) {
        console.error('Error filtering products:', error);
    }
}

function shouldShowProduct(product, searchTerm, karatValue, subcategoryValue) {
    try {
        const productName = (product.getAttribute('data-name') || '').toLowerCase();
        const productSubcategory = product.getAttribute('data-subcategory') || product.getAttribute('data-category') || '';
        const productMetal = product.getAttribute('data-metal') || currentMetal;

        // Check metal compatibility
        if (productMetal !== currentMetal) {
            return false;
        }

        // Check subcategory filter
        if (subcategoryValue !== 'all' && productSubcategory !== subcategoryValue) {
            return false;
        }

        // Check search term
        if (searchTerm && !productName.includes(searchTerm)) {
            return false;
        }

        // Check karat filter
        if (karatValue) {
            const productId = product.getAttribute('data-product-id');
            let karatSelect = document.getElementById(`karat_${productId}`);
            if (!karatSelect) {
                karatSelect = document.getElementById(`karat_list_${productId}`);
            }
            const selectedKarat = karatSelect ? karatSelect.value : '18';

            if (selectedKarat !== karatValue) {
                return false;
            }
        }

        return true;
    } catch (error) {
        console.error('Error in shouldShowProduct:', error);
        return true; // Default to show if error
    }
}

function applySorting(products, sortValue) {
    try {
        const sortedProducts = Array.from(products).sort((a, b) => {
            switch (sortValue) {
                case 'name':
                    const nameA = (a.getAttribute('data-name') || '').toLowerCase();
                    const nameB = (b.getAttribute('data-name') || '').toLowerCase();
                    return nameA.localeCompare(nameB);
                
                case 'price_low':
                case 'price_high':
                    const priceA = getCurrentProductPrice(a);
                    const priceB = getCurrentProductPrice(b);
                    return sortValue === 'price_low' ? priceA - priceB : priceB - priceA;
                
                case 'featured':
                    const featuredA = a.querySelector('.badge.bg-warning') ? 1 : 0;
                    const featuredB = b.querySelector('.badge.bg-warning') ? 1 : 0;
                    return featuredB - featuredA;
                
                default:
                    return 0;
            }
        });

        // Reorder DOM elements
        sortedProducts.forEach((product, index) => {
            if (product.classList.contains('product-item')) {
                const container = product.closest('.col-lg-3, .col-md-4, .col-sm-6');
                const parent = container.parentNode;
                parent.appendChild(container);
            } else {
                const parent = product.parentNode;
                parent.appendChild(product);
            }
        });

    } catch (error) {
        console.error('Error applying sorting:', error);
    }
}

function getCurrentProductPrice(productElement) {
    try {
        const productId = productElement.getAttribute('data-product-id');
        const priceElement = document.getElementById(`total_price_${productId}`) || 
                           document.getElementById(`total_price_list_${productId}`);
        
        if (priceElement) {
            const priceText = priceElement.textContent.replace(/[^\d.]/g, '');
            return parseFloat(priceText) || 0;
        }
        return 0;
    } catch (error) {
        console.error('Error getting current product price:', error);
        return 0;
    }
}

function updateFilterFeedback(visibleCount, searchTerm, karatValue, subcategoryValue) {
    try {
        // Update product count if element exists
        const totalProductsElement = document.getElementById('totalProducts');
        if (totalProductsElement) {
            totalProductsElement.textContent = visibleCount;
        }

        // Show/hide no products message
        const noProductsMessage = document.getElementById('noProductsMessage');
        if (noProductsMessage) {
            if (visibleCount === 0) {
                noProductsMessage.classList.remove('d-none');
                
                // Update message based on active filters
                let message = 'No products found';
                const reasons = [];
                
                if (searchTerm) reasons.push(`search: "${searchTerm}"`);
                if (karatValue) reasons.push(`karat: ${karatValue}K`);
                if (subcategoryValue !== 'all') reasons.push(`category: ${subcategoryValue}`);
                
                if (reasons.length > 0) {
                    message += ` for ${reasons.join(', ')}`;
                }
                
                const messageTitle = noProductsMessage.querySelector('h5');
                if (messageTitle) messageTitle.textContent = message;
                
            } else {
                noProductsMessage.classList.add('d-none');
            }
        }

        console.log(`Filter applied: ${visibleCount} products visible`);
        
    } catch (error) {
        console.error('Error updating filter feedback:', error);
    }
}

// ============================
// DYNAMIC METAL/SUBCATEGORY FUNCTIONS
// ============================

function getCurrentMetal() {
    return metalCategories.find(metal => metal.slug === currentMetal) || metalCategories[0];
}

function getAvailableKarats(metalSlug) {
    const metal = metalCategories.find(m => m.slug === metalSlug);
    if (!metal) return [];

    // Get available karats/purities from database
    if (metal.purity_ratios) {
        return Object.keys(metal.purity_ratios);
    }

    // Fallback based on metal type
    switch (metal.symbol) {
        case 'XAU':
            return ['9', '10', '14', '18', '19', '20', '21', '22', '23', '24'];
        case 'XAG':
            return ['800', '900', '925', '950', '999'];
        case 'XPT':
            return ['850', '900', '950', '999'];
        case 'XPD':
            return ['500', '950', '999'];
        default:
            return ['18'];
    }
}

function getSubcategoriesForMetal(metalSlug) {
    // Filter subcategories that are compatible with the current metal
    return subcategories.filter(subcategory => {
        // Check if this subcategory is associated with this metal
        // This would typically come from the database relationship
        if (subcategory.metal_categories && subcategory.metal_categories.includes) {
            return subcategory.metal_categories.includes(metalSlug);
        }
        // If no specific association, show all subcategories
        return true;
    });
}

function populateScrapKaratOptions() {
    const scrapKaratSelect = document.getElementById('scrapKarat');
    if (!scrapKaratSelect) return;

    const currentMetalObj = getCurrentMetal();
    if (!currentMetalObj) return;

    const availableKarats = getAvailableKarats(currentMetal);

    scrapKaratSelect.innerHTML = '<option value="">Select Purity</option>';

    availableKarats.forEach(karat => {
        const option = document.createElement('option');
        option.value = karat;

        if (currentMetalObj.symbol === 'XAU') {
            option.textContent = `${karat}K Gold (${((karat/24) * 100).toFixed(1)}% Pure)`;
        } else {
            const purityPercent = currentMetalObj.purity_ratios?.[karat]
                ? (currentMetalObj.purity_ratios[karat] * 100).toFixed(1)
                : karat.length === 3 ? (karat/10).toFixed(1) : karat;
            option.textContent = `${karat} ${currentMetalObj.name} (${purityPercent}% Pure)`;
        }

        scrapKaratSelect.appendChild(option);
    });
}

// ============================
// PRICE CALCULATION ENGINES
// ============================

function calculateJewelryPrice(productId, weight, karatOrPurity, subcategory, metal = 'gold') {
    // Get the current price for the specified karat/purity (already includes purity calculation)
    let currentPriceWithPurity;

    if (metalPricesPerGram[metal] && metalPricesPerGram[metal][karatOrPurity]) {
        currentPriceWithPurity = metalPricesPerGram[metal][karatOrPurity];
    } else {
        // Fallback to a default price
        currentPriceWithPurity = 64.13; // Default fallback
    }

    // Metal weight × current price × purity (purity is already included in the price we retrieved)
    const metalValue = weight * currentPriceWithPurity;

    // Labor cost - get from dynamic configuration
    const laborCostPerGram = tradingConfig.jewelry.laborCosts[subcategory] || 15.00;
    const totalLaborCost = weight * laborCostPerGram;

    // Base cost = metal value + labor cost
    const baseCost = metalValue + totalLaborCost;

    // Final price = base cost + profit margin
    const profitMargin = baseCost * tradingConfig.jewelry.profitMargin;
    const finalPrice = baseCost + profitMargin;

    return {
        currentPriceWithPurity: currentPriceWithPurity,
        metalValue: metalValue,
        laborCost: totalLaborCost,
        baseCost: baseCost,
        profitMargin: profitMargin,
        finalPrice: finalPrice,
        pricePerGram: finalPrice / weight,
        breakdown: {
            metalValue: metalValue,
            laborValue: totalLaborCost,
            profitValue: profitMargin,
            totalValue: finalPrice
        }
    };
}

function calculateScrapPrice(weight, karatOrPurity, metal = 'gold') {
    // Get the current price for the specified karat/purity
    let currentPriceWithPurity;

    if (metalPricesPerGram[metal] && metalPricesPerGram[metal][karatOrPurity]) {
        currentPriceWithPurity = metalPricesPerGram[metal][karatOrPurity];
    } else {
        currentPriceWithPurity = 64.13; // Default fallback
    }

    // Metal weight × current price × purity
    const grossValue = weight * currentPriceWithPurity;

    // Processing fee (15% of gross value)
    const processingFee = grossValue * tradingConfig.scrap.processingFee;

    // Additional margin by karat/purity
    const margins = tradingConfig.scrap.margins[metal] || {};
    const marginRate = margins[karatOrPurity] || 0.10;
    const marginDeduction = grossValue * marginRate;

    // Final offer = gross value - processing fee - margin
    const totalDeductions = processingFee + marginDeduction;
    const offerValue = grossValue - totalDeductions;
    const offerPricePerGram = offerValue / weight;

    return {
        currentPriceWithPurity: currentPriceWithPurity,
        grossValue: grossValue,
        processingFee: processingFee,
        marginDeduction: marginDeduction,
        totalDeductions: totalDeductions,
        offerValue: offerValue,
        offerPricePerGram: offerPricePerGram,
        breakdown: {
            grossValue: grossValue,
            processingFeeAmount: processingFee,
            marginAmount: marginDeduction,
            netOffer: offerValue
        }
    };
}

// ============================
// PRODUCT MANAGEMENT
// ============================

function updateProductPriceOnKaratChange(productId) {
    try {
        const karatSelect = document.getElementById(`karat_${productId}`) ||
                           document.getElementById(`karat_list_${productId}`);

        if (!karatSelect) return;

        const selectedKaratOrPurity = karatSelect.value;
        const productElement = document.querySelector(`[data-product-id="${productId}"]`);
        const metal = productElement?.getAttribute('data-metal') || currentMetal;

        // Get the current price with purity already calculated
        let currentPriceWithPurity;

        if (metalPricesPerGram[metal] && metalPricesPerGram[metal][selectedKaratOrPurity]) {
            currentPriceWithPurity = metalPricesPerGram[metal][selectedKaratOrPurity];
        } else {
            currentPriceWithPurity = 64.13; // Fallback
        }

        // Update price per gram displays
        const priceElements = [
            document.getElementById(`price_per_gram_${productId}`),
            document.getElementById(`price_per_gram_list_${productId}`)
        ];

        priceElements.forEach(element => {
            if (element) {
                element.textContent = currentPriceWithPurity.toFixed(2);
            }
        });

        // Update karat/purity display
        const karatDisplayElement = document.getElementById(`karat_display_${productId}`);
        if (karatDisplayElement) {
            const metalObj = getCurrentMetal();
            const displayText = metalObj?.symbol === 'XAU' ?
                `${selectedKaratOrPurity}K ${metalObj.name}` :
                `${selectedKaratOrPurity} ${metalObj.name}`;
            karatDisplayElement.textContent = displayText;
        }

        // Sync both dropdowns
        const gridKaratSelect = document.getElementById(`karat_${productId}`);
        const listKaratSelect = document.getElementById(`karat_list_${productId}`);

        if (gridKaratSelect && listKaratSelect) {
            if (gridKaratSelect !== karatSelect) {
                gridKaratSelect.value = selectedKaratOrPurity;
            }
            if (listKaratSelect !== karatSelect) {
                listKaratSelect.value = selectedKaratOrPurity;
            }
        }

        updateProductTotalPrice(productId);

    } catch (error) {
        console.error('Error updating price on karat change:', error);
    }
}

function updateProductTotalPrice(productId) {
    try {
        let input, totalPriceDisplay, weightDisplay;

        if (currentView === 'grid') {
            input = document.getElementById(`weight_${productId}`);
            totalPriceDisplay = document.getElementById(`total_price_${productId}`);
            weightDisplay = document.getElementById(`weight_display_${productId}`);
        } else {
            input = document.getElementById(`weight_list_${productId}`);
            totalPriceDisplay = document.getElementById(`total_price_list_${productId}`);
            weightDisplay = document.getElementById(`weight_display_list_${productId}`);
        }

        if (!input || !totalPriceDisplay) return;

        const weight = parseFloat(input.value) || 1;
        if (weight <= 0) return;

        const karatSelect = document.getElementById(`karat_${productId}`) ||
                           document.getElementById(`karat_list_${productId}`);
        const selectedKaratOrPurity = karatSelect ? karatSelect.value : '18';

        // Get product details
        const productElement = document.querySelector(`[data-product-id="${productId}"]`);
        const subcategory = productElement ? (productElement.getAttribute('data-subcategory') || 'rings') : 'rings';
        const metal = productElement ? (productElement.getAttribute('data-metal') || currentMetal) : currentMetal;

        const pricing = calculateJewelryPrice(productId, weight, selectedKaratOrPurity, subcategory, metal);

        totalPriceDisplay.textContent = `AUD${pricing.finalPrice.toFixed(2)}`;

        if (weightDisplay) {
            weightDisplay.textContent = weight.toFixed(1);
        }
    } catch (error) {
        console.error('Error updating product total price:', error);
    }
}

function initializeProductPrices() {
    try {
        document.querySelectorAll('.product-item').forEach(productElement => {
            const productId = productElement.getAttribute('data-product-id');
            if (productId) {
                const gridKaratSelect = document.getElementById(`karat_${productId}`);
                const listKaratSelect = document.getElementById(`karat_list_${productId}`);

                // Get metal type and set appropriate default
                const metal = productElement.getAttribute('data-metal') || currentMetal;
                const metalObj = metalCategories.find(m => m.slug === metal);
                let defaultValue = '18'; // Fallback

                if (metalObj) {
                    const availableKarats = getAvailableKarats(metal);
                    if (availableKarats.length > 0) {
                        // Use a sensible default based on metal type
                        if (metalObj.symbol === 'XAU') {
                            defaultValue = availableKarats.includes('18') ? '18' : availableKarats[0];
                        } else {
                            defaultValue = availableKarats.includes('925') ? '925' :
                                          availableKarats.includes('950') ? '950' : availableKarats[0];
                        }
                    }
                }

                if (gridKaratSelect) gridKaratSelect.value = defaultValue;
                if (listKaratSelect) listKaratSelect.value = defaultValue;

                updateProductPriceOnKaratChange(productId);
            }
        });
    } catch (error) {
        console.error('Error initializing product prices:', error);
    }
}

function initializeProductData() {
    if (!document.getElementById('gridView')) return; // Skip if not on jewelry module

    const allProducts = [];
    document.querySelectorAll('.product-item').forEach(productElement => {
        try {
            const productId = productElement.getAttribute('data-product-id');
            const titleElement = productElement.querySelector('.card-title');
            const productName = titleElement ? titleElement.textContent.trim() : 'Unknown Product';
            const categoryElement = productElement.querySelector('.text-muted');
            const category = categoryElement ? categoryElement.textContent.trim() : 'Jewelry';
            const image = '/images/products/placeholder.jpg';

            if (productId) {
                allProducts.push({
                    id: productId,
                    name: productName,
                    category: category,
                    image: image
                });
            }
        } catch (error) {
            console.error('Error processing product:', error);
        }
    });
}

// ============================
// MODULE MANAGEMENT SYSTEM
// ============================

function switchModule(module) {
    currentModule = module;

    // Hide all sections
    document.querySelectorAll('.module-section').forEach(section => {
        section.classList.add('d-none');
    });

    // Show selected module
    const targetSection = document.getElementById(`${module}Section`);
    if (targetSection) {
        targetSection.classList.remove('d-none');
    }

    // Update navigation
    document.querySelectorAll('.nav-module').forEach(nav => {
        nav.classList.remove('active');
    });

    const activeNav = document.querySelector(`[data-module="${module}"]`);
    if (activeNav) {
        activeNav.classList.add('active');
    }

    // Clear cart when switching modules (optional)
    if (cart.length > 0) {
        if (confirm('Switching modules will clear your current cart. Continue?')) {
            cart = [];
            updateCartDisplay();
        } else {
            return;
        }
    }

    // Module-specific initialization
    switch(module) {
        case 'scrap':
            initializeScrapModule();
            break;
        case 'bullion_sell':
            initializeBullionSellModule();
            break;
        case 'bullion_buy':
            initializeBullionBuyModule();
            break;
        default:
            break;
    }
}

function switchMetal(metalSlug) {
    const metal = metalCategories.find(m => m.slug === metalSlug);
    if (!metal) return;

    currentMetal = metalSlug;

    // Update navigation
    document.querySelectorAll('.nav-metal').forEach(nav => {
        nav.classList.remove('active');
    });

    const activeNav = document.querySelector(`[data-metal="${metalSlug}"]`);
    if (activeNav) {
        activeNav.classList.add('active');
    }

    updateMetalPriceDisplay();
    updateAllProductPrices();
    populateScrapKaratOptions();

    // Update subcategory tabs for current metal
    updateSubcategoryTabs();
    
    // Reset filters and reapply
    currentSubcategory = 'all';
    filterProducts();
}

function updateSubcategoryTabs() {
    const subcategoryTabs = document.getElementById('subcategoryTabs');
    if (!subcategoryTabs) return;

    const compatibleSubcategories = getSubcategoriesForMetal(currentMetal);

    // Rebuild subcategory navigation
    subcategoryTabs.innerHTML = `
        <li class="nav-item">
            <button class="nav-link active" data-subcategory="all" onclick="filterBySubcategory('all')">
                All Items
            </button>
        </li>
    `;

    compatibleSubcategories.forEach(subcategory => {
        const navItem = document.createElement('li');
        navItem.className = 'nav-item';
        navItem.innerHTML = `
            <button class="nav-link" data-subcategory="${subcategory.slug}" onclick="filterBySubcategory('${subcategory.slug}')">
                ${subcategory.name}
            </button>
        `;
        subcategoryTabs.appendChild(navItem);
    });
}

function updatePriceDisplays() {
    updateMetalPriceDisplay();

    const lastUpdated = document.getElementById('lastUpdated');
    if (lastUpdated && currentMetalPrices.last_updated) {
        lastUpdated.textContent = `Last updated: ${currentMetalPrices.last_updated.toLocaleTimeString()}`;
    }
}

function updateMetalPriceDisplay() {
    const priceDisplay = document.getElementById('metalPricesDisplay');
    if (!priceDisplay) return;

    const currentPrices = metalPricesPerGram[currentMetal] || {};

    let priceHTML = Object.entries(currentPrices)
        .map(([purity, price]) => {
            const metal = getCurrentMetal();
            const displayText = metal?.symbol === 'XAU' ? `${purity}K` : purity;
            return `<small class="badge bg-light text-dark me-1">${displayText}: AUD${price.toFixed(2)}</small>`;
        }).join('');

    if (priceHTML) {
        priceDisplay.innerHTML = priceHTML;
    } else {
        priceDisplay.innerHTML = '<small class="text-muted">Prices loading...</small>';
    }
}

function updateAllProductPrices() {
    document.querySelectorAll('.product-item').forEach(productElement => {
        const productId = productElement.getAttribute('data-product-id');
        if (productId) {
            updateProductPriceOnKaratChange(productId);
        }
    });

    if (currentModule === 'scrap') {
        updateScrapPriceDisplay();
    }

    if (currentModule === 'bullion_sell') {
        updateBullionSellDisplay();
    }

    if (currentModule === 'bullion_buy') {
        updateBullionBuyDisplay();
    }
}

// ============================
// UTILITY FUNCTIONS
// ============================

function adjustWeight(productId, change) {
    try {
        let input;
        if (currentView === 'grid') {
            input = document.getElementById(`weight_${productId}`);
        } else {
            input = document.getElementById(`weight_list_${productId}`);
        }

        if (!input) return;

        const currentWeight = parseFloat(input.value) || 1;
        const newWeight = Math.max(0.1, Math.round((currentWeight + change) * 10) / 10);
        input.value = newWeight;
        validateAndUpdatePrice(productId);
    } catch (error) {
        console.error('Error adjusting weight:', error);
    }
}

function validateAndUpdatePrice(productId) {
    try {
        let input, errorDiv;

        if (currentView === 'grid') {
            input = document.getElementById(`weight_${productId}`);
            errorDiv = document.getElementById(`error_${productId}`);
        } else {
            input = document.getElementById(`weight_list_${productId}`);
            errorDiv = document.getElementById(`error_list_${productId}`);
        }

        if (!input) return false;

        const weight = parseFloat(input.value);
        if (isNaN(weight) || weight <= 0) {
            if (errorDiv) {
                errorDiv.style.display = 'block';
                errorDiv.textContent = 'Weight must be greater than 0';
            }
            return false;
        }

        if (errorDiv) {
            errorDiv.style.display = 'none';
        }

        updateProductTotalPrice(productId);
        return true;
    } catch (error) {
        console.error('Error validating price:', error);
        return false;
    }
}

function updateAddToCartButtonStates(productId, isAdded) {
    const allButtons = document.querySelectorAll(`[data-product-id="${productId}"].add-to-cart-btn`);

    allButtons.forEach(button => {
        if (isAdded) {
            button.innerHTML = '<i class="fas fa-check me-1"></i>Added!';
            button.classList.add('btn-added');
            button.classList.remove('btn-primary');
            button.disabled = true;
        } else {
            button.innerHTML = '<i class="fas fa-cart-plus me-1"></i>Add';
            button.classList.remove('btn-added');
            button.classList.add('btn-primary');
            button.disabled = false;
        }
    });
}

function resetAllButtons() {
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.innerHTML = '<i class="fas fa-cart-plus me-1"></i>Add';
        button.classList.remove('btn-added');
        button.classList.add('btn-primary');
        button.disabled = false;
    });
}

function showNotification(message, type) {
    const alertClass = type === 'success' ? 'alert-success' :
                      type === 'warning' ? 'alert-warning' :
                      type === 'error' ? 'alert-danger' : 'alert-info';

    const alertHTML = `
        <div class="alert ${alertClass} alert-dismissible fade show position-fixed"
             style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;

    document.querySelectorAll('.alert.position-fixed').forEach(alert => alert.remove());
    document.body.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const alert = document.querySelector(`.${alertClass}.position-fixed`);
        if (alert) alert.remove();
    }, 5000);
}

// ============================
// VIEW MANAGEMENT SYSTEM
// ============================

function switchToGridView() {
    try {
        currentView = 'grid';

        const gridBtn = document.getElementById('gridViewBtn');
        const listBtn = document.getElementById('listViewBtn');

        if (gridBtn && listBtn) {
            gridBtn.classList.add('active');
            listBtn.classList.remove('active');
        }

        const gridView = document.getElementById('gridView');
        const listView = document.getElementById('listView');

        if (gridView) {
            gridView.classList.remove('d-none');
            gridView.classList.add('view-transition', 'show');
        }

        if (listView) {
            listView.classList.add('d-none');
        }

        localStorage.setItem('gold_trading_view', 'grid');
        
        // Reapply filters after view change
        filterProducts();
    } catch (error) {
        console.error('Error switching to grid view:', error);
    }
}

function switchToListView() {
    try {
        currentView = 'list';

        const gridBtn = document.getElementById('gridViewBtn');
        const listBtn = document.getElementById('listViewBtn');

        if (gridBtn && listBtn) {
            gridBtn.classList.remove('active');
            listBtn.classList.add('active');
        }

        const gridView = document.getElementById('gridView');
        const listView = document.getElementById('listView');

        if (gridView) {
            gridView.classList.add('d-none');
        }

        if (listView) {
            listView.classList.remove('d-none');
            listView.classList.add('view-transition', 'show');
        }

        localStorage.setItem('gold_trading_view', 'list');
        
        // Reapply filters after view change
        filterProducts();
    } catch (error) {
        console.error('Error switching to list view:', error);
    }
}

// ============================
// EVENT LISTENERS SETUP
// ============================

function setupEventListeners() {
    if (document.body.hasAttribute('data-listeners-setup')) {
        return;
    }

    try {
        // Jewelry module event listeners
        const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
        addToCartButtons.forEach((button) => {
            if (button.hasAttribute('data-listener-added')) return;

            const productId = button.getAttribute('data-product-id');
            const productName = button.getAttribute('data-product-name') || 'Unknown Product';
            const productCategory = button.getAttribute('data-product-category') || 'Jewelry';
            const productImage = button.getAttribute('data-product-image') || '';

            button.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                addToCart(productId, productName, productCategory, productImage);
            });

            button.setAttribute('data-listener-added', 'true');
        });

        // Weight input events
        document.querySelectorAll('.weight-input').forEach(input => {
            if (input.hasAttribute('data-listener-added')) return;

            const productId = input.getAttribute('data-product-id');

            input.addEventListener('input', function() {
                validateAndUpdatePrice(productId);
            });
            input.addEventListener('change', function() {
                validateAndUpdatePrice(productId);
            });

            input.setAttribute('data-listener-added', 'true');
        });

        // Weight adjustment buttons
        document.querySelectorAll('.weight-btn-plus').forEach(button => {
            if (button.hasAttribute('data-listener-added')) return;

            button.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const productId = this.getAttribute('data-product-id');
                adjustWeight(productId, 0.1);
            });

            button.setAttribute('data-listener-added', 'true');
        });

        document.querySelectorAll('.weight-btn-minus').forEach(button => {
            if (button.hasAttribute('data-listener-added')) return;

            button.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const productId = this.getAttribute('data-product-id');
                adjustWeight(productId, -0.1);
            });

            button.setAttribute('data-listener-added', 'true');
        });

        // Search input event
        const searchInput = document.getElementById('searchInput');
        if (searchInput && !searchInput.hasAttribute('data-listener-added')) {
            searchInput.addEventListener('input', searchProducts);
            searchInput.addEventListener('keyup', searchProducts);
            searchInput.setAttribute('data-listener-added', 'true');
        }

        // Filter dropdowns
        const karatFilter = document.getElementById('karatFilter');
        if (karatFilter && !karatFilter.hasAttribute('data-listener-added')) {
            karatFilter.addEventListener('change', filterProducts);
            karatFilter.setAttribute('data-listener-added', 'true');
        }

        const sortFilter = document.getElementById('sortFilter');
        if (sortFilter && !sortFilter.hasAttribute('data-listener-added')) {
            sortFilter.addEventListener('change', filterProducts);
            sortFilter.setAttribute('data-listener-added', 'true');
        }

        // Manual price update button
        const updatePricesBtn = document.getElementById('updatePricesBtn');
        if (updatePricesBtn && !updatePricesBtn.hasAttribute('data-listener-added')) {
            updatePricesBtn.addEventListener('click', updateMetalPrices);
            updatePricesBtn.setAttribute('data-listener-added', 'true');
        }

        document.body.setAttribute('data-listeners-setup', 'true');

    } catch (error) {
        console.error('Error setting up event listeners:', error);
    }
}

// ============================
// CART MANAGEMENT SYSTEM
// ============================

function updateCartDisplay() {
    try {
        const cartItems = document.getElementById('cartItems');
        const emptyCart = document.getElementById('emptyCart');
        const cartSummary = document.getElementById('cartSummary');

        if (cart.length === 0) {
            if (emptyCart) emptyCart.style.display = 'block';
            if (cartSummary) cartSummary.classList.add('d-none');
            return;
        }

        if (emptyCart) emptyCart.style.display = 'none';
        if (cartSummary) cartSummary.classList.remove('d-none');

        let subtotal = 0;
        const cartHTML = cart.map((item, index) => {
            subtotal += Math.abs(item.totalPrice);
            const isNegative = item.totalPrice < 0 || item.type === 'scrap' || (item.type === 'bullion' && item.subtype === 'buy');
            const priceColor = isNegative ? 'text-danger' : 'text-primary';
            const typeIcon = item.type === 'scrap' ? 'fas fa-recycle' :
                           item.type === 'bullion' ? 'fas fa-coins' : 'fas fa-gem';

            return `
                <div class="cart-item p-2 border-bottom">
                    <div class="row align-items-center">
                        <div class="col-2">
                            <i class="${typeIcon} fa-2x text-muted"></i>
                        </div>
                        <div class="col-7">
                            <h6 class="mb-1" style="font-size: 0.85rem;">${item.productName}</h6>
                            <small class="text-muted">${item.productCategory}</small><br>
                            <small class="text-muted">${item.weight.toFixed(2)}g • ${item.productKarat}</small>
                            <div class="fw-bold ${priceColor}">
                                ${isNegative ? '-' : ''}AUD${Math.abs(item.totalPrice).toFixed(2)}
                            </div>
                        </div>
                        <div class="col-3 text-end">
                            <button class="btn btn-outline-danger btn-sm" onclick="removeFromCart(${index})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        if (cartItems) cartItems.innerHTML = cartHTML;

        // Calculate totals based on transaction types
        let totalRevenue = 0;
        let totalExpenses = 0;

        cart.forEach(item => {
            if (item.type === 'scrap' || (item.type === 'bullion' && item.subtype === 'buy')) {
                totalExpenses += Math.abs(item.totalPrice);
            } else {
                totalRevenue += Math.abs(item.totalPrice);
            }
        });

        const netTotal = totalRevenue - totalExpenses;
        const tax = Math.max(0, totalRevenue * 0.10);
        const finalTotal = netTotal + tax;

        const cartSubtotal = document.getElementById('cartSubtotal');
        const cartTax = document.getElementById('cartTax');
        const cartTotal = document.getElementById('cartTotal');

        if (cartSubtotal) cartSubtotal.textContent = `AUD${netTotal.toFixed(2)}`;
        if (cartTax) cartTax.textContent = `AUD${tax.toFixed(2)}`;
        if (cartTotal) cartTotal.textContent = `AUD${finalTotal.toFixed(2)}`;
    } catch (error) {
        console.error('Error updating cart display:', error);
    }
}

function addToCart(productId, productName, productCategory, productImage) {
    try {
        let weightInput;
        if (currentView === 'grid') {
            weightInput = document.getElementById(`weight_${productId}`);
        } else {
            weightInput = document.getElementById(`weight_list_${productId}`);
        }

        if (!weightInput) {
            showNotification('Error: Product weight input not found', 'error');
            return;
        }

        const weight = parseFloat(weightInput.value);
        if (isNaN(weight) || weight <= 0) {
            showNotification('Please enter a valid weight greater than 0', 'error');
            weightInput.focus();
            return;
        }

        const karatSelect = document.getElementById(`karat_${productId}`) ||
                           document.getElementById(`karat_list_${productId}`);
        const selectedKaratOrPurity = karatSelect ? karatSelect.value : '18';

        // Get product details
        const productElement = document.querySelector(`[data-product-id="${productId}"]`);
        const metal = productElement ? (productElement.getAttribute('data-metal') || 'gold') : 'gold';

        const categoryMapping = {
            'Bracelets': 'bracelets',
            'Necklaces': 'necklaces',
            'Rings': 'rings',
            'Chains': 'chains',
            'Full Sets': 'full-sets',
            'Half Sets': 'half-sets',
            'Anklets': 'anklets',
            'Earrings': 'earrings'
        };

        const category = categoryMapping[productCategory] || 'rings';
        const pricing = calculateJewelryPrice(productId, weight, selectedKaratOrPurity, category, metal);

        let finalImage = '/images/products/placeholder.jpg';
        if (productImage && productImage !== '/images/products/default-product.jpg') {
            finalImage = productImage;
        }

        // Create display text for karat/purity
        const displayKarat = metal === 'gold' ? `${selectedKaratOrPurity}K` : selectedKaratOrPurity;

        const cartItem = {
            type: 'jewelry',
            metal: metal,
            productId: productId,
            productName: productName,
            productKarat: displayKarat,
            productCategory: productCategory,
            productImage: finalImage,
            weight: weight,
            pricePerGram: pricing.pricePerGram,
            totalPrice: pricing.finalPrice,
            metalCost: pricing.metalValue,
            laborCost: pricing.laborCost
        };

        cart.push(cartItem);
        updateCartDisplay();
        updateAddToCartButtonStates(productId, true);

        const karatDisplayText = metal === 'gold' ? `${selectedKaratOrPurity}K` : `${selectedKaratOrPurity} purity`;
        showNotification(`${productName} (${karatDisplayText}) added to cart!`, 'success');
    } catch (error) {
        console.error('Error adding to cart:', error);
        showNotification('Error adding product to cart', 'error');
    }
}

function removeFromCart(index) {
    try {
        if (index < 0 || index >= cart.length) {
            showNotification('Error: Invalid item index', 'error');
            return;
        }

        if (cart[index]) {
            const itemName = cart[index].productName;
            const productId = cart[index].productId;
            cart.splice(index, 1);
            updateCartDisplay();

            if (cart[index] && cart[index].type === 'jewelry') {
                updateAddToCartButtonStates(productId, false);
            }

            showNotification(`${itemName} removed from cart`, 'info');
        }
    } catch (error) {
        console.error('Error removing item from cart:', error);
        showNotification('Error removing item from cart', 'error');
    }
}

function clearCart() {
    try {
        if (cart.length === 0) {
            showNotification('Cart is already empty', 'info');
            return;
        }

        if (confirm('Are you sure you want to clear your cart?')) {
            cart.forEach(item => {
                if (item.type === 'jewelry') {
                    updateAddToCartButtonStates(item.productId, false);
                }
            });

            cart = [];
            updateCartDisplay();
            showNotification('Cart cleared', 'info');
        }
    } catch (error) {
        console.error('Error clearing cart:', error);
        showNotification('Error clearing cart', 'error');
    }
}

function updateCartItemWeight(index, newWeight) {
    try {
        const weight = parseFloat(newWeight);
        if (isNaN(weight) || weight <= 0) {
            showNotification('Weight must be greater than 0', 'error');
            if (cart[index]) {
                const weightInput = document.querySelector(`input[onchange="updateCartItemWeight(${index}, this.value)"]`);
                if (weightInput) {
                    weightInput.value = cart[index].weight;
                }
            }
            return;
        }

        if (cart[index] && cart[index].type === 'jewelry') {
            const item = cart[index];
            item.weight = weight;

            // Get the metal type and karat/purity from the cart item
            const metal = item.metal || 'gold';
            const karatOrPurity = metal === 'gold' ?
                item.productKarat.replace('K', '') :
                item.productKarat;

            // Recalculate jewelry price with labor costs
            const categoryMapping = {
                'Bracelets': 'bracelets',
                'Necklaces': 'necklaces',
                'Rings': 'rings',
                'Chains': 'chains',
                'Full Sets': 'full-sets',
                'Half Sets': 'half-sets',
                'Anklets': 'anklets',
                'Earrings': 'earrings'
            };
            const category = categoryMapping[item.productCategory] || 'rings';
            const pricing = calculateJewelryPrice(item.productId, weight, karatOrPurity, category, metal);

            item.totalPrice = pricing.finalPrice;
            item.pricePerGram = pricing.pricePerGram;
            item.metalCost = pricing.metalValue;
            item.laborCost = pricing.laborCost;
        } else {
            // For scrap and bullion, simple recalculation
            cart[index].weight = weight;
            cart[index].totalPrice = cart[index].pricePerGram * weight;
        }

        updateCartDisplay();
    } catch (error) {
        console.error('Error updating cart item weight:', error);
    }
}

// ============================
// SCRAP MODULE SYSTEM
// ============================

function initializeScrapModule() {
    updateScrapPriceDisplay();
}

function updateScrapPriceDisplay() {
    const container = document.getElementById('scrapPricesContainer');
    if (!container) return;

    const currentPrices = metalPricesPerGram[currentMetal] || {};
    const margins = tradingConfig.scrap.margins[currentMetal] || {};

    let scrapHTML = Object.entries(currentPrices).map(([purity, basePrice]) => {
        const margin = margins[purity] || 0.10;
        const offerPrice = basePrice * (1 - tradingConfig.scrap.processingFee - margin);

        const metal = getCurrentMetal();
        const displayText = metal?.symbol === 'XAU' ? `${purity}K ${metal.name}` : `${purity} ${metal.name}`;
        const purityPercent = metal?.symbol === 'XAU'
            ? ((purity/24) * 100).toFixed(1)
            : (purity.length === 3 ? (purity/10).toFixed(1) : purity);

        return `
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card border-warning">
                    <div class="card-body text-center py-2">
                        <h6 class="card-title mb-1">${displayText}</h6>
                        <div class="text-muted small">${purityPercent}% Pure</div>
                        <div class="fw-bold text-warning">AUD${offerPrice.toFixed(2)}/g</div>
                        <small class="text-muted">Our Buy Price</small>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    container.innerHTML = scrapHTML;
}

function calculateScrapValue() {
    const karatOrPurity = document.getElementById('scrapKarat').value;
    const weight = parseFloat(document.getElementById('scrapWeight').value);

    if (!karatOrPurity || !weight || weight <= 0) {
        document.getElementById('scrapValue').innerHTML = '<div class="text-muted">Enter weight to see offer</div>';
        return;
    }

    const basePrice = metalPricesPerGram[currentMetal]?.[karatOrPurity];
    if (!basePrice) {
        document.getElementById('scrapValue').innerHTML = '<div class="text-muted">Invalid selection</div>';
        return;
    }

    const margins = tradingConfig.scrap.margins[currentMetal] || {};
    const margin = margins[karatOrPurity] || 0.10;
    const offerPrice = basePrice * (1 - tradingConfig.scrap.processingFee - margin);
    const totalValue = weight * offerPrice;

    const metal = getCurrentMetal();
    const displayUnit = metal?.symbol === 'XAU' ? `${karatOrPurity}K` : karatOrPurity;

    document.getElementById('scrapValue').innerHTML = `
        <div class="text-center">
            <div class="h4 text-success">AUD${totalValue.toFixed(2)}</div>
            <small class="text-muted">for ${weight}g of ${displayUnit} ${metal?.name || 'metal'}</small>
            <div class="mt-2">
                <small class="text-info">Rate: AUD${offerPrice.toFixed(2)} per gram</small>
            </div>
        </div>
    `;
}

function addScrapToCart() {
    const karatOrPurity = document.getElementById('scrapKarat').value;
    const weight = parseFloat(document.getElementById('scrapWeight').value);
    const description = document.getElementById('scrapDescription').value || `Scrap ${getCurrentMetal()?.name || 'Metal'}`;

    if (!karatOrPurity || !weight || weight <= 0) {
        showNotification('Please enter valid purity and weight', 'error');
        return;
    }

    const basePrice = metalPricesPerGram[currentMetal]?.[karatOrPurity];
    if (!basePrice) {
        showNotification('Invalid metal purity selection', 'error');
        return;
    }

    const margins = tradingConfig.scrap.margins[currentMetal] || {};
    const margin = margins[karatOrPurity] || 0.10;
    const offerPrice = basePrice * (1 - tradingConfig.scrap.processingFee - margin);
    const totalValue = weight * offerPrice;

    const metalObj = getCurrentMetal();
    const displayUnit = metalObj?.symbol === 'XAU' ? `${karatOrPurity}K` : karatOrPurity;

    const cartItem = {
        type: 'scrap',
        metal: currentMetal,
        productId: `scrap_${currentMetal}_${Date.now()}`,
        productName: `${description} (${displayUnit})`,
        productKarat: displayUnit,
        productCategory: `Scrap ${metalObj?.name || 'Metal'} Purchase`,
        weight: weight,
        pricePerGram: offerPrice,
        totalPrice: -totalValue,
        description: description
    };

    cart.push(cartItem);
    updateCartDisplay();

    // Reset form
    document.getElementById('scrapWeight').value = '';
    document.getElementById('scrapDescription').value = '';
    document.getElementById('scrapValue').innerHTML = '<div class="text-muted">Enter weight to see offer</div>';

    showNotification(`${description} added to cart!`, 'success');
}

// ============================
// BULLION MODULE SYSTEM
// ============================

function initializeBullionSellModule() {
    updateBullionSellDisplay();
}

function initializeBullionBuyModule() {
    updateBullionBuyDisplay();
}

function updateBullionSellDisplay() {
    const container = document.getElementById('bullionSellContainer');
    if (!container) return;

    const metalObj = getCurrentMetal();
    if (!metalObj) return;

    // Get highest purity price for bullion
    const currentPrices = metalPricesPerGram[currentMetal] || {};
    const availableKarats = getAvailableKarats(currentMetal);
    const highestPurity = availableKarats[availableKarats.length - 1]; // Usually 999 or 24
    const basePrice = currentPrices[highestPurity] || 0;

    const sellPremium = tradingConfig.bullion.sellPremium[currentMetal] || 0.08;
    const sellPrice = basePrice * (1 + sellPremium);

    const bullionHTML = Object.entries(tradingConfig.bullion.sizes).map(([size, config]) => {
        const totalPrice = sellPrice * config.weight;
        const purity = metalObj.symbol === 'XAU' ? '24K' : '999';

        return `
            <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="card border-success h-100">
                    <div class="card-body text-center">
                        <h6 class="card-title">${size === '0.5oz' || size === '1oz' ? size : size + 'g'}</h6>
                        <div class="text-muted small mb-2">${config.weight.toFixed(2)}g • ${purity} ${metalObj.name}</div>
                        <div class="fw-bold text-success h5">AUD${totalPrice.toFixed(2)}</div>
                        <button class="btn btn-success btn-sm w-100 mt-2"
                                onclick="addBullionToCart('${size}', ${config.weight}, ${sellPrice}, 'sell', '${currentMetal}')">
                            <i class="fas fa-cart-plus me-1"></i>Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    container.innerHTML = bullionHTML;
}

function updateBullionBuyDisplay() {
    const container = document.getElementById('bullionBuyContainer');
    if (!container) return;

    const metalObj = getCurrentMetal();
    if (!metalObj) return;

    // Get highest purity price for bullion
    const currentPrices = metalPricesPerGram[currentMetal] || {};
    const availableKarats = getAvailableKarats(currentMetal);
    const highestPurity = availableKarats[availableKarats.length - 1];
    const basePrice = currentPrices[highestPurity] || 0;

    const buyMargin = tradingConfig.bullion.buyMargin[currentMetal] || 0.05;
    const buyPrice = basePrice * (1 - buyMargin);

    const bullionHTML = Object.entries(tradingConfig.bullion.sizes).map(([size, config]) => {
        const totalPrice = buyPrice * config.weight;
        const purity = metalObj.symbol === 'XAU' ? '24K' : '999';

        return `
            <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="card border-info h-100">
                    <div class="card-body text-center">
                        <h6 class="card-title">${size === '0.5oz' || size === '1oz' ? size : size + 'g'}</h6>
                        <div class="text-muted small mb-2">${config.weight.toFixed(2)}g • ${purity} ${metalObj.name}</div>
                        <div class="fw-bold text-info h5">AUD${totalPrice.toFixed(2)}</div>
                        <button class="btn btn-info btn-sm w-100 mt-2"
                                onclick="addBullionToCart('${size}', ${config.weight}, ${buyPrice}, 'buy', '${currentMetal}')">
                            <i class="fas fa-handshake me-1"></i>We Buy
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    container.innerHTML = bullionHTML;
}

function addBullionToCart(size, weight, pricePerGram, type, metal) {
    const totalPrice = weight * pricePerGram;
    const displaySize = (size === '0.5oz' || size === '1oz') ? size : size + 'g';
    const metalObj = metalCategories.find(m => m.slug === metal);
    const metalName = metalObj ? metalObj.name : 'Metal';
    const purity = metalObj?.symbol === 'XAU' ? '24K' : '999';

    const cartItem = {
        type: 'bullion',
        subtype: type,
        metal: metal,
        productId: `bullion_${metal}_${type}_${size}_${Date.now()}`,
        productName: `${displaySize} ${metalName} Bullion`,
        productKarat: purity,
        productCategory: type === 'sell' ? `${metalName} Bullion Sale` : `${metalName} Bullion Purchase`,
        weight: weight,
        pricePerGram: pricePerGram,
        totalPrice: type === 'buy' ? -totalPrice : totalPrice,
        size: displaySize
    };

    cart.push(cartItem);
    updateCartDisplay();
    showNotification(`${displaySize} ${metalName} bullion added to cart!`, 'success');
}

// ============================
// CUSTOMER SEARCH SYSTEM
// ============================

function initializeCustomerSearch() {
    const searchInput = document.getElementById('customerSearch');
    if (searchInput && !searchInput.hasAttribute('data-listener-added')) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimer);
            const query = this.value.trim();
            if (query.length >= 2) {
                searchTimer = setTimeout(() => {
                    performCustomerSearch(query);
                }, 300);
            } else {
                clearSearchResults();
            }
        });

        searchInput.addEventListener('blur', function() {
            setTimeout(() => {
                clearSearchResults();
            }, 200);
        });

        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const query = this.value.trim();
                if (query.length >= 2) {
                    performCustomerSearch(query);
                }
            }
        });

        searchInput.setAttribute('data-listener-added', 'true');
    }
}

function performCustomerSearch(query) {
    const resultsElement = document.getElementById('customerSearchResults');
    if (resultsElement) resultsElement.innerHTML = '<div class="p-2 text-muted">Searching...</div>';

    fetch('/api/customers/search?query=' + encodeURIComponent(query), {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.success && data.data && data.data.length > 0) {
            displayCustomerSearchResults(data.data);
        } else {
            displayNoCustomersFound();
        }
    })
    .catch(error => {
        console.error('Customer search error:', error);
        displayNoCustomersFound();
    });
}

function displayCustomerSearchResults(customers) {
    const resultsContainer = document.getElementById('customerSearchResults');
    if (!resultsContainer) return;

    const resultsHTML = customers.map(customer => {
        const safeName = escapeHtml(customer.full_name || customer.name || `${customer.first_name} ${customer.last_name}`);
        const safeEmail = escapeHtml(customer.email || '');
        const safePhone = escapeHtml(customer.phone || '');
        const safePassportId = escapeHtml(customer.passport_id_number || customer.passport_id || '');

        return `
            <div class="card mb-2 border shadow-sm customer-result" style="cursor: pointer;">
                <div class="card-body p-2">
                    <div class="row align-items-center">
                        <div class="col">
                            <h6 class="mb-1">${safeName}</h6>
                            <small class="text-muted">
                                ${safeEmail}${safePhone ? ' • ' + safePhone : ''}
                                ${safePassportId ? ' • ID: ' + safePassportId : ''}
                            </small>
                        </div>
                        <div class="col-auto">
                            <button class="btn btn-sm btn-primary select-customer-btn"
                                    data-customer='${JSON.stringify(customer).replace(/'/g, "&apos;")}'>
                                Select
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    resultsContainer.innerHTML = resultsHTML;
    resultsContainer.style.display = 'block';

    resultsContainer.querySelectorAll('.select-customer-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const customerData = JSON.parse(this.getAttribute('data-customer'));
            selectCustomer(customerData);
        });
    });
}

function selectCustomer(customer) {
    selectedCustomer = customer;

    try {
        const customerIdField = document.getElementById('customerId');
        const customerFirstNameField = document.getElementById('customerFirstName');
        const customerLastNameField = document.getElementById('customerLastName');
        const customerEmailField = document.getElementById('customerEmail');
        const customerPhoneField = document.getElementById('customerPhone');
        const customerPassportField = document.getElementById('customerPassportId');

        if (customerIdField) customerIdField.value = customer.id || '';
        if (customerFirstNameField) customerFirstNameField.value = customer.first_name || '';
        if (customerLastNameField) customerLastNameField.value = customer.last_name || '';
        if (customerEmailField) customerEmailField.value = customer.email || '';
        if (customerPhoneField) customerPhoneField.value = customer.phone || '';
        if (customerPassportField) customerPassportField.value = customer.passport_id_number || customer.passport_id || '';

        document.querySelectorAll('#checkoutForm .is-invalid').forEach(field => {
            field.classList.remove('is-invalid');
        });

        const searchInput = document.getElementById('customerSearch');
        if (searchInput) searchInput.value = '';
        clearSearchResults();

        showNotification('Customer selected successfully', 'success');
    } catch (error) {
        console.error('Error selecting customer:', error);
        showNotification('Error selecting customer', 'error');
    }
}

function displayNoCustomersFound() {
    const resultsContainer = document.getElementById('customerSearchResults');
    if (!resultsContainer) return;

    resultsContainer.innerHTML = `
        <div class="alert alert-info mb-2">
            <i class="fas fa-info-circle me-2"></i>
            No customers found. A new customer record will be created when you place the order.
        </div>
    `;
    resultsContainer.style.display = 'block';
}

function clearSearchResults() {
    const resultsContainer = document.getElementById('customerSearchResults');
    if (resultsContainer) {
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

// ============================
// CHECKOUT SYSTEM
// ============================

function proceedToCheckout() {
    try {
        if (cart.length === 0) {
            showNotification('Your cart is empty', 'warning');
            return;
        }

        const mainContainer = document.querySelector('.container-fluid');
        const checkoutSection = document.getElementById('checkoutSection');

        if (mainContainer) mainContainer.classList.add('d-none');
        if (checkoutSection) checkoutSection.classList.remove('d-none');

        displayCheckoutItems();
        window.scrollTo({top: 0, behavior: 'smooth'});
    } catch (error) {
        console.error('Error proceeding to checkout:', error);
    }
}

function displayCheckoutItems() {
    try {
        const container = document.getElementById('checkoutItems');
        if (!container) return;

        const itemsHTML = cart.map(item => {
            const typeIcon = item.type === 'scrap' ? 'fas fa-recycle text-warning' :
                           item.type === 'bullion' ? 'fas fa-coins text-info' : 'fas fa-gem text-primary';
            const isNegative = item.type === 'scrap' || (item.type === 'bullion' && item.subtype === 'buy');
            const priceColor = isNegative ? 'text-danger' : 'text-primary';

            return `
                <div class="checkout-item p-2 border-bottom">
                    <div class="row align-items-center">
                        <div class="col-2 text-center">
                            <i class="${typeIcon} fa-lg"></i>
                        </div>
                        <div class="col-10">
                            <h6 class="mb-1" style="font-size: 0.875rem;">${item.productName}</h6>
                            <small class="text-muted">${item.productCategory}</small><br>
                            <small class="text-muted">${item.weight.toFixed(2)}g • ${item.productKarat}</small>
                            <div class="fw-bold ${priceColor} mt-1">
                                ${isNegative ? '-' : ''}AUD${Math.abs(item.totalPrice).toFixed(2)}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = itemsHTML;
        updateCheckoutTotals();
    } catch (error) {
        console.error('Error displaying checkout items:', error);
    }
}

function updateCheckoutTotals() {
    try {
        let totalRevenue = 0;
        let totalExpenses = 0;

        cart.forEach(item => {
            if (item.type === 'scrap' || (item.type === 'bullion' && item.subtype === 'buy')) {
                totalExpenses += Math.abs(item.totalPrice);
            } else {
                totalRevenue += Math.abs(item.totalPrice);
            }
        });

        const netSubtotal = totalRevenue - totalExpenses;
        const tax = Math.max(0, totalRevenue * 0.10);
        const shipping = totalRevenue > 500 ? 0 : (totalRevenue > 0 ? 25 : 0);
        const total = netSubtotal + tax + shipping;

        const checkoutSubtotal = document.getElementById('checkoutSubtotal');
        const checkoutTax = document.getElementById('checkoutTax');
        const checkoutShipping = document.getElementById('checkoutShipping');
        const checkoutTotal = document.getElementById('checkoutTotal');

        if (checkoutSubtotal) checkoutSubtotal.textContent = `AUD${netSubtotal.toFixed(2)}`;
        if (checkoutTax) checkoutTax.textContent = `AUD${tax.toFixed(2)}`;
        if (checkoutShipping) checkoutShipping.innerHTML = shipping === 0 ? '<span class="text-success">FREE</span>' : `AUD${shipping.toFixed(2)}`;
        if (checkoutTotal) checkoutTotal.textContent = `AUD${total.toFixed(2)}`;
    } catch (error) {
        console.error('Error updating checkout totals:', error);
    }
}

function backToShopping() {
    try {
        const checkoutSection = document.getElementById('checkoutSection');
        const mainContainer = document.querySelector('.container-fluid');

        if (checkoutSection) checkoutSection.classList.add('d-none');
        if (mainContainer) mainContainer.classList.remove('d-none');

        window.scrollTo({top: 0, behavior: 'smooth'});
    } catch (error) {
        console.error('Error going back to shopping:', error);
    }
}

function placeOrder() {
    showNotification('Order placement feature will be implemented in the backend', 'info');
}

function startNewOrder() {
    try {
        cart = [];
        selectedCustomer = null;
        updateCartDisplay();

        const form = document.getElementById('checkoutForm');
        if (form) form.reset();

        const customerSearch = document.getElementById('customerSearch');
        if (customerSearch) customerSearch.value = '';
        clearSearchResults();

        resetAllButtons();

        // Reset all weight inputs to 1
        setDefaultWeights();

        // Reset all karat dropdowns to 18K
        document.querySelectorAll('.karat-selector').forEach(select => {
            select.value = '18';
        });

        // Reinitialize prices
        initializeProductPrices();

        const receiptSection = document.getElementById('receiptSection');
        const mainContainer = document.querySelector('.container-fluid');

        if (receiptSection) receiptSection.classList.add('d-none');
        if (mainContainer) mainContainer.classList.remove('d-none');

        window.scrollTo({top: 0, behavior: 'smooth'});
        showNotification('Ready for a new order!', 'success');
    } catch (error) {
        console.error('Error starting new order:', error);
    }
}

// ============================
// GLOBAL FUNCTION EXPORTS
// ============================

// Make functions available globally for onclick handlers
window.updateMetalPrices = updateMetalPrices;
window.switchMetal = switchMetal;
window.switchModule = switchModule;
window.calculateScrapValue = calculateScrapValue;
window.addScrapToCart = addScrapToCart;
window.addBullionToCart = addBullionToCart;
window.updateProductPriceOnKaratChange = updateProductPriceOnKaratChange;
window.filterBySubcategory = filterBySubcategory;
window.searchProducts = searchProducts;
window.filterProducts = filterProducts;
window.switchToGridView = switchToGridView;
window.switchToListView = switchToListView;
window.proceedToCheckout = proceedToCheckout;
window.clearCart = clearCart;
window.backToShopping = backToShopping;
window.placeOrder = placeOrder;
window.removeFromCart = removeFromCart;
window.updateCartItemWeight = updateCartItemWeight;
window.startNewOrder = startNewOrder;
window.calculateJewelryPrice = calculateJewelryPrice;
window.calculateScrapPrice = calculateScrapPrice;
window.loadDynamicConfiguration = loadDynamicConfiguration;

// ============================
// SYSTEM INITIALIZATION COMPLETE
// ============================

console.log('Gold Trading System JavaScript loaded successfully');